﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlans_GetByArchiveAppraisalID]
    @ArchiveAppraisalID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanID, 
        ArchiveAppraisalID, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlans
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID
END