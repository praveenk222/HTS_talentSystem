﻿CREATE TABLE [Archive].[CompetencyApprovals] (
    [ArchiveCompetencyApprovalID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalCompetencyApprovalID] INT           NOT NULL,
    [ArchiveCompetencyID]          INT           NULL,
    [ArchiveSkillID]               INT           NULL,
    [ApprovalStatus]               NVARCHAR (50) NOT NULL,
    [Comment]                      NTEXT         NULL,
    [StatusChangedDate]            DATETIME      NULL,
    [ApproverName]                 NVARCHAR (75) NOT NULL,
    [ApproverID]                   NVARCHAR (20) NOT NULL,
    [ModifiedBy]                   NVARCHAR (50) NOT NULL,
    [ModifiedOn]                   DATETIME      CONSTRAINT [DF_CompetencyApprovals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_CompetencyApprovals] PRIMARY KEY CLUSTERED ([ArchiveCompetencyApprovalID] ASC),
    CONSTRAINT [FK_CompetencyApprovals_Competencies] FOREIGN KEY ([ArchiveCompetencyID]) REFERENCES [Archive].[Competencies] ([ArchiveCompetencyID]),
    CONSTRAINT [FK_CompetencyApprovals_Skills] FOREIGN KEY ([ArchiveSkillID]) REFERENCES [Archive].[Skills] ([ArchiveSkillID])
);


GO
CREATE TRIGGER [Archive].[tr_CompetencyApprovals_PreventChanges]     ON  Archive.CompetencyApprovals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END