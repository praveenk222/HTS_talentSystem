﻿CREATE TABLE [Archive].[AwardsPatentsRecognitions] (
    [ArchiveAwardPatentRecognitionID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalAwardPatentRecognitionID] INT           NOT NULL,
    [ArchiveProfileID]                 INT           NOT NULL,
    [Description]                      NTEXT         NOT NULL,
    [DateReceived]                     VARCHAR (4)   NOT NULL,
    [ReferenceNumber]                  NVARCHAR (20) NULL,
    [ModifiedBy]                       NVARCHAR (50) NOT NULL,
    [ModifiedOn]                       DATETIME      CONSTRAINT [DF_ArchiveAwardPatentRecognitions_ModifiedOn] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_AwardPatentRecognitions] PRIMARY KEY CLUSTERED ([ArchiveAwardPatentRecognitionID] ASC),
    CONSTRAINT [FK_AwardPatentRecognitions_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);


GO
CREATE TRIGGER [Archive].[tr_ArchiveAwardPatentRecognitions_PreventChanges]     ON  Archive.AwardsPatentsRecognitions     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END