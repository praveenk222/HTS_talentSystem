﻿CREATE TABLE [History].[EnterpriseCompetencies] (
    [CreatedOn]              DATETIME      CONSTRAINT [DF_EnterpriseCompetencies_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [EnterpriseCompetencyID] INT           NOT NULL,
    [Title]                  NVARCHAR (50) NOT NULL,
    [ManagerRequired]        BIT           NOT NULL,
    [EmployeeRequired]       BIT           NOT NULL,
    [IsDeleted]              BIT           NOT NULL,
    [ModifiedBy]             NVARCHAR (50) NOT NULL,
    [ModifiedOn]             DATETIME      NOT NULL,
    [TimeStamp]              BINARY (8)    NOT NULL,
    CONSTRAINT [PK_EnterpriseCompetencies] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [EnterpriseCompetencyID] ASC)
);

