﻿CREATE TABLE [History].[AwardsPatentsRecognitions] (
    [CreatedOn]                DATETIME      CONSTRAINT [DF_AwardsPatentsRecognition_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [AwardPatentRecognitionID] INT           NOT NULL,
    [EmployeeProfileID]        INT           NOT NULL,
    [Description]              NTEXT         NOT NULL,
    [DateReceived]             VARCHAR (50)  NOT NULL,
    [ReferenceNumber]          NVARCHAR (20) NULL,
    [CreatedBy]                VARCHAR (50)  NOT NULL,
    [Created]                  DATETIME      NOT NULL,
    [ModifiedBy]               NVARCHAR (50) NOT NULL,
    [ModifiedOn]               DATETIME      NOT NULL,
    CONSTRAINT [PK_AwardsPatentsRecognition] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [AwardPatentRecognitionID] ASC)
);

