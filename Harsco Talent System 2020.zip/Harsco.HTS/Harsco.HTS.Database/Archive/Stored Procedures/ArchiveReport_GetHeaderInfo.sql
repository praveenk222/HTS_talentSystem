﻿


-- =============================================
-- AUTHOR: Tejal Shah
-- CREATED DATE: 2020/08/31
--	
-- =============================================
CREATE PROCEDURE  [Archive].[ArchiveReport_GetHeaderInfo] 

@ProfileId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN
	SELECT  Profiles.EmployeeName, JobTitle, Email, Profiles.ManagerName, JobFamilyName, DateHired, DivisionName, LocationName, Appraisals.AppraisalType,
	(SUBSTRING(Appraisals.AppraisalType,0,6))   as Title
	FROM Archive.Profiles
		INNER JOIN Archive.Appraisals ON Appraisals.ArchiveAppraisalID = Profiles.ArchiveAppraisalID
    WHERE Profiles.ArchiveProfileId = @ProfileId

END
SET NOCOUNT OFF
COMMIT TRANSACTION;