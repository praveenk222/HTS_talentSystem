﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/17/2012
-- =============================================
CREATE PROCEDURE [dbo].[EnterpriseCompetenciesListActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN
  
    SELECT EnterpriseCompetencyID, ISNULL(Translations.TranslatedText,EnterpriseCompetencies.Title) as Title,
		ManagerRequired, EmployeeRequired, IsDeleted, EnterpriseCompetencies.ModifiedBy, EnterpriseCompetencies.ModifiedOn
    FROM EnterpriseCompetencies
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = EnterpriseCompetencies.Title
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = TranslationLanguageId
			and Code = @TranslationCode
	WHERE IsDeleted = 0
	Order by ISNULL(Translations.TranslatedText,EnterpriseCompetencies.Title)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;