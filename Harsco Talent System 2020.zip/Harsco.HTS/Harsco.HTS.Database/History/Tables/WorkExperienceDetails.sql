﻿CREATE TABLE [History].[WorkExperienceDetails] (
    [CreatedOn]               DATETIME      CONSTRAINT [DF_WorkExperienceDetails_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [WorkExperienceDetailID]  INT           NOT NULL,
    [WorkExperienceID]        INT           NOT NULL,
    [WorkExperienceTimeStamp] BINARY (8)    NOT NULL,
    [Title]                   NVARCHAR (75) NOT NULL,
    [Responsibilities]        NTEXT         NOT NULL,
    [Sequence]                INT           NOT NULL,
    [ModifiedBy]              NVARCHAR (50) NOT NULL,
    [ModifiedOn]              DATETIME      NOT NULL,
    [TimeStamp]               BINARY (8)    NOT NULL,
    CONSTRAINT [PK_WorkExperienceDetails] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [WorkExperienceDetailID] ASC)
);

