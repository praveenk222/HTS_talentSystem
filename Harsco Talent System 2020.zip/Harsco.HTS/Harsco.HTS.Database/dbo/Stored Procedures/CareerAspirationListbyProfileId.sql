﻿
-- =============================================
-- Author:		Ed Blair
-- Create date: 09/24/2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CareerAspirationListbyProfileId]

@ProfileId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	SELECT Id, ProfileId, Aspiration, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
	FROM dbo.CareerAspiration
	WHERE ProfileId = @ProfileId
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;