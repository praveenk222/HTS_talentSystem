﻿CREATE TABLE [History].[JobTitle] (
    [CreatedOn]   DATETIME      NOT NULL,
    [JobTitleId]  INT           NOT NULL,
    [Description] VARCHAR (255) NOT NULL,
    [IsDeleted]   BIT           NOT NULL,
    [CreatedBy]   VARCHAR (50)  NOT NULL,
    [Created]     DATETIME      NOT NULL,
    [ModifiedBy]  VARCHAR (50)  NOT NULL,
    [ModifiedOn]  DATETIME      NOT NULL,
    CONSTRAINT [PK_JobTitle_1] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [JobTitleId] ASC)
);

