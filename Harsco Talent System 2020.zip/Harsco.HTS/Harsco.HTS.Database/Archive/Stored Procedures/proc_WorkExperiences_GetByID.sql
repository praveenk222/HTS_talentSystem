﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_WorkExperiences_GetByID]
    @ArchiveWorkExperienceID int
AS
BEGIN
    SELECT ArchiveWorkExperienceID, 
        ArchiveProfileID, 
        EmployerName, 
        Address, 
        DateEmploymentStarted, 
        DateEmploymentEnded, 
        ModifiedBy, 
        ModifiedOn
    FROM WorkExperiences
    WHERE ArchiveWorkExperienceID = @ArchiveWorkExperienceID
END