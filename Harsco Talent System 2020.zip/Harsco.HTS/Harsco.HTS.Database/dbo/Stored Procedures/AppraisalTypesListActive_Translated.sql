﻿


-- ===================================================
-- AUTHOR:		 Ed Blair
-- CREATED DATE: 08/19/2013
--
-- [dbo].[AppraisalTypesListActive_Translated] 'en'
-- ===================================================
CREATE PROCEDURE  [dbo].[AppraisalTypesListActive_Translated]
    
@LanguageCode varchar(20)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @Translate TABLE
	(Keyphrase nvarchar(255),
	TranslatedText nvarchar(2000))

	INSERT INTO @Translate 
	SELECT KeyPhrase, TranslatedText 
		FROM dbo.Translations
		INNER JOIN dbo.TranslationLanguages ON TranslationLanguages.ID = Translations.TranslationLanguageId
			AND TranslationLanguages.Code = @LanguageCode
	
    SELECT AppraisalTypeID, Substring(Title,0,6) + (SELECT TranslatedText FROM @Translate WHERE Keyphrase = Substring(Title, 6,99)) as Title, Code
    FROM AppraisalTypes
    WHERE IsDeleted = 0
    
END
SET NOCOUNT OFF
COMMIT TRANSACTION;