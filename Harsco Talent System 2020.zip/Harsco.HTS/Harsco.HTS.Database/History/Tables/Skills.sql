﻿CREATE TABLE [History].[Skills] (
    [CreatedOn]              DATETIME      CONSTRAINT [DF_Skills_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [SkillID]                INT           NOT NULL,
    [ProfileId]              INT           NOT NULL,
    [EnterpriseCompetencies] VARCHAR (255) NOT NULL,
    [CreatedBy]              VARCHAR (50)  NOT NULL,
    [Created]                DATETIME      NOT NULL,
    [ModifiedBy]             NVARCHAR (50) NOT NULL,
    [ModifiedOn]             DATETIME      NOT NULL,
    [ApproverID]             NVARCHAR (20) NULL,
    [EmpRating]              INT           NULL,
    [Year]                   INT           NULL,
    [MngrRating]             INT           NULL,
    [ApprovalStatusID]       INT           NULL,
    CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [SkillID] ASC)
);



