﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 04/30/2013
-- =============================================
CREATE PROCEDURE  [dbo].[AppraisalsListByAppraisalTypeId]

@AppraisalTypeId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AppraisalID, AppraisalTypeID, COCViolation, ManagerMeeting,PerformanceRating, CompetencyRating, OverallRating, ReviewDate, SelfAssessmentComplete, ManagerStepComplete, 
		EmployeeComment, ManagerComment, ObjectiveComment, CompetencyComment, SkillComment, EmployeeName, EmployeeSignDate, ManagerName, ManagerSignDate, 
		ManagersManagerName, ManagersManagerSignDate, ModifiedBy, ModifiedOn
    FROM Appraisals
    WHERE AppraisalTypeId = @AppraisalTypeId
    
END
SET NOCOUNT OFF
COMMIT TRANSACTION;