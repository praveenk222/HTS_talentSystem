﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_Objectives_GetByArchiveAppraisalID]
    @ArchiveAppraisalID int
AS
BEGIN
    SELECT ArchiveObjectiveID, 
        ArchiveAppraisalID, 
        Description, 
        DateDue, 
        Achieved, 
        ModifiedBy, 
        ModifiedOn
    FROM Objectives
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID
END