﻿

-- ==========================================================
-- Author:		Ed Blair
-- Create date: 04/22/2015
-- Description: check to see if appraisal has been started
-- 
-- Modifications:
--  [dbo].[MoveAppraisalNotInProgress] 594
-- ==========================================================
CREATE PROCEDURE [dbo].[CheckAppraisalInProgress]

@AppraisalId int,
@ProfileId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @Count int
	DECLARE @Results TABLE (checkID int)
	
	INSERT INTO @Results
	SELECT ObjectiveID
	FROM Objectives
	WHERE (ISNULL(convert(varchar(1000),YearEndResults),'') != '' OR ISNULL(convert(varchar(1000),ManagerYearEndResults),'') != '')
	AND AppraisalID = @AppraisalId
	UNION ALL
	SELECT CompetencyID
	FROM Competencies
	WHERE (EmployeeSkillRatingId IS NOT NULL OR ManagerSkillRatingId IS NOT NULL)
	AND AppraisalID = @AppraisalId
	UNION ALL
	SELECT CompetencyID
	FROM CompetencyComments
	WHERE (ISNULL(convert(varchar(1000),Comment),'') != '' OR ISNULL(convert(varchar(1000),ManagerComment),'') != '')
	AND CompetencyID in (select CompetencyID FROM Competencies WHERE AppraisalID = @AppraisalId)
	UNION ALL
	SELECT ProfileId
	FROM MidYear
	WHERE ProfileID = @ProfileId
	AND (ISNULL(convert(varchar(1000),EmpObjective),'') != '' OR ISNULL(convert(varchar(1000),EmpValueBehavior),'') != '' OR ISNULL(convert(varchar(1000),EmpDevelopmentPlan),'') != ''
		OR ISNULL(convert(varchar(1000), MgrObjective),'') != '' OR ISNULL(convert(varchar(1000),MgrValueBehavior),'') != '' OR ISNULL(convert(varchar(1000),MgrDevelopmentPlan),'') != '')

	set @Count = @@ROWCOUNT
	
	SELECT @Count as CountCheck
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;