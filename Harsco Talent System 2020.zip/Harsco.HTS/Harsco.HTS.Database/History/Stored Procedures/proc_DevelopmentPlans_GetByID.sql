﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlans_GetByID]
    @DevelopmentPlanID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanID, 
        AppraisalID, 
        AppraisalTimeStamp, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM DevelopmentPlans
    WHERE DevelopmentPlanID = @DevelopmentPlanID
    ORDER BY CreatedOn Desc
END