﻿CREATE TABLE [Archive].[Skills] (
    [ArchiveSkillID]         INT           IDENTITY (1, 1) NOT NULL,
    [OriginalSkillID]        INT           NOT NULL,
    [ArchiveProfileId]       INT           NOT NULL,
    [EnterpriseCompetencies] VARCHAR (255) NOT NULL,
    [CreatedBy]              NVARCHAR (50) NOT NULL,
    [CreatedOn]              DATETIME      NOT NULL,
    [ModifiedBy]             NVARCHAR (50) NOT NULL,
    [ModifiedOn]             DATETIME      CONSTRAINT [DF_Skills_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    [ApproverID]             NVARCHAR (20) NULL,
    [EmpRating]              INT           NULL,
    [Year]                   INT           NULL,
    [MngrRating]             INT           NULL,
    [ApprovalStatusID]       INT           NULL,
    CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([ArchiveSkillID] ASC),
    CONSTRAINT [FK_Skills_Appraisals] FOREIGN KEY ([ArchiveProfileId]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);




GO
CREATE TRIGGER [Archive].[tr_Skills_PreventChanges]     ON  Archive.Skills     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END