﻿CREATE TABLE [Archive].[CareerAspiration] (
    [ArchiveCareerAspirationId]  INT          IDENTITY (1, 1) NOT NULL,
    [OriginalCareerAspirationId] INT          NOT NULL,
    [ArchiveProfileId]           INT          NOT NULL,
    [Aspiration]                 NTEXT        NOT NULL,
    [CreatedBy]                  VARCHAR (50) NOT NULL,
    [CreatedOn]                  DATETIME     NOT NULL,
    [ModifiedBy]                 VARCHAR (50) NOT NULL,
    [ModifiedOn]                 DATETIME     NOT NULL,
    CONSTRAINT [PK_CareerAspiration_3] PRIMARY KEY CLUSTERED ([ArchiveCareerAspirationId] ASC)
);

