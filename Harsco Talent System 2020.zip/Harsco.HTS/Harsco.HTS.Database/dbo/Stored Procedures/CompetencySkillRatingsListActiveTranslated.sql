﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 8/16/2012
-- =============================================
CREATE PROCEDURE [dbo].[CompetencySkillRatingsListActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CompetencySkillRatings.CompetencySkillRatingID, ISNULL(Translations.TranslatedText,CompetencySkillRatings.Title) as Title
    FROM CompetencySkillRatings
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = CompetencySkillRatings.Title 
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = TranslationLanguageId
			and TranslationLanguages.Code = @TranslationCode
	WHERE IsDeleted = 0
	ORDER BY ISNULL(Translations.TranslatedText,CompetencySkillRatings.Title)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;