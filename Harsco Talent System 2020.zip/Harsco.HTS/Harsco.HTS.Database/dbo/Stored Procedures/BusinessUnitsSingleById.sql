﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/20/2012
-- =============================================
CREATE PROCEDURE [dbo].[BusinessUnitsSingleById]	

@Id int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT BusinessUnitID, BusinessUnitName, Abbreviation, DisplayName, IsDeleted
	FROM vw_BusinessUnits
	WHERE BusinessUnitID = @Id

END
SET NOCOUNT OFF
COMMIT TRANSACTION;