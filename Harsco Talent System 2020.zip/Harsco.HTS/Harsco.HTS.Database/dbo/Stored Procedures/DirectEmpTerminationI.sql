﻿CREATE PROCEDURE [dbo].[DirectEmpTerminationI]
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN
DECLARE @Count int
DECLARE @RowNumber int
DECLARE @HCEmail varchar(255)
DECLARE @HCEmployeeID nvarchar(100)
DECLARE @HCUserName varchar(255)
DECLARE @PNetworkID nvarchar(255)

DECLARE @Profiles TABLE
	(
		Id int Identity(1,1),
		Email varchar(255),
		TerminationDate datetime,
		NetworkID nvarchar(255),
		EmployeeNumber nvarchar(100)
	)
	
	INSERT INTO @Profiles
	SELECT distinct Email,TerminationDate,networkid,employeenumber from profiles where terminationdate is null
	and networkid not in ('removed','duplicate')

	SET @Count = @@ROWCOUNT
	SET @RowNumber = 1


	WHILE @RowNumber <= @Count
		BEGIN
		--  Get profile table details
		 Select @PNetworkID= NetworkID from @Profiles where Id=@RowNumber 

		-- Get head count details
		SELECT @HCEmail = Email, @HCEmployeeID = EMPLOYEE_ID, @HCUserName = AD_USERNAME
		FROM HeadCount
		WHERE AD_USERNAME=@PNetworkID and direct_indirect='Direct'
		
		IF(@HCEmployeeID!=0 and @HCUserName>0)
		BEGIN
		Update profiles set TerminationDate=GETDATE() where NetworkID=@HCUserName and EmployeeNumber=@HCEmployeeID
		END
		SET @RowNumber = @RowNumber + 1
		END
		END
SET NOCOUNT OFF
COMMIT TRANSACTION;