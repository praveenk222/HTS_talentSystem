﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 7/10/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentPlanCompletion_Delete]

@Id int,
@ModifiedBy nvarchar(50)

AS

BEGIN

	UPDATE DevelopmentPlanCompletion
	SET	IsDeleted = 1, 
		ModifiedBy = @ModifiedBy, 
		ModifiedOn = getdate()
	WHERE Id = @ID

END