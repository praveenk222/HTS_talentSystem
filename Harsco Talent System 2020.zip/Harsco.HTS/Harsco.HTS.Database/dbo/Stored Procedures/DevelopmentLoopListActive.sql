﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2017/10/20
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentLoopListActive]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ID, Description, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM dbo.DevelopmentLoop
	WHERE IsDeleted = 0
	ORDER BY Description
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;