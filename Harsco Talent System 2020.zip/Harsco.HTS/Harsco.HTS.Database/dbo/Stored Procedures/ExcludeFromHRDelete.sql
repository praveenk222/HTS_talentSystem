﻿

-- =========================================================================
-- Author:		Ed Blair
-- Create date: 8/15/2013
-- Description:	delete a single ExcludeFromHR record
--
-- =========================================================================
CREATE PROCEDURE [dbo].[ExcludeFromHRDelete]

@Id int

AS

BEGIN

  DELETE FROM dbo.ExcludeFromHR
  WHERE Id = @Id
	
END