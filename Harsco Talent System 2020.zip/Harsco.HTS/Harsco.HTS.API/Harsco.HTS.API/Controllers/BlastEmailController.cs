﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.EmailService;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MimeKit;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [ApiController]
    [Route("[controller]")]
    public class BlastEmailController : ControllerBase
    {
        private readonly IEmailService _emailService;
        public BlastEmailController(IEmailService emailService)
        {
            this._emailService = emailService;
        }

        [HttpGet]
        [Route("GetDropDownValues")]
        public IActionResult GetDropDownValues()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var vwCountries = db.VwCountries.ToList().OrderBy(c => c.CountryName);
                var vwBusinessUnits = db.VwBusinessUnits.ToList().OrderBy(b => b.BusinessUnitName);
                var vwAppraisalPeriod = db.AppraisalTypes.Where(p => p.AppraisalTypeId > 17).ToList();

                var vwBalstEmailPicks = new List<BlastEmailPicks>()
                {
                    new BlastEmailPicks() { PickId = 1, PickTitle = "No Objectives Entered"},
                    new BlastEmailPicks() { PickId = 2, PickTitle = "Objectives not Approved"},
                    new BlastEmailPicks() { PickId = 3, PickTitle = "Mid - Year Appraisal Not Signed By Employee"},
                    new BlastEmailPicks() { PickId = 4, PickTitle = "Mid - Year Appraisal Not Signed By Manager"},
                    new BlastEmailPicks() { PickId = 5, PickTitle = "Appraisal Not Completed"},
                    new BlastEmailPicks() { PickId = 6, PickTitle = "Self Assesment Not Completed"},
                    new BlastEmailPicks() { PickId = 7, PickTitle = "Manager Needs to Complete Assessment"},
                    new BlastEmailPicks() { PickId = 8, PickTitle = "Employee Needs to Sign"},
                    new BlastEmailPicks() { PickId = 9, PickTitle = "Manager Needs to Sign"},
                    new BlastEmailPicks() { PickId = 10, PickTitle = "Manager's Manager Needs to Sign"},
                    new BlastEmailPicks() { PickId = 11, PickTitle = "All Users"}
                };
                return Ok(new
                {
                    vwCountries,
                    vwBusinessUnits,
                    vwAppraisalPeriod,
                    vwBalstEmailPicks
                });
            }
        }

        [HttpPost]
        [Route("SendBlastEmail")]
        public IActionResult SendBlastEmail(SendBlastEmailFunc model)
        {
            bool? result = false;
            if (model != null)
            {
                if (model.EmailUsers.Count > 0)
                {
                    var message = new Message(model.EmailUsers.Select(i => i.EmailAddress).ToArray(), model.EmailSubject, model.EmailMessage, null);
                    try
                    {
                        _emailService.SendEmailAsync(message);
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        result = false;
                    }
                }
            }
            //message.From.AddRange(emailMessage.FromAddresses.Select(x => new MailboxAddress(x.Name, x.Address)));

            return Ok(result);
        }

        [HttpGet]
        [Route("GetUsersForBlastEmail")]
        public IActionResult GetUsersForBlastEmail(int AppraisalTypeId, string CountryId, string DivisionId, int ProcId)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {//18, "253,105,233,231", "2,15,13", 6
                var result = db.SendBlastEmailUsers_SP.FromSqlRaw("SendBlastEmail  {0}, {1}, {2}, {3}",
                    AppraisalTypeId, CountryId, DivisionId, ProcId).ToList();

                List<BlastEmailUsers> UsersList = new List<BlastEmailUsers>();
                foreach (SendBlastEmailUsers_SP model in result)
                {
                    BlastEmailUsers bUser = new BlastEmailUsers();
                    model.BindModelTo(bUser);
                    bUser.SendEmail = true;
                    UsersList.Add(bUser);
                }

                return Ok(UsersList);
            }
        }
    }
}

public class BlastEmailPicks
{
    public int PickId { get; set; }
    public string PickTitle { get; set; }
}

public class BlastEmailUsers
{
    public int ProfileID { get; set; }
    public string EmployeeName { get; set; }
    public string EmailAddress { get; set; }
    public int CountryID { get; set; }
    public bool? SendEmail { get; set; }
}

public class SendBlastEmailFunc
{
    public bool? SendMyself { get; set; }
    public string EmailSubject { get; set; }
    public string EmailMessage { get; set; }
    public List<BlastEmailUsers> EmailUsers { get; set; }
}
