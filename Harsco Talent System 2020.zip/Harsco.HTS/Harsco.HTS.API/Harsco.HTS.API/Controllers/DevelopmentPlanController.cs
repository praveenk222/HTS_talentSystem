﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("[controller]")]
    [ApiController]
    public class DevelopmentPlanController : ControllerBase
    {
        [HttpGet]
        [Route("GetDevPlanDetailsByID")]
        public IActionResult GetDevPlanDetailsByID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                vmDevelopmentPlan devPlanVM = new vmDevelopmentPlan();
                var profile = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();

                var devPlanDB = db.DevelopmentPlans.Include(p => p.DevelopmentPlanDetails).Where(p => p.AppraisalId == profile.AppraisalId).FirstOrDefault();

                if (devPlanDB == null)
                {
                    devPlanDB = CreateDevelopmentPlan(profile);
                    return Ok(devPlanVM);
                }

                if (devPlanDB != null)
                {
                    devPlanDB.BindModelTo(devPlanVM);

                    devPlanVM.DevelopmentPlanDetails = new List<vmDevelopmentPlanDetails>();
                    foreach (var devPlanDetails in devPlanDB.DevelopmentPlanDetails)
                    {
                        vmDevelopmentPlanDetails devPlanDetailVM = new vmDevelopmentPlanDetails();
                        devPlanDetailVM.DevelopmentPlanApproval = new vmDevelopmentPlanApprovals();
                        var devPlanApprovalDB = db.DevelopmentPlanApprovals.Where(p => p.DevelopmentPlanDetailId == devPlanDetails.DevelopmentPlanDetailId).OrderByDescending(p => p.DevelopmentPlanApprovalId).FirstOrDefault();
                        devPlanApprovalDB.BindModelTo(devPlanDetailVM.DevelopmentPlanApproval);

                        devPlanDetails.BindModelTo(devPlanDetailVM);
                        devPlanVM.DevelopmentPlanDetails.Add(devPlanDetailVM);
                    }
                    return Ok(devPlanVM);
                }
                return Ok(null);
            }
        }

        private DevelopmentPlans CreateDevelopmentPlan(Profiles profile)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                DevelopmentPlans developmentPlansDB = new DevelopmentPlans();
                developmentPlansDB.AppraisalId = profile.AppraisalId;
                developmentPlansDB.ModifiedBy = profile.NetworkId;
                developmentPlansDB.ModifiedOn = DateTime.UtcNow;

                db.DevelopmentPlans.Add(developmentPlansDB);
                db.SaveChanges();
                return developmentPlansDB;
            }
        }

        [HttpGet]
        [Route("GetDropDownValues")]
        public IActionResult GetDropDownValues()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var pointOfEntry = db.PointOfEntry.Where(p => p.IsDeleted == false).ToList();
                var activityLoop = db.ActivityLoop.Where(p => p.IsDeleted == false).ToList();
                var developmentLoop = db.DevelopmentLoop.Where(p => p.IsDeleted == false).ToList();

                return Ok(new
                {
                    pointOfEntry,
                    activityLoop,
                    developmentLoop
                });
            }
        }

        [HttpPost]
        [Route("CreateDevPlanDetail")]
        public IActionResult CreateDevPlanDetail(vmDevelopmentPlan developmentPlanVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                try
                {
					var managerProfile = db.Profiles.Where(p => p.ProfileId == developmentPlanVM.DisplayUser.ManagerId).SingleOrDefault();
					var profileDB = db.Profiles.Where(p => p.ProfileId == developmentPlanVM.DisplayUser.ProfileId).SingleOrDefault();

					if (developmentPlanVM.DevelopmentPlanId == 0)
                    {
						var devPlanDB = CreateDevelopmentPlan(profileDB);
                        developmentPlanVM.DevelopmentPlanId = devPlanDB.DevelopmentPlanId;
					}

					//DevelopmentPlanDetails Section
					DevelopmentPlanDetails developmentPlanDetailsDB = new DevelopmentPlanDetails();
					developmentPlanVM.DevelopmentPlanDetails[0].BindModelTo(developmentPlanDetailsDB);
					developmentPlanDetailsDB.DevelopmentPlanId = developmentPlanVM.DevelopmentPlanId; 
					developmentPlanDetailsDB.Objective = "";
					developmentPlanDetailsDB.CreatedBy = developmentPlanVM.LoggedInUser.NetworkId;
					developmentPlanDetailsDB.CreatedOn = DateTime.Now;
					developmentPlanDetailsDB.ModifiedBy = developmentPlanVM.LoggedInUser.NetworkId;
					developmentPlanDetailsDB.ModifiedOn = DateTime.Now;

					db.DevelopmentPlanDetails.Add(developmentPlanDetailsDB);
					db.SaveChanges();

					//DevelopmentPlanApprovals section
					DevelopmentPlanApprovals devPlanApprovalsDB = new DevelopmentPlanApprovals();
					devPlanApprovalsDB.DevelopmentPlanDetailId = developmentPlanDetailsDB.DevelopmentPlanDetailId;
					devPlanApprovalsDB.ApprovalStatusId = 4;
					devPlanApprovalsDB.ApproverName = managerProfile.EmployeeName;
					devPlanApprovalsDB.ApproverId = managerProfile.NetworkId;
					devPlanApprovalsDB.ModifiedBy = developmentPlanVM.LoggedInUser.NetworkId;
					devPlanApprovalsDB.ModifiedOn = DateTime.Now;
					db.DevelopmentPlanApprovals.Add(devPlanApprovalsDB);
					db.SaveChanges();


                    //MidYear Section

                    
                    var managerProfileDB = managerProfile;

                    Appraisals appraisals = db.Appraisals.Where(a => a.AppraisalId == profileDB.AppraisalId).SingleOrDefault();
                    AppraisalTypes apt = db.AppraisalTypes.Where(a => a.AppraisalTypeId == appraisals.AppraisalTypeId).FirstOrDefault();

                    if (apt.Code == "MID")
                    {
                        MidYearEmpMgrDevPlan midYearEmpMgrDevPlan = new MidYearEmpMgrDevPlan();
                        midYearEmpMgrDevPlan.ProfileId = profileDB.ProfileId;
                        midYearEmpMgrDevPlan.DevPlanDetailId = developmentPlanDetailsDB.DevelopmentPlanDetailId;
                        midYearEmpMgrDevPlan.AppraisalTypeId = appraisals.AppraisalTypeId; //17;
                        midYearEmpMgrDevPlan.EmployeeName = profileDB.EmployeeName;
                        midYearEmpMgrDevPlan.ManagerName = managerProfileDB.EmployeeName;
                        midYearEmpMgrDevPlan.CreatedBy = profileDB.NetworkId;
                        midYearEmpMgrDevPlan.ModifiedBy = profileDB.NetworkId;
                        midYearEmpMgrDevPlan.CreatedOn = DateTime.Now;
                        midYearEmpMgrDevPlan.ModifiedOn = DateTime.Now;

                        db.MidYearEmpMgrDevPlan.Add(midYearEmpMgrDevPlan);
                        db.SaveChanges();
                    }

				}
                catch (Exception)
                {
                }
                

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("DeleteDevPlan")]
        public IActionResult DeleteDevPlan(vmDevelopmentPlanDetails developmentPlanDetailsVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                //var devPlanDB = db.DevelopmentPlans.Where(p => p.DevelopmentPlanId == developmentPlanVM.DevelopmentPlanId).SingleOrDefault();
                //db.DevelopmentPlans.Remove(devPlanDB);

                var devPlanDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanDetailId == developmentPlanDetailsVM.DevelopmentPlanDetailId).FirstOrDefault();
                db.DevelopmentPlanDetails.RemoveRange(devPlanDetailsDB);

                var devPlanApprovalsDb = db.DevelopmentPlanApprovals.Where(p => p.DevelopmentPlanDetailId == devPlanDetailsDB.DevelopmentPlanDetailId).ToList();
                db.DevelopmentPlanApprovals.RemoveRange(devPlanApprovalsDb);
                db.SaveChanges();

                //Delete MidYear record with the ObjectiveID
                var midYearDevPlanDB = db.MidYearEmpMgrDevPlan.Where(p => p.DevPlanDetailId == devPlanDetailsDB.DevelopmentPlanDetailId).SingleOrDefault();
                if (midYearDevPlanDB != null)
                {
                    db.MidYearEmpMgrDevPlan.Remove(midYearDevPlanDB);
                }

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("UpdateDevPlanDetail")]
        public IActionResult UpdateDevPlanDetail(vmDevelopmentPlan devPlanVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var managerProfile = db.Profiles.Where(p => p.ProfileId == devPlanVM.DisplayUser.ManagerId).SingleOrDefault();
                var dpDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanDetailId == devPlanVM.DevelopmentPlanDetails[0].DevelopmentPlanDetailId).FirstOrDefault();
                if (devPlanVM.DevelopmentPlanDetails[0].DevelopmentPlanApproval.ApprovalStatusId == 4)
                {
                    devPlanVM.DevelopmentPlanDetails[0].BindModelTo(dpDetailsDB);
                    dpDetailsDB.ModifiedBy = devPlanVM.LoggedInUser.NetworkId;
                    dpDetailsDB.ModifiedOn = DateTime.Now;
                    db.SaveChanges();

                    return Ok(new { status = "Success" });
                }
                else
                {
                    dpDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanDetailId == devPlanVM.DevelopmentPlanDetails[0].DevelopmentPlanDetailId).FirstOrDefault();

                    devPlanVM.DevelopmentPlanDetails[0].BindModelTo(dpDetailsDB);
                    dpDetailsDB.ModifiedBy = devPlanVM.LoggedInUser.NetworkId;
                    dpDetailsDB.ModifiedOn = DateTime.Now;

                    DevelopmentPlanApprovals devPlanApprovalsDB = new DevelopmentPlanApprovals();
                    devPlanApprovalsDB.DevelopmentPlanDetailId = devPlanVM.DevelopmentPlanDetails[0].DevelopmentPlanDetailId;
                    devPlanApprovalsDB.ApprovalStatusId = 4;
                    devPlanApprovalsDB.ApproverName = managerProfile.EmployeeName;
                    devPlanApprovalsDB.ApproverId = managerProfile.NetworkId;
                    devPlanApprovalsDB.ModifiedBy = devPlanVM.LoggedInUser.NetworkId;
                    devPlanApprovalsDB.ModifiedOn = DateTime.Now;
                    db.DevelopmentPlanApprovals.Add(devPlanApprovalsDB);
                    db.SaveChanges();

                    return Ok(new { status = "Success" });
                }
            }
        }

        [HttpPost]
        [Route("SubmitDevPlan")]
        public IActionResult SubmitDevPlan(vmDevelopmentPlanDetails devPlanDetailsVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var devPlanApprovalDb = db.DevelopmentPlanApprovals.Where(p => p.DevelopmentPlanDetailId == devPlanDetailsVM.DevelopmentPlanDetailId).OrderByDescending(p => p.DevelopmentPlanApprovalId).FirstOrDefault();

                devPlanApprovalDb.ApprovalStatusId = 1;
                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }
    }
}