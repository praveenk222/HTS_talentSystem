﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2017/10/20
-- =============================================
CREATE PROCEDURE [dbo].[ActivityLoopSingleById]

@ActivityLoopId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ID, Description, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM dbo.ActivityLoop
	WHERE ID = @ActivityLoopId
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;