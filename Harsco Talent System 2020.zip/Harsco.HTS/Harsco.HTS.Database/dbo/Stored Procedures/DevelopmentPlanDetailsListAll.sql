﻿  
  
  
-- =============================================  
-- AUTHOR: Shaun Kline  
-- CREATED DATE: 2009/06/24  
-- =============================================  
CREATE PROCEDURE [dbo].[DevelopmentPlanDetailsListAll]  
  
AS  
  
BEGIN  
    SELECT DevelopmentPlanDetailID,   
        DevelopmentPlanID,   
        Category,   
        Objective,   
        Activity,   
        SupportRequired,   
        DateDue,   
        MeasurementProcess,   
        CompletionId,  
		CompletionDate,  
        Result, 
        CreatedBy,   
        CreatedOn,  
        ModifiedBy,   
        ModifiedOn  
    FROM DevelopmentPlanDetails  
  
END