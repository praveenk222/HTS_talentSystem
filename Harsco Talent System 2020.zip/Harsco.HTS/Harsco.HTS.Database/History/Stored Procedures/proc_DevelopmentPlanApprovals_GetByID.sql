﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlanApprovals_GetByID]
    @DevelopmentPlanApprovalID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanApprovalID, 
        DevelopmentPlanStrengthID, 
        DevelopmentPlanStrengthTimeStamp, 
        DevelopmentPlanWeaknessID, 
        DevelopmentPlanWeaknessTimeStamp, 
        DevelopmentPlanDetailID, 
        DevelopmentPlanDetailTimeStamp, 
        Comment, 
        ApprovalStatusID, 
        ApprovalStatusTimeStamp, 
        StatusChangedDate, 
        ApproverName, 
        ApproverID, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM DevelopmentPlanApprovals
    WHERE DevelopmentPlanApprovalID = @DevelopmentPlanApprovalID
    ORDER BY CreatedOn Desc
END