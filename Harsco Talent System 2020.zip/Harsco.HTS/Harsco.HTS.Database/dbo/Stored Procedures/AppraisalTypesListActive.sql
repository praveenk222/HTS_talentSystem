﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 02/18/2013
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalTypesListActive]
    
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AppraisalTypeID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn,
        [TimeStamp]
    FROM AppraisalTypes
    WHERE IsDeleted = 0
    
END
SET NOCOUNT OFF
COMMIT TRANSACTION;