﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_UnderstoodLanguages_GetByID]
    @ArchiveUnderstoodLanguageID int
AS
BEGIN
    SELECT ArchiveUnderstoodLanguageID, 
        ArchiveProfileID, 
        Language, 
        Description, 
        LanguageFluency, 
        ModifiedBy, 
        ModifiedOn
    FROM UnderstoodLanguages
    WHERE ArchiveUnderstoodLanguageID = @ArchiveUnderstoodLanguageID
END