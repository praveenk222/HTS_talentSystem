﻿CREATE TABLE [History].[MidYear] (
    [CreatedOn]          DATETIME       NOT NULL,
    [MidYearID]          INT            NOT NULL,
    [ProfileID]          INT            NOT NULL,
    [AppraisalTypeID]    INT            NOT NULL,
    [EmpObjective]       NTEXT          NULL,
    [MgrObjective]       NTEXT          NULL,
    [EmpValueBehavior]   NTEXT          NULL,
    [MgrValueBehavior]   NTEXT          NULL,
    [EmpDevelopmentPlan] NTEXT          NULL,
    [MgrDevelopmentPlan] NTEXT          NULL,
    [ReviewDate]         DATETIME       NULL,
    [EmpSignDate]        DATETIME       NULL,
    [EmployeeName]       NVARCHAR (100) NULL,
    [MgrSignDate]        DATETIME       NULL,
    [ManagerName]        NVARCHAR (100) NULL,
    [CreatedBy]          VARCHAR (50)   NOT NULL,
    [Created]            DATETIME       NOT NULL,
    [ModifiedBy]         VARCHAR (50)   NOT NULL,
    [ModifiedOn]         DATETIME       NOT NULL,
    CONSTRAINT [PK_MidYear_1] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [MidYearID] ASC)
);

