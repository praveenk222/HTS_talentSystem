﻿    
    
    
-- =============================================    
-- Author:  Ed Blair    
-- Create date: 03/08/2013    
-- Description:     
-- [CountriesListForHREmployee] 'tshah'    
-- =============================================    
CREATE PROCEDURE [dbo].[CountriesListForHREmployee]    
    
@CurrentUser nvarchar(50)    
    
AS    
    
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;    
BEGIN TRANSACTION;    
SET NOCOUNT ON    
BEGIN    
    
 DECLARE @seeAll int    
 DECLARE @CountryId int    
     
 SELECT @seeAll=ISNULL(HRBP,0), @CountryId = ISNULL(HRPermissions.CountryId,0)    
 FROM HRUsers    
 INNER JOIN HRPermissions ON HRPermissions.HRUserId = HRUsers.HRUserId    
 WHERE HRUsers.UserName = @CurrentUser    
      
 If ((@seeAll = 1) OR (@CountryId = 0))    
 BEGIN    
  SELECT vw_Countries.CountryName, vw_Countries.CountryId, vw_Countries.CountryCode    
  FROM dbo.vw_Countries    
  ORDER BY CountryName 
	  
 END    
 ELSE    
 BEGIN    
  SELECT distinct vw_Countries.CountryName, vw_Countries.CountryId, vw_Countries.CountryCode    
  FROM HRUsers    
   INNER JOIN HRPermissions on HRPermissions.HRUserId = HRUsers.HRUserId    
   LEFT OUTER JOIN dbo.vw_Countries ON vw_Countries.CountryID = HRPermissions.CountryId    
  WHERE UserName = @CurrentUser    
      
  AND (@seeAll = 1 OR HRPermissions.CountryId IN (SELECT CountryID FROM dbo.vw_Countries))    
  ORDER BY CountryName    
   
 END    
    
END    
SET NOCOUNT OFF    
COMMIT TRANSACTION;