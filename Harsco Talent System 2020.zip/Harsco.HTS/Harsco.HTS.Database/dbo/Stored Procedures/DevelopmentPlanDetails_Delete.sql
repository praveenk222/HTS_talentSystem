﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentPlanDetails_Delete]

@DevelopmentPlanDetailID int,
@ModifiedBy nvarchar(50)

AS

BEGIN
	--UPDATE DevelopmentPlanComments
 --   SET ModifiedBy = @ModifiedBy,
 --       ModifiedOn = GETDATE()
 --   WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID

	UPDATE DevelopmentPlanApprovals
    SET ModifiedBy = @ModifiedBy,
        ModifiedOn = GETDATE()
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID

    UPDATE DevelopmentPlanDetails
    SET ModifiedBy = @ModifiedBy,
        ModifiedOn = GETDATE()
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID

    WAITFOR DELAY '00:00:00.005'

    --DELETE FROM DevelopmentPlanComments
    --WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID

    DELETE FROM DevelopmentPlanApprovals
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID

    DELETE FROM DevelopmentPlanDetails
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID
END