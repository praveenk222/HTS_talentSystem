﻿CREATE TABLE [History].[LicenseCategories] (
    [CreatedOn]         DATETIME      CONSTRAINT [DF_LicenseCategories_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [LicenseCategoryID] INT           NOT NULL,
    [Title]             NVARCHAR (50) NOT NULL,
    [IsDeleted]         BIT           NOT NULL,
    [CreatedBy]         VARCHAR (50)  NOT NULL,
    [Created]           DATETIME      NOT NULL,
    [ModifiedBy]        NVARCHAR (50) NOT NULL,
    [ModifiedOn]        DATETIME      NOT NULL,
    CONSTRAINT [PK_LicenseCategories] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [LicenseCategoryID] ASC)
);

