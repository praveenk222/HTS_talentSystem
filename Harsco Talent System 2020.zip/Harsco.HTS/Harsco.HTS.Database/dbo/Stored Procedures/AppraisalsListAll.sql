﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2009/06/24
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalsListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN
    SELECT AppraisalID, 
        AppraisalTypeID, 
        COCViolation, 
        ManagerMeeting,
        PerformanceRating, 
        CompetencyRating, 
        OverallRating, 
        ReviewDate, 
        SelfAssessmentComplete, 
        ManagerStepComplete, 
        EmployeeComment, 
        ManagerComment, 
        ObjectiveComment, 
        CompetencyComment, 
        SkillComment, 
        EmployeeName, 
        EmployeeSignDate, 
        ManagerName, 
        ManagerSignDate, 
        ManagersManagerName, 
        ManagersManagerSignDate, 
        ModifiedBy, 
        ModifiedOn
    FROM Appraisals

END
SET NOCOUNT OFF
COMMIT TRANSACTION;