﻿CREATE TABLE [History].[ObjectiveComments] (
    [CreatedOn]                   DATETIME      CONSTRAINT [DF_ObjectiveComments_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ObjectiveCommentID]          INT           NOT NULL,
    [ObjectiveID]                 INT           NULL,
    [ObjectiveMilestoneID]        INT           NULL,
    [ObjectiveMilestoneTimeStamp] BINARY (8)    NULL,
    [Comment]                     NTEXT         NOT NULL,
    [Confidential]                BIT           NOT NULL,
    [CommentTypeID]               INT           NOT NULL,
    [ModifiedBy]                  NVARCHAR (50) NOT NULL,
    [ModifiedOn]                  DATETIME      NOT NULL,
    [TimeStamp]                   BINARY (50)   NOT NULL,
    CONSTRAINT [PK_ObjectiveComments] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ObjectiveCommentID] ASC)
);

