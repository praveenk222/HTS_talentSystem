﻿CREATE TABLE [History].[DevelopmentPlanApprovals] (
    [CreatedOn]                        DATETIME       CONSTRAINT [DF_DevelopmentPlanApprovals_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [DevelopmentPlanApprovalID]        INT            NOT NULL,
    [DevelopmentPlanStrengthID]        INT            NULL,
    [DevelopmentPlanStrengthTimeStamp] BINARY (8)     NULL,
    [DevelopmentPlanWeaknessID]        INT            NULL,
    [DevelopmentPlanWeaknessTimeStamp] BINARY (8)     NULL,
    [DevelopmentPlanDetailID]          INT            NULL,
    [DevelopmentPlanDetailTimeStamp]   BINARY (8)     NULL,
    [Comment]                          NTEXT          NULL,
    [ApprovalStatusID]                 INT            NOT NULL,
    [ApprovalStatusTimeStamp]          BINARY (8)     NOT NULL,
    [StatusChangedDate]                DATETIME       NULL,
    [ApproverName]                     NVARCHAR (255) NOT NULL,
    [ApproverID]                       NVARCHAR (20)  NOT NULL,
    [ModifiedBy]                       NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                       DATETIME       NOT NULL,
    [TimeStamp]                        BINARY (8)     NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanApprovals] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanApprovalID] ASC)
);

