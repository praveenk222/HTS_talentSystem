﻿  
  
  
-- =============================================  
-- AUTHOR: Shaun Kline  
-- CREATED DATE: 2009/06/24  
-- =============================================  
CREATE PROCEDURE [dbo].[DevelopmentPlanDetails_Update]  
  
@DevelopmentPlanDetailID int,  
@DevelopmentPlanID int,  
@Category int,  
@Objective ntext,  
@Activity ntext,  
@SupportRequired ntext,  
@DateDue smalldatetime,  
@MeasurementProcess nvarchar(255),  
@CompletionId int,  
@PointOfEntryId int,   
@ActivityLoopId int,   
@DevelopmentLoopId int,  
@CompletionDate smalldatetime,  
@Result nvarchar(255),  
@ModifiedBy nvarchar(50),  
@ModifiedOn datetime  
  
AS  
  
BEGIN  
    UPDATE DevelopmentPlanDetails  
    SET DevelopmentPlanID = @DevelopmentPlanID,   
        Category = @Category,   
        Objective = @Objective,   
        Activity = @Activity,   
        SupportRequired = @SupportRequired,   
        DateDue = @DateDue,   
        MeasurementProcess = @MeasurementProcess,   
        CompletionId = @CompletionId,  
  PointOfEntryId = @PointOfEntryId,  
  ActivityLoopId = @ActivityLoopId,  
  DevelopmentLoopId =  @DevelopmentLoopId,
  CompletionDate=@CompletionDate,  
  Result=@Result,  
        ModifiedBy = @ModifiedBy,   
        ModifiedOn = @ModifiedOn  
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID  
END