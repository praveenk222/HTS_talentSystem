﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 5/1/2013
-- =============================================
CREATE PROCEDURE [dbo].[BusinessUnitsListActive]	

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT BusinessUnitID, BusinessUnitName, Abbreviation, DisplayName, IsDeleted
	FROM vw_BusinessUnits
	WHERE IsDeleted = 0
	ORDER BY BusinessUnitName

END
SET NOCOUNT OFF
COMMIT TRANSACTION;