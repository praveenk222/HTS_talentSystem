﻿CREATE TABLE [Archive].[ObjectiveMilestones] (
    [ArchiveObjectiveMilestoneID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalObjectiveMilestoneID] INT           NOT NULL,
    [ArchiveObjectiveID]           INT           NOT NULL,
    [Title]                        NVARCHAR (50) NOT NULL,
    [DateDue]                      SMALLDATETIME NOT NULL,
    [MilestoneStatus]              NVARCHAR (50) NOT NULL,
    [ModifiedBy]                   NVARCHAR (50) NOT NULL,
    [ModifiedOn]                   DATETIME      CONSTRAINT [DF_ObjectiveMilestones_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ObjectiveMilestones_1] PRIMARY KEY CLUSTERED ([ArchiveObjectiveMilestoneID] ASC),
    CONSTRAINT [FK_ObjectiveMilestones_Objectives] FOREIGN KEY ([ArchiveObjectiveID]) REFERENCES [Archive].[Objectives] ([ArchiveObjectiveID])
);


GO
CREATE TRIGGER [Archive].[tr_ObjectiveMilestones_PreventChanges]     ON  Archive.ObjectiveMilestones     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END