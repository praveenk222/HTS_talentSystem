﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_EnterpriseCompetencies_GetByID]
    @EnterpriseCompetencyID int
AS
BEGIN
    SELECT CreatedOn, 
        EnterpriseCompetencyID, 
        Title, 
        ManagerRequired, 
        EmployeeRequired, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM EnterpriseCompetencies
    WHERE EnterpriseCompetencyID = @EnterpriseCompetencyID
    ORDER BY CreatedOn Desc
END