﻿using System;
using System.Collections.Generic;

namespace Harsco.HTS.API.Models
{
    public partial class VwDivisionAliases
    {
        public int DivisionAkaid { get; set; }
        public int? DivisionId { get; set; }
        public string Alias { get; set; }
    }
}
