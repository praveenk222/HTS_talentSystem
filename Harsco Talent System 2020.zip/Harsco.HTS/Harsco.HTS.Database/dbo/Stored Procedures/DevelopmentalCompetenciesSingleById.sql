﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 07/13/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetenciesSingleById]

@Id int

AS

BEGIN
    SELECT Id, 
        Competency, 
        IsDeleted,
        CreatedBy, 
        CreatedOn,        
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentalCompetencies
    WHERE Id = @Id
END