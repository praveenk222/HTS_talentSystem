﻿



-- ===================================================
-- AUTHOR:		 Ed Blair
-- CREATED DATE: 10/20/2017
--
-- [dbo].[ActivityLoopListActiveTranslated] 'en'
-- ===================================================
CREATE PROCEDURE  [dbo].[ActivityLoopListActiveTranslated]
    
@LanguageCode varchar(20)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  	DECLARE @Translate TABLE
	(Keyphrase nvarchar(255),
	TranslatedText nvarchar(2000))

	INSERT INTO @Translate 
	SELECT KeyPhrase, TranslatedText 
		FROM dbo.Translations
		INNER JOIN dbo.TranslationLanguages ON TranslationLanguages.ID = Translations.TranslationLanguageId
			AND TranslationLanguages.Code = @LanguageCode
	
    SELECT ActivityLoop.ID, ISNULL((SELECT TranslatedText FROM @Translate WHERE Keyphrase = ActivityLoop.Description),ActivityLoop.Description) as Description
    FROM ActivityLoop
    WHERE IsDeleted = 0
    

END
SET NOCOUNT OFF
COMMIT TRANSACTION;