﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_AppraisalAttachments_GetByArchiveAppraisalID]
    @ArchiveAppraisalID int
AS
BEGIN
    SELECT ArchiveAppraisalAttachmentID, 
        ArchiveAppraisalID, 
        FileName, 
        FileSize, 
        ContentType, 
        Attachment, 
        ModifiedBy, 
        ModifiedOn
    FROM AppraisalAttachments
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID
END