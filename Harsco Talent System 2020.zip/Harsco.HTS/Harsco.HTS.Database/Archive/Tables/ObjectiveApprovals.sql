﻿CREATE TABLE [Archive].[ObjectiveApprovals] (
    [ArchiveObjectiveApprovalID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalObjectiveApprovalID] INT           NOT NULL,
    [ArchiveObjectiveID]          INT           NULL,
    [ArchiveObjectiveMilestoneID] INT           NULL,
    [ApprovalStatus]              NVARCHAR (50) NOT NULL,
    [Comment]                     NTEXT         NULL,
    [StatusChangedDate]           DATETIME      NULL,
    [ApproverName]                NVARCHAR (75) NOT NULL,
    [ApproverID]                  NVARCHAR (20) NOT NULL,
    [ModifiedBy]                  NVARCHAR (50) NOT NULL,
    [ModifiedOn]                  DATETIME      CONSTRAINT [DF_ObjectiveApprovals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ObjectiveApprovals_1] PRIMARY KEY CLUSTERED ([ArchiveObjectiveApprovalID] ASC),
    CONSTRAINT [FK_ObjectiveApprovals_ObjectiveMilestones] FOREIGN KEY ([ArchiveObjectiveMilestoneID]) REFERENCES [Archive].[ObjectiveMilestones] ([ArchiveObjectiveMilestoneID]),
    CONSTRAINT [FK_ObjectiveApprovals_Objectives] FOREIGN KEY ([ArchiveObjectiveID]) REFERENCES [Archive].[Objectives] ([ArchiveObjectiveID])
);


GO
CREATE TRIGGER [Archive].[tr_ObjectiveApprovals_PreventChanges]     ON  Archive.ObjectiveApprovals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END