﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalsUpdateManagerMeeting]

@AppraisalID int,
@ManagerMeeting varchar(1),
@ModifiedBy varchar(50)

AS

BEGIN
	
    UPDATE Appraisals SET ManagerMeeting = @ManagerMeeting, ModifiedBy = @ModifiedBy, ModifiedOn = getdate()
    WHERE AppraisalID = @AppraisalID

END