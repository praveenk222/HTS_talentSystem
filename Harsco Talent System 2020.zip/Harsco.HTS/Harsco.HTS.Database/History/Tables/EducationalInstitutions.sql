﻿CREATE TABLE [History].[EducationalInstitutions] (
    [CreatedOn]                  DATETIME       CONSTRAINT [DF_EducationalInstitutions_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [EducationalInstitutionID]   INT            NOT NULL,
    [EmployeeProfileID]          INT            NOT NULL,
    [InstitutionName]            NVARCHAR (75)  NOT NULL,
    [Address]                    NVARCHAR (255) NOT NULL,
    [EducationalDegreeID]        INT            NOT NULL,
    [EducationalDegreeTimeStamp] BINARY (8)     NOT NULL,
    [DegreeObtainedOther]        NVARCHAR (75)  NULL,
    [YearsAttendedStart]         INT            NOT NULL,
    [YearsAttendedEnd]           INT            NULL,
    [Description]                NTEXT          NOT NULL,
    [ModifiedBy]                 NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                 DATETIME       NOT NULL,
    [TimeStamp]                  BINARY (8)     NOT NULL,
    CONSTRAINT [PK_EducationalInstitutions] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [EducationalInstitutionID] ASC)
);



