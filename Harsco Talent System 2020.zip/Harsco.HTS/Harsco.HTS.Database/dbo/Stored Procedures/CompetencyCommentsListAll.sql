﻿



-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/12
-- =============================================
CREATE PROCEDURE  [dbo].[CompetencyCommentsListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CompetencyCommentID, CompetencyID, Comment, ManagerComment, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM dbo.CompetencyComments
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;