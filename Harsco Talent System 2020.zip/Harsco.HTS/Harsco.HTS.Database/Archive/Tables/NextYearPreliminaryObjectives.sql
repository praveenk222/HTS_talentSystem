﻿CREATE TABLE [Archive].[NextYearPreliminaryObjectives] (
    [ArchiveId]          INT          IDENTITY (1, 1) NOT NULL,
    [OriginalId]         INT          NOT NULL,
    [AppraisalId]        INT          NOT NULL,
    [NextYearObjectives] NTEXT        NOT NULL,
    [CreatedBy]          VARCHAR (50) NOT NULL,
    [CreatedOn]          DATETIME     NOT NULL,
    [ModifiedBy]         VARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME     NOT NULL,
    CONSTRAINT [PK_NextYearPreliminaryObjectives_1] PRIMARY KEY CLUSTERED ([ArchiveId] ASC)
);

