﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/10/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentPlanCompletion_Modify]

@Id int,
@Completion varchar(50),
@IsDeleted bit,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.DevelopmentPlanCompletion WHERE Id = @Id))
		BEGIN
			UPDATE DevelopmentPlanCompletion
			SET Completion = @Completion, 
				IsDeleted = @IsDeleted, 
				ModifiedBy = @ModifiedBy, 
				ModifiedOn = @ModifiedOn
			WHERE Id = @ID
		END
    ELSE
		BEGIN
			INSERT INTO DevelopmentPlanCompletion
			(Completion, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@Completion, @IsDeleted, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

		END
END