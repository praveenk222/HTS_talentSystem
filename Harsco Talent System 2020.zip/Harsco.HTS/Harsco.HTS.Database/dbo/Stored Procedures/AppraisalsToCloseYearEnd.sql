﻿-- =============================================  
-- AUTHOR: 
-- CREATED DATE: 04/02/2014  
-- [dbo].[AppraisalsToCloseYearEnd] 6, '', '2','233'  
-- =============================================  
CREATE PROCEDURE [dbo].[AppraisalsToCloseYearEnd]    
	@AppraisalTypeID int,  
	@EmployeeNetworkId varchar(50)
AS  
SET NOCOUNT ON  
BEGIN  
  
	SELECT 
		Appraisals.AppraisalID, AppraisalTypeID, COCViolation, ManagerMeeting,PerformanceRating, CompetencyRating, OverallRating, ReviewDate, SelfAssessmentComplete,   
		ManagerStepComplete, EmployeeComment, ManagerComment, ObjectiveComment, CompetencyComment, SkillComment, Appraisals.EmployeeName,   
		EmployeeSignDate, ManagerName, ManagerSignDate, ManagersManagerName, ManagersManagerSignDate, Appraisals.ModifiedBy, Appraisals.ModifiedOn, [TimeStamp]  
	FROM 
		Appraisals  
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID  
	AND AppraisalTypeID = @AppraisalTypeID   
	AND Profiles.NetworkID = @EmployeeNetworkId 
	--AND (@CountryID = '' OR @CountryID IS NULL OR Profiles.CountryID IN (Select items From dbo.Split(@CountryID, ',')))  
	--AND (@DivisionID = '' OR @DivisionID IS NULL OR Profiles.DivisionID IN (Select items From dbo.Split(@DivisionID, ',')))   
	AND NetworkId NOT IN ('Removed','Duplicate')  
	AND Networkid NOT IN (SELECT NetworkID FROM NotRequiredReview WHERE IsDeleted = 0) 
   
END  
SET NOCOUNT OFF
