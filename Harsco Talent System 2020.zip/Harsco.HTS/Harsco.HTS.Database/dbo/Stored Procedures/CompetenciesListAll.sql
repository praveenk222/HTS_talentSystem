﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/12
-- =============================================
CREATE PROCEDURE [dbo].[CompetenciesListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CompetencyID, AppraisalID, EnterpriseCompetencyID, EmployeeSkillRatingId, ManagerSkillRatingId, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM Competencies
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;