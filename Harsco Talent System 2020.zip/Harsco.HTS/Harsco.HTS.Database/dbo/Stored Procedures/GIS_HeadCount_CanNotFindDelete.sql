﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/20
-- =============================================
CREATE PROCEDURE [dbo].[GIS_HeadCount_CanNotFindDelete]

@RowId int

AS

BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DELETE
	FROM dbo.GIS_HeadCount_CanNotFind
	WHERE ROW_WID = @RowId
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;