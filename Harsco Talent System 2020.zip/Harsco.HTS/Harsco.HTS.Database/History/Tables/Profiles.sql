﻿CREATE TABLE [History].[Profiles] (
    [CreatedOn]               DATETIME       CONSTRAINT [DF_Profile_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ProfileID]               INT            NOT NULL,
    [AppraisalID]             INT            NOT NULL,
    [AppraisalTimeStamp]      BINARY (8)     NOT NULL,
    [NetworkID]               NVARCHAR (20)  NOT NULL,
    [ManagerProfileID]        INT            NULL,
    [ManagerProfileTimeStamp] BINARY (8)     NULL,
    [EmployeeNumber]          NVARCHAR (20)  NULL,
    [EmployeeName]            NVARCHAR (255) NULL,
    [Email]                   NVARCHAR (255) NULL,
    [DivisionID]              INT            NULL,
    [DivisionName]            VARCHAR (255)  NULL,
    [CountryID]               INT            NULL,
    [CountryCode]             VARCHAR (3)    NULL,
    [Location]                VARCHAR (255)  NULL,
    [Address]                 NVARCHAR (255) NULL,
    [PhoneNumber]             NVARCHAR (255) NULL,
    [JobTitle]                NVARCHAR (255) NULL,
    [JobFamilyID]             INT            NULL,
    [JobFamilyName]           NVARCHAR (75)  NULL,
    [DateHired]               SMALLDATETIME  NULL,
    [TerminationDate]         SMALLDATETIME  NULL,
    [CreatedBy]               VARCHAR (50)   NOT NULL,
    [Created]                 DATETIME       NOT NULL,
    [ModifiedBy]              NVARCHAR (50)  NOT NULL,
    [ModifiedOn]              DATETIME       NOT NULL,
    CONSTRAINT [PK_Profile] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ProfileID] ASC)
);



