﻿CREATE TABLE [History].[AppraisalAttachments] (
    [CreatedOn]             DATETIME       CONSTRAINT [DF_Table_2_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [AppraisalAttachmentID] INT            NOT NULL,
    [AppraisalID]           INT            NOT NULL,
    [AppraisalTimeStamp]    BINARY (8)     NOT NULL,
    [FileName]              NVARCHAR (100) NOT NULL,
    [FileSize]              INT            NOT NULL,
    [ContentType]           NVARCHAR (100) NOT NULL,
    [Attachment]            IMAGE          NOT NULL,
    [ModifiedBy]            NVARCHAR (50)  NOT NULL,
    [ModifiedOn]            DATETIME       NOT NULL,
    [TimeStamp]             BINARY (50)    NOT NULL,
    CONSTRAINT [PK_Table_2] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [AppraisalAttachmentID] ASC)
);

