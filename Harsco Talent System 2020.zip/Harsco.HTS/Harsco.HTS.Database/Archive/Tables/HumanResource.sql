﻿CREATE TABLE [Archive].[HumanResource] (
    [ArchiveId]          INT          IDENTITY (1, 1) NOT NULL,
    [OriginalId]         INT          NOT NULL,
    [ArchiveAppraisalId] INT          NOT NULL,
    [SendToHr]           DATETIME     NOT NULL,
    [SendToManager]      DATETIME     NOT NULL,
    [Comments]           NTEXT        NOT NULL,
    [CreatedBy]          VARCHAR (50) NOT NULL,
    [CreatedOn]          DATETIME     NOT NULL,
    [ModifiedBy]         VARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME     NOT NULL,
    CONSTRAINT [PK_HumanResource_1] PRIMARY KEY CLUSTERED ([ArchiveId] ASC)
);

