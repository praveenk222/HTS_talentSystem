﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/24/2012
-- =============================================
CREATE PROCEDURE [dbo].[AwardsPatentsRecognitionsInsert]

@ProfileID int,
@Description ntext,
@DateReceived varchar(4),
@ReferenceNumber nvarchar(20),
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	
    INSERT INTO AwardsPatentsRecognitions
    (ProfileID, Description, DateReceived, ReferenceNumber, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
    VALUES (@ProfileID, @Description, @DateReceived, @ReferenceNumber, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

	SELECT AwardPatentRecognitionID from AwardsPatentsRecognitions WHERE AwardPatentRecognitionID = SCOPE_IDENTITY();
END