﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_Appraisals_GetByID]
    @ArchiveAppraisalID int
AS
BEGIN
    SELECT ArchiveAppraisalID, 
        OriginalAppraisalID,
        AppraisalYear, 
        AppraisalType,
        COCViolation,
        PerformanceRating,
        CompetencyRating,
        OverallRating,
        ReviewDate,
        SelfAssessmentComplete,
        ManagerStepComplete,
        EmployeeComment,
        ManagerComment,
        ObjectiveComment,
        CompetencyComment,
        SkillComment,
        EmployeeName,
        EmployeeSignDate,
        ManagerName,
        ManagerSignDate,
        ManagersManagerName,
        ManagersManagerSignDate,
        ModifiedBy,
        ModifiedOn
    FROM Archive.Appraisals
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID
END