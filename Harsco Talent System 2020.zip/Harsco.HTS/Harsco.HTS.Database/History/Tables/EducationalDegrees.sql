﻿CREATE TABLE [History].[EducationalDegrees] (
    [CreatedOn]           DATETIME      CONSTRAINT [DF_EducationalDegree_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [EducationalDegreeID] INT           NOT NULL,
    [Abbreviation]        NVARCHAR (10) NOT NULL,
    [Title]               NVARCHAR (75) NOT NULL,
    [IsDeleted]           BIT           NOT NULL,
    [ModifiedBy]          NVARCHAR (50) NOT NULL,
    [ModifiedOn]          DATETIME      NOT NULL,
    [TimeStamp]           BINARY (8)    NOT NULL,
    CONSTRAINT [PK_EducationalDegree] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [EducationalDegreeID] ASC)
);

