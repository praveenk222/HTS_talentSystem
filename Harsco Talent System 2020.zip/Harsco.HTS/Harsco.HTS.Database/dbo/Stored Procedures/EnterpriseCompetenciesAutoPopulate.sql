﻿
-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/16/2012
-- =============================================
CREATE PROCEDURE [dbo].[EnterpriseCompetenciesAutoPopulate]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT EnterpriseCompetencyId, Title
    FROM dbo.EnterpriseCompetencies
	WHERE EnterpriseCompetencyId in (17,18,19,20,21,22) --(11,12,13,14,15,16)
	Order by Title
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;