﻿CREATE TABLE [History].[CompetencySkillRatings] (
    [CreatedOn]               DATETIME      CONSTRAINT [DF_ObjectiveSkillRatings_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CompetencySkillRatingID] INT           NOT NULL,
    [Title]                   NVARCHAR (50) NOT NULL,
    [Code]                    NVARCHAR (6)  NOT NULL,
    [IsDeleted]               BIT           NOT NULL,
    [ModifiedBy]              NVARCHAR (50) NOT NULL,
    [ModifiedOn]              DATETIME      NOT NULL,
    [TimeStamp]               BINARY (50)   NOT NULL,
    CONSTRAINT [PK_ObjectiveSkillRatings] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CompetencySkillRatingID] ASC)
);

