﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanApprovals_GetByArchiveDevelopmentPlanStrengthID]
    @ArchiveDevelopmentPlanStrengthID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanApprovalID, 
        ArchiveDevelopmentPlanStrengthID, 
        ArchiveDevelopmentPlanWeaknessID, 
        ArchiveDevelopmentPlanDetailID, 
        Comment, 
        ApprovalStatus, 
        StatusChangedDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanApprovals
    WHERE ArchiveDevelopmentPlanStrengthID = @ArchiveDevelopmentPlanStrengthID
END