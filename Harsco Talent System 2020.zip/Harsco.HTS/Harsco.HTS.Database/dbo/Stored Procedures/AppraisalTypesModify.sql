﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 5/1/2013
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalTypesModify]

@AppraisalTypeID int,
@Title nvarchar(50),
@Code nvarchar(6),
@IsDeleted bit,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime
      
AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.AppraisalTypes WHERE AppraisalTypeID = @AppraisalTypeID))
		BEGIN
			UPDATE AppraisalTypes
			SET 
			Title = @Title,
			Code = @Code,
			IsDeleted = @IsDeleted,
			ModifiedBy = @ModifiedBy,
			ModifiedOn = @ModifiedOn
			WHERE AppraisalTypeID = @AppraisalTypeID		
		END
    ELSE
		BEGIN
			INSERT INTO AppraisalTypes 
			(Title, Code, IsDeleted, ModifiedBy, ModifiedOn)
			VALUES (@Title, @Code, @IsDeleted, @ModifiedBy, @ModifiedOn)
		END
END