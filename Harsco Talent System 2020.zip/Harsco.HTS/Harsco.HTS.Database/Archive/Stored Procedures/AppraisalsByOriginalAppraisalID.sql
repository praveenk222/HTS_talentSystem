﻿-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/13/2012
-- 1598		1599
-- 7384		7503
-- =============================================
-- Exec [Archive].[AppraisalsByOriginalAppraisalID] 7901, 7782
CREATE PROCEDURE  [Archive].[AppraisalsByOriginalAppraisalID]
@OriginalAppraisalID int,
@ProfileId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

; WITH CTEPastAppraisals as(
	SELECT
		Appraisals.ArchiveAppraisalID, Appraisals.OriginalAppraisalID, Profiles.ArchiveProfileID, Profiles.OriginalProfileID, Appraisals.AppraisalType,
		convert(varchar(10),Appraisals.ArchiveAppraisalID) + ' - YearEnd' as FromWhere
	FROM
		Archive.Appraisals
		INNER JOIN Archive.Profiles ON Profiles.ArchiveAppraisalID = Appraisals.ArchiveAppraisalID
	WHERE
		OriginalAppraisalID = @OriginalAppraisalID
    
	UNION ALL
    
	--SELECT
	--	ArchiveMidYear, OriginalMidYearID, ArchivedProfileID, ArchivedProfileID, AppraisalTypes.Title,
	--	convert(varchar(10),ArchiveMidYear) + ' - MidYear' as FromWhere
	--from 
	--	Archive.MidYear
	--	INNER JOIN dbo.Profiles ON Profiles.ProfileId = MidYear.ArchivedProfileId
	--	INNER JOIN dbo.AppraisalTypes ON AppraisalTypes.AppraisalTypeID = MidYear.AppraisalTypeID
	--WHERE
	--	ArchivedProfileID = @ProfileId
    
	--ORDER BY AppraisalType
	 SELECT
		min(ArchiveMidYear) , min(OriginalMidYearID) , ArchivedProfileID, ArchivedProfileID, AppraisalTypes.Title,
		convert(varchar(10),min(ArchiveMidYear)) + ' - MidYear' as FromWhere
	FROM 
		Archive.MidYear
		INNER JOIN dbo.Profiles ON Profiles.ProfileId = MidYear.ArchivedProfileId
		INNER JOIN dbo.AppraisalTypes ON AppraisalTypes.AppraisalTypeID = MidYear.AppraisalTypeID
	WHERE
		ArchivedProfileID =@ProfileId
    Group by ArchivedProfileID, ArchivedProfileID, AppraisalTypes.Title
	)

    Select * from CTEPastAppraisals
	Order By AppraisalType DESC
END
SET NOCOUNT OFF
COMMIT TRANSACTION;
