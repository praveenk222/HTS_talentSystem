﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_CompetencySkillRatings_GetByID]
    @CompetencySkillRatingID int
AS
BEGIN
    SELECT CreatedOn, 
        CompetencySkillRatingID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM CompetencySkillRatings
    WHERE CompetencySkillRatingID = @CompetencySkillRatingID
    ORDER BY CreatedOn Desc
END