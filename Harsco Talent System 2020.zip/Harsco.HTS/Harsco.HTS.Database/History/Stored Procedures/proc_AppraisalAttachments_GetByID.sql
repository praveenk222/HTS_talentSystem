﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_AppraisalAttachments_GetByID]
    @AppraisalAttachmentID int
AS
BEGIN
    SELECT CreatedOn, 
        AppraisalAttachmentID, 
        AppraisalID, 
        AppraisalTimeStamp, 
        FileName, 
        FileSize, 
        ContentType, 
        Attachment, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM AppraisalAttachments
    WHERE AppraisalAttachmentID = @AppraisalAttachmentID
    ORDER BY CreatedOn Desc
END