﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_ObjectiveMilestones_GetByID]
    @ArchiveObjectiveMilestoneID int
AS
BEGIN
    SELECT ArchiveObjectiveMilestoneID, 
        ArchiveObjectiveID, 
        Title, 
        DateDue, 
        MilestoneStatus, 
        ModifiedBy, 
        ModifiedOn
    FROM ObjectiveMilestones
    WHERE ArchiveObjectiveMilestoneID = @ArchiveObjectiveMilestoneID
END