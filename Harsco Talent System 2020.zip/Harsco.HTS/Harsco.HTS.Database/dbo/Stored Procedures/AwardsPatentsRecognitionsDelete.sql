﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/24/2012
-- =============================================
CREATE PROCEDURE [dbo].[AwardsPatentsRecognitionsDelete]

@AwardPatentRecognitionID int

AS

BEGIN

	DELETE FROM dbo.AwardsPatentsRecognitions
	WHERE AwardPatentRecognitionID = @AwardPatentRecognitionID
	
END