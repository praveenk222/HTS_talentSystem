﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalRatings_Delete]

@Id int,
@ModifiedBy nvarchar(50)

AS

BEGIN

	UPDATE AppraisalRatings
	SET	IsDeleted = 1, 
		ModifiedBy = @ModifiedBy, 
		ModifiedOn = getdate()
	WHERE Id = @ID

END