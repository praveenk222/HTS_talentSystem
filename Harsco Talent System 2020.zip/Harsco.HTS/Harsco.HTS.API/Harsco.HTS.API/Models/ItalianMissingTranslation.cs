﻿using System;
using System.Collections.Generic;

namespace Harsco.HTS.API.Models
{
    public partial class ItalianMissingTranslation
    {
        public string KeyPhrase { get; set; }
        public string EnglishText { get; set; }
        public string F3 { get; set; }
    }
}
