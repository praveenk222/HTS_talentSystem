﻿CREATE TABLE [History].[HumanResource] (
    [CreatedOn]     DATETIME     NOT NULL,
    [Id]            INT          NOT NULL,
    [AppraisalId]   INT          NOT NULL,
    [SendToHr]      DATETIME     NULL,
    [SendToManager] DATETIME     NULL,
    [Comments]      NTEXT        NULL,
    [CreatedBy]     VARCHAR (50) NOT NULL,
    [Created]       DATETIME     NOT NULL,
    [ModifiedBy]    VARCHAR (50) NOT NULL,
    [ModifiedOn]    DATETIME     NOT NULL,
    CONSTRAINT [PK_HumanResource_2] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [Id] ASC)
);

