﻿  

-- =============================================================================  
-- Author:  Ed Blair  
-- Create date: 04/02/2013   
-- Modifications:  
--  
-- =============================================================================  
CREATE PROCEDURE  [dbo].[AppraisalArchiveMidYear]  
  
@ProfileId int,  
@AppraisalID int,  
@ModifiedBy nvarchar(50)  
  
AS  
  
BEGIN  
 SET NOCOUNT ON;  
  
    BEGIN TRANSACTION  
  
    BEGIN TRY    
  INSERT INTO Archive.MidYear  
   (OriginalMidYearID, ArchivedProfileID, AppraisalTypeID, EmpObjective, MgrObjective, EmpValueBehavior, MgrValueBehavior, EmpDevelopmentPlan,  
   MgrDevelopmentPlan, ReviewDate, EmpSignDate, EmployeeName, MgrSignDate, ManagerName,  
   CreatedBy, Created, ModifiedBy, ModifiedOn)  
  SELECT MidYearId, @ProfileID,  AppraisalTypeID, EmpObjective, MgrObjective, EmpValueBehavior, MgrValueBehavior, EmpDevelopmentPlan,  
   MgrDevelopmentPlan, ReviewDate, EmpSignDate, EmployeeName, MgrSignDate, ManagerName, CreatedBy, CreatedOn, @ModifiedBy, ModifiedOn  
   FROM MidYear   
   WHERE MidYear.ProfileID = @ProfileID  
     
  DELETE FROM MidYear   
  WHERE MidYear.ProfileID = @ProfileID  
    
  UPDATE Appraisals  
        SET AppraisalTypeID = AppraisalTypeID + 1,  
   COCViolation = '',  
   ManagerMeeting = '',  
            PerformanceRating = NULL,  
            CompetencyRating = NULL,  
            OverallRating = NULL,  
            ObjectiveComment = NULL,  
            CompetencyComment = NULL,  
            SkillComment = NULL,  
            ReviewDate = NULL,  
            SelfAssessmentComplete = 0,  
            ManagerStepComplete = 0,  
            EmployeeComment = NULL,  
            ManagerComment = NULL,  
            EmployeeName = NULL,  
            EmployeeSignDate = NULL,  
            ManagerName = NULL,  
            ManagerSignDate = NULL,  
            ManagersManagerName = NULL,  
            ManagersManagerSignDate = NULL,  
            ModifiedBy = 'Archive Process'  
          WHERE AppraisalID = @AppraisalID  
  
  select 'true'

        COMMIT TRANSACTION  
    END TRY  
    BEGIN CATCH  
        DECLARE @ErrorMessage NVARCHAR(4000),  
            @ErrorNumber INT,  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(200)  
  
            -- Assign variables to error-handling functions that  
            -- capture information for RAISERROR.  
        SELECT  @ErrorNumber = ERROR_NUMBER(), @ErrorSeverity = ERROR_SEVERITY(),  
                @ErrorState = ERROR_STATE(), @ErrorLine = ERROR_LINE(),  
                @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-') ;  
  
            -- Building the message string that will contain original  
            -- error information.  
        SELECT  @ErrorMessage = N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' +  
                'Message: ' + ERROR_MESSAGE() ;  
  
            -- Raise an error: msg_str parameter of RAISERROR will contain  
            -- the original error information.  
        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState, @ErrorNumber, -- parameter: original error number.  
          @ErrorSeverity, -- parameter: original error severity.  
          @ErrorState, -- parameter: original error state.  
          @ErrorProcedure, -- parameter: original error procedure name.  
          @ErrorLine-- parameter: original error line number.  
                ) ;  
        ROLLBACK TRANSACTION  
        RETURN 50001  
    END CATCH  
END