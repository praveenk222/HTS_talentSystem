﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 5/1/2013
-- =============================================
CREATE PROCEDURE [dbo].[CommunicationsLogSingleById]

@Id int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CommunicationsLogID, AppraisalID, Recipients, [Subject], Body, DateSent, ModifiedBy, ModifiedOn
    FROM CommunicationsLog
    WHERE CommunicationsLogID = @Id
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;