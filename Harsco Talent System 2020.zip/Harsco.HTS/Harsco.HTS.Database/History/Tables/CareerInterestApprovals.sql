﻿CREATE TABLE [History].[CareerInterestApprovals] (
    [CreatedOn]                DATETIME      CONSTRAINT [DF_CareerInterestApprovals_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CareerInterestApprovalID] INT           NOT NULL,
    [CareerInterestID]         INT           NOT NULL,
    [CareerInterestTimeStamp]  BINARY (8)    NOT NULL,
    [ApprovalStatusID]         INT           NOT NULL,
    [ApprovalStatusTimeStamp]  BINARY (8)    NOT NULL,
    [Comment]                  NTEXT         NULL,
    [StatusChangedDate]        DATETIME      NULL,
    [ApproverName]             NVARCHAR (75) NOT NULL,
    [ApproverID]               NVARCHAR (20) NOT NULL,
    [ModifiedBy]               NVARCHAR (50) NOT NULL,
    [ModifiedOn]               DATETIME      NOT NULL,
    [TimeStamp]                BINARY (50)   NOT NULL,
    CONSTRAINT [PK_CareerInterestApprovals] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CareerInterestApprovalID] ASC)
);

