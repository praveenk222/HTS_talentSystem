﻿  
  
  
-- =============================================  
-- Author:  Ed Blair  
-- Create date: 10/20/2017  
-- Description:   
--  [dbo].[DevelopmentPlanDetailsWithDescriptionsByDevelopmentPlanID] 21185  
-- =============================================  
CREATE PROCEDURE [dbo].[DevelopmentPlanDetailsWithDescriptionsByDevelopmentPlanID]  
  
@DevelopmentPlanID int  
  
AS  
  
BEGIN  
    SELECT DevelopmentPlanDetailID,   
        DevelopmentPlanID,   
        Category,   
        Objective,   
        Activity,   
        SupportRequired,   
        DateDue,   
        MeasurementProcess,   
        CompletionId,  
  PointOfEntryId,  
  ActivityLoopId,  
  DevelopmentLoopId,  
  CompletionDate,  
  Result,
        DevelopmentPlanDetails.CreatedBy,   
        DevelopmentPlanDetails.CreatedOn,  
        DevelopmentPlanDetails.ModifiedBy,   
        DevelopmentPlanDetails.ModifiedOn,  
  PointOfEntry.Description as PointofEntryDesc  
    FROM DevelopmentPlanDetails  
  LEFT OUTER JOIN PointOfEntry ON PointOfEntry.Id = DevelopmentPlanDetails.PointOfEntryId  
    WHERE DevelopmentPlanID = @DevelopmentPlanID  
END