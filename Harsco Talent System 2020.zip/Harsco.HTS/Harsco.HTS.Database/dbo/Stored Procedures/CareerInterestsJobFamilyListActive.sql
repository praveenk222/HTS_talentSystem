﻿
-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 10/02/2012
-- =============================================
CREATE PROCEDURE [dbo].[CareerInterestsJobFamilyListActive]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT Id, JobFamily, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM CareerInterestsJobFamily
	WHERE IsDeleted = 0
	Order by JobFamily
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;