﻿CREATE TABLE [History].[NextYearPreliminaryObjectives] (
    [CreatedOn]          DATETIME     NOT NULL,
    [Id]                 INT          NOT NULL,
    [AppraisalId]        INT          NOT NULL,
    [NextYearObjectives] NTEXT        NOT NULL,
    [CreatedBy]          VARCHAR (50) NOT NULL,
    [Created]            DATETIME     NOT NULL,
    [ModifiedBy]         VARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME     NOT NULL,
    CONSTRAINT [PK_NextYearPreliminaryObjectives_2] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [Id] ASC)
);

