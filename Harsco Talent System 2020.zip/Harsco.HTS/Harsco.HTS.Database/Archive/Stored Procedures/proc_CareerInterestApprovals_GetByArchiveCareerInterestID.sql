﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_CareerInterestApprovals_GetByArchiveCareerInterestID]
    @ArchiveCareerInterestID int
AS
BEGIN
    SELECT ArchiveCareerInterestApprovalID, 
        ArchiveCareerInterestID, 
        ApprovalStatus, 
        Comment, 
        StatusChangeDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM CareerInterestApprovals
    WHERE ArchiveCareerInterestID = @ArchiveCareerInterestID
END