﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 8/16/2012
-- =============================================
CREATE PROCEDURE [dbo].[CareerInterestTimingActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CareerInterestTiming.CareerInterestTimingID, ISNULL(Translations.TranslatedText,CareerInterestTiming.Title) as Title
    FROM CareerInterestTiming
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = CareerInterestTiming.Title
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = Translations.TranslationLanguageId
			and Code = @TranslationCode
	WHERE IsDeleted = 0
	ORDER BY ISNULL(Translations.TranslatedText,CareerInterestTiming.Title)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;