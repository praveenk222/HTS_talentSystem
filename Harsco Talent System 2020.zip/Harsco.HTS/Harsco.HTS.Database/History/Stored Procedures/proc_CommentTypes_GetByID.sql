﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_CommentTypes_GetByID]
    @CommentTypeID int
AS
BEGIN
    SELECT CreatedOn, 
        CommentTypeID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM CommentTypes
    WHERE CommentTypeID = @CommentTypeID
    ORDER BY CreatedOn Desc
END