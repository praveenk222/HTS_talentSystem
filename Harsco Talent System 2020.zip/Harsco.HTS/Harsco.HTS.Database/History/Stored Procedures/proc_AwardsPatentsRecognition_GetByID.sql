﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_AwardsPatentsRecognition_GetByID]
    @AwardPatentRecognitionID int
AS
BEGIN
    SELECT CreatedOn, 
        AwardPatentRecognitionID, 
        EmployeeProfileID, 
        EmployeeProfileTimeStamp, 
        Description, 
        DateReceived, 
        ReferenceNumber, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM AwardsPatentsRecognition
    WHERE AwardPatentRecognitionID = @AwardPatentRecognitionID
    ORDER BY CreatedOn Desc
END