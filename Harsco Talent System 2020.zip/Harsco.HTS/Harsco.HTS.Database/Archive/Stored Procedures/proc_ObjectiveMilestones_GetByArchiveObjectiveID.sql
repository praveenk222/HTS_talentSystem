﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_ObjectiveMilestones_GetByArchiveObjectiveID]
    @ArchiveObjectiveID int
AS
BEGIN
    SELECT ArchiveObjectiveMilestoneID, 
        ArchiveObjectiveID, 
        Title, 
        DateDue, 
        MilestoneStatus, 
        ModifiedBy, 
        ModifiedOn
    FROM ObjectiveMilestones
    WHERE ArchiveObjectiveID = @ArchiveObjectiveID
END