﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_ObjectiveApprovals_GetByArchiveObjectiveID]
    @ArchiveObjectiveID int
AS
BEGIN
    SELECT ArchiveObjectiveApprovalID, 
        ArchiveObjectiveID, 
        ArchiveObjectiveMilestoneID, 
        ApprovalStatus, 
        Comment, 
        StatusChangedDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM ObjectiveApprovals
    WHERE ArchiveObjectiveID = @ArchiveObjectiveID
END