﻿
-- ==================================================================
-- Author:		Ed Blair
-- Create date: 08/08/2012
-- Description: 
-- 
-- Modifications:
-- [dbo].[AppraisalNeedsHRSignOff] 'rkuppili'
-- ==================================================================
CREATE PROCEDURE [dbo].[AppraisalNeedsHRSignOff] 
@CurrentProfileID varchar(50)
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN
	DECLARE @seeAll int

	DECLARE @CurrentUsername INT
	
	SELECT @CurrentUsername = NetworkID FROM Profiles WHERE ProfileID = @CurrentProfileID

	
	SELECT @seeAll=ISNULL(HRBP,0) 
	FROM [dbo].[HRUsers_New] H
		INNER JOIN [dbo].[HRPermissions_New] HP ON HP.HRUserId = H.HRUserId
	WHERE H.UserName = @CurrentUsername

	SELECT Profiles.EmployeeName, Appraisals.AppraisalId, ProfileID, Profiles.NetworkId
    FROM 
		dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		INNER JOIN HumanResource ON HumanResource.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN [dbo].[HRUsers_New] H ON H.UserName = Profiles.NetworkId
    WHERE 
		SelfAssessmentComplete = 1
		AND ManagerStepComplete = 0
		AND HumanResource.SendToHr IS NOT NULL
		AND HumanResource.SendToManager IS NULL
		AND Profiles.Networkid NOT IN ('removed','Duplicate','pdecker')
		AND Profiles.Networkid NOT IN (SELECT NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND Profiles.TerminationDate IS NULL		
		AND Profiles.NetWorkId in (
		SELECT NetWorkId FROM Profiles
		WHERE EXISTS(
			SELECT H.HRUserId
			FROM [dbo].[HRUsers_New] H
				INNER JOIN [dbo].[HRPermissions_New] HP ON HP.HRUserId = H.HRUserId 
				AND userName = @CurrentUsername
			WHERE 
			(
				Profiles.DivisionID =  BusinessGroupID 
				AND CountryId = Profiles.CountryID
			)
			OR 
			(
				@seeAll = 1 AND	(H.HRUserId IS NOT NULL AND Profiles.DivisionID != 14)
			)
			--(Profiles.DivisionID =  BusinessGroupID AND CountryId is Null)
			--OR (Profiles.DivisionID =  BusinessGroupID AND CountryId = Profiles.CountryID)
			--OR (@seeAll = 1 AND ( HRUsers.HRUserId IS NOT NULL AND Profiles.DivisionID != 14 ))
		)
	)
 
END
SET NOCOUNT OFF
COMMIT TRANSACTION;