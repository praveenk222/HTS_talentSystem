﻿CREATE TABLE [History].[TrainingDevelopment] (
    [CreatedOn]             DATETIME      CONSTRAINT [DF_TrainingDevelopment_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [TrainingDevelopmentID] INT           NOT NULL,
    [EmployeeProfileID]     INT           NOT NULL,
    [Description]           NTEXT         NOT NULL,
    [TrainingCategoryID]    INT           NOT NULL,
    [TrainingCategoryOther] NVARCHAR (75) NULL,
    [CertificationNumber]   NVARCHAR (20) NULL,
    [YearObtained]          INT           NULL,
    [ExpirationDate]        SMALLDATETIME NULL,
    [ModifiedBy]            NVARCHAR (50) NOT NULL,
    [ModifiedOn]            DATETIME      NOT NULL,
    [TimeStamp]             BINARY (50)   NOT NULL,
    CONSTRAINT [PK_TrainingDevelopment] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [TrainingDevelopmentID] ASC)
);



