﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [ApiController]
    [Route("[controller]")]
    public class MidYearAppraisalController : ControllerBase
    {
        [HttpGet]
        [Route("GetMidYearByID")]
        public IActionResult GetMidYearByID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                List<vmMidYear> midYearVMList = new List<vmMidYear>();

                var midyearDBList = db.MidYear.Where(p => p.ProfileId == profileID).ToList();
                var profileDB = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
                var objectiveDbList = db.Objectives.Where(p => p.AppraisalId == profileDB.AppraisalId).ToList();

                midyearDBList.ForEach(item =>
                {
                    vmMidYear midYearVM = new vmMidYear();
                    item.BindModelTo(midYearVM);

                    if (item.ObjectiveId != null)
                    {
                        var objective = objectiveDbList.Find(p => p.ObjectiveId == item.ObjectiveId);
                        if(objective != null)
						{
                            midYearVM.Objective = new vmObjective();
                            objective.BindModelTo(midYearVM.Objective);
                            midYearVMList.Add(midYearVM);
                        }
                    }
                    
                });

                return Ok(midYearVMList);
            }
        }

        [HttpGet]
        [Route("CheckIfMidYearValid")]
        public IActionResult CheckIfMidYearValid(int appraisalID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var profileDb = db.Profiles.Where(p => p.AppraisalId == appraisalID).SingleOrDefault();
                //objectives section
                var objectives = db.Objectives.Where(p => p.AppraisalId == appraisalID).ToList();

                List<int> objectiveIDs = objectives.Select(x => x.ObjectiveId).ToList();

                var objectiveApprovals = (from c in db.ObjectiveApprovals
                                          where objectiveIDs.Contains((int)c.ObjectiveId)
                                          select c).ToList();

                bool objectivesNotApproved = objectiveApprovals.Any(p => p.ApprovalStatusId != 2);

                //values section
                bool ValuesNotFilled = db.MidYearEmpMgrValues.Where(p => p.ProfileId == profileDb.ProfileId).Any(q => (q.EmpValueBehavior == null) && (q.MgrValueBehavior == null));

                //Dev plan section
                bool DevPlanNotFilled = db.MidYearEmpMgrDevPlan.Where(p => p.ProfileId == profileDb.ProfileId).Any(q => (q.EmpDevPlan == null) && (q.MgrDevPlan == null));

                //self assesment completed
                var selfAssessmentCompleted = db.MidYear.Where(p => p.ProfileId == profileDb.ProfileId).Any(q => q.EmpSignDate != null);

                //manager signed
                var managerSignedOff = db.MidYear.Where(p => p.ProfileId == profileDb.ProfileId).Any(q => q.MgrSignDate != null);
                return Ok(new
                {
                    objectivesNotApproved,
                    ValuesNotFilled,
                    DevPlanNotFilled,
                    selfAssessmentCompleted,
                    managerSignedOff
                });
            }
        }

        [HttpGet]
        [Route("CheckIfMidYearSubmitted")]
        public IActionResult CheckIfMidYearSubmitted(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                //var midYear = db.MidYear.Where(p =>  p.ProfileId == profileID).ToList();
                bool notSubmitted = db.MidYear.Any(p => p.ProfileId == profileID && p.ReviewDate == null);

                return Ok(new { status = notSubmitted });
            }
        }

        [HttpGet]
        [Route("GetValues")]
        public IActionResult GetValues()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var midyearEmpMgrValues = db.EnterpriseCompetencies.Where(p => p.EnterpriseCompetencyId >= 17 && p.EnterpriseCompetencyId <= 22).ToList();

                return Ok(midyearEmpMgrValues);
            }
        }

        [HttpGet]
        [Route("GetMidYearValuesByID")]
        public IActionResult GetMidYearValuesByID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var midyearEmpMgrValuesCount = db.MidYearEmpMgrValues.Where(p => p.ProfileId == profileID).Count();
                if (midyearEmpMgrValuesCount == 0)
                {
                    CreateEmpMgrValuesByProfileID(profileID);
                    var midyearEmpMgrValuesDB = db.MidYearEmpMgrValues.Where(p => p.ProfileId == profileID).ToList();
                    return Ok(midyearEmpMgrValuesDB);
                }
                else
                {
                    var midyearEmpMgrValuesDB = db.MidYearEmpMgrValues.Where(p => p.ProfileId == profileID).ToList();
                    return Ok(midyearEmpMgrValuesDB);
                }
            }
        }

        [HttpGet]
        [Route("GetMidYearDevPlanByID")]
        public IActionResult GetMidYearDevPlanByID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var midyearEmpMgrValuesCount = db.MidYearEmpMgrDevPlan.Where(p => p.ProfileId == profileID).Count();
                if (midyearEmpMgrValuesCount == 0)
                {
                    CreateEmpMgrDevPlanByProfileID(profileID);
                    var midyearEmpMgrDevPlanDBLst = db.MidYearEmpMgrDevPlan.Where(p => p.ProfileId == profileID).ToList();

                    List<vmMidYearEmpMgrDevPlan> midYearEmpMgrDevPlanVMLst = new List<vmMidYearEmpMgrDevPlan>();

                    midyearEmpMgrDevPlanDBLst.ForEach(item =>
                        {
                            vmMidYearEmpMgrDevPlan midYearEmpMgrDevPlanVM = new vmMidYearEmpMgrDevPlan();
                            item.BindModelTo(midYearEmpMgrDevPlanVM);
                            midYearEmpMgrDevPlanVMLst.Add(midYearEmpMgrDevPlanVM);
                            var devPlanDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanDetailId == item.DevPlanDetailId).SingleOrDefault();
                            midYearEmpMgrDevPlanVM.DevPlanDetails = new vmDevelopmentPlanDetails();
                            item.BindModelTo(midYearEmpMgrDevPlanVM.DevPlanDetails);
                        });

                    return Ok(midYearEmpMgrDevPlanVMLst);
                }
                else
                {
                    var midyearEmpMgrDevPlanDBLst = db.MidYearEmpMgrDevPlan.Where(p => p.ProfileId == profileID).ToList();
                    List<vmMidYearEmpMgrDevPlan> midYearEmpMgrDevPlanVMLst = new List<vmMidYearEmpMgrDevPlan>();
                    midyearEmpMgrDevPlanDBLst.ForEach(item =>
                    {
                        vmMidYearEmpMgrDevPlan midYearEmpMgrDevPlanVM = new vmMidYearEmpMgrDevPlan();
                        item.BindModelTo(midYearEmpMgrDevPlanVM);
                        midYearEmpMgrDevPlanVMLst.Add(midYearEmpMgrDevPlanVM);
                        var devPlanDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanDetailId == item.DevPlanDetailId).SingleOrDefault();
                        midYearEmpMgrDevPlanVM.DevPlanDetails = new vmDevelopmentPlanDetails();
                        devPlanDetailsDB.BindModelTo(midYearEmpMgrDevPlanVM.DevPlanDetails);
                    });
                    return Ok(midYearEmpMgrDevPlanVMLst);
                }
            }
        }

        private void CreateEmpMgrValuesByProfileID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var profileDB = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
                var managerProfileDB = db.Profiles.Where(p => p.ProfileId == profileDB.ManagerId).SingleOrDefault();
                List<MidYearEmpMgrValues> EmpMgrValuesList = new List<MidYearEmpMgrValues>();
                Appraisals appraisals = db.Appraisals.Where(a => a.AppraisalId == profileDB.AppraisalId).SingleOrDefault();

                for (int i = 11; i <= 16; i++)
                {
                    MidYearEmpMgrValues midYearEmpMgrValues = new MidYearEmpMgrValues();
                    midYearEmpMgrValues.ProfileId = profileID;
                    midYearEmpMgrValues.AppraisalTypeId = appraisals.AppraisalTypeId;// 17;
                    midYearEmpMgrValues.EnterpriseCompetencyId = i;
                    midYearEmpMgrValues.EmployeeName = profileDB.EmployeeName;
                    midYearEmpMgrValues.ManagerName = managerProfileDB.EmployeeName;
                    midYearEmpMgrValues.CreatedBy = profileDB.NetworkId;
                    midYearEmpMgrValues.ModifiedBy = profileDB.NetworkId;
                    midYearEmpMgrValues.CreatedOn = DateTime.Now;
                    midYearEmpMgrValues.ModifiedOn = DateTime.Now;

                    EmpMgrValuesList.Add(midYearEmpMgrValues);
                }

                db.MidYearEmpMgrValues.AddRange(EmpMgrValuesList);
                db.SaveChanges();
            }
        }

        private void CreateEmpMgrDevPlanByProfileID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var profileDB = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
                var managerProfileDB = db.Profiles.Where(p => p.ProfileId == profileDB.ManagerId).SingleOrDefault();
                List<MidYearEmpMgrDevPlan> EmpMgrDevPlanList = new List<MidYearEmpMgrDevPlan>();

                var devPlanDB = db.DevelopmentPlans.Where(p => p.AppraisalId == profileDB.AppraisalId).SingleOrDefault();
                if (devPlanDB != null)
                {
                    var devPlanDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanId == devPlanDB.DevelopmentPlanId).ToList();

                    Appraisals appraisals = db.Appraisals.Where(a => a.AppraisalId == profileDB.AppraisalId).SingleOrDefault();

                    for (int i = 0; i < devPlanDetailsDB.Count; i++)
                    {
                        MidYearEmpMgrDevPlan midYearEmpMgrDevPlan = new MidYearEmpMgrDevPlan();
                        midYearEmpMgrDevPlan.ProfileId = profileID;
                        midYearEmpMgrDevPlan.DevPlanDetailId = devPlanDetailsDB[i].DevelopmentPlanDetailId;
                        midYearEmpMgrDevPlan.AppraisalTypeId = appraisals.AppraisalTypeId; // 17;
                        midYearEmpMgrDevPlan.EmployeeName = profileDB.EmployeeName;
                        midYearEmpMgrDevPlan.ManagerName = managerProfileDB.EmployeeName;
                        midYearEmpMgrDevPlan.CreatedBy = profileDB.NetworkId;
                        midYearEmpMgrDevPlan.ModifiedBy = profileDB.NetworkId;
                        midYearEmpMgrDevPlan.CreatedOn = DateTime.Now;
                        midYearEmpMgrDevPlan.ModifiedOn = DateTime.Now;

                        EmpMgrDevPlanList.Add(midYearEmpMgrDevPlan);
                    }
                }

                db.MidYearEmpMgrDevPlan.AddRange(EmpMgrDevPlanList);
                db.SaveChanges();
            }
        }

        [HttpPost]
        [Route("UpdateMidYearEmpMgrValues")]
        public IActionResult UpdateMidYearEmpMgrValues(vmMidYearEmpMgrValues midYearEmpMgrValuesVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var midYearValsDb = db.MidYearEmpMgrValues.Where(p => p.MidYearEmpValuesId == midYearEmpMgrValuesVM.MidYearEmpValuesId).SingleOrDefault();

                midYearEmpMgrValuesVM.BindModelTo(midYearValsDb);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("UpdateMidYearEmpMgrDevPlan")]
        public IActionResult UpdateMidYearEmpMgrDevPlan(vmMidYearEmpMgrDevPlan midYearEmpMgrDevPlanVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var midYearDevPlanDb = db.MidYearEmpMgrDevPlan.Where(p => p.MidYearEmpMgrDevId == midYearEmpMgrDevPlanVM.MidYearEmpMgrDevId).SingleOrDefault();

                midYearEmpMgrDevPlanVM.BindModelTo(midYearDevPlanDb);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("CreateMidYearValuesAndDevPlan")]
        public IActionResult CreateMidYearValuesAndDevPlan(vmMidYearEmpMgrValues midYearEmpValuesDevmtPlanVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {

                Appraisals appraisals = db.Appraisals.Where(a => a.AppraisalId == midYearEmpValuesDevmtPlanVM.DisplayUser.AppraisalId).SingleOrDefault();

                MidYearEmpValuesDevmtPlan midYearEmpValuesDevmtPlanDB = new MidYearEmpValuesDevmtPlan();
                midYearEmpValuesDevmtPlanVM.BindModelTo(midYearEmpValuesDevmtPlanDB);

                midYearEmpValuesDevmtPlanDB.ProfileId = midYearEmpValuesDevmtPlanVM.DisplayUser.ProfileId;
                midYearEmpValuesDevmtPlanDB.AppraisalTypeId = appraisals.AppraisalTypeId; // 17; //need to change
                midYearEmpValuesDevmtPlanDB.CreatedOn = DateAndTime.Now;
                midYearEmpValuesDevmtPlanDB.ModifiedOn = DateAndTime.Now;
                midYearEmpValuesDevmtPlanDB.CreatedBy = midYearEmpValuesDevmtPlanVM.LoggedInUser.NetworkId;
                midYearEmpValuesDevmtPlanDB.ModifiedBy = midYearEmpValuesDevmtPlanVM.LoggedInUser.NetworkId;

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("UpdateMidYear")]
        public IActionResult UpdateMidYear(vmMidYear midYearVm)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var MidYearDb = db.MidYear.Where(p => p.ObjectiveId == midYearVm.ObjectiveId && p.ProfileId == midYearVm.ProfileId).SingleOrDefault();

                midYearVm.BindModelTo(MidYearDb);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("SubmitMidYearByEmployee")]
        public IActionResult SubmitMidYearByEmployee(vmMidYearSubmit vmMidYearSubmit)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var profileDb = db.Profiles.Where(p => p.ProfileId == vmMidYearSubmit.LoggedInUser.ProfileId).SingleOrDefault();
                var midYearLstDb = db.MidYear.Where(p => p.ProfileId == vmMidYearSubmit.DisplayUser.ProfileId).ToList();
                if (midYearLstDb != null)
                {
                    midYearLstDb.ForEach(item =>
                    {
                        item.EmpSignDate = DateTime.UtcNow;
                        item.EmployeeName = profileDb.EmployeeName;
                    });
                    db.SaveChanges();
                }

                return Ok(new { status = "Success" });
            }
        }

        [HttpGet]
        [Route("ReturnToEmployee")]
        public IActionResult ReturnToEmployee(int ProfileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                List<MidYear> MidYearList = db.MidYear.Where(p => p.ProfileId == ProfileID).ToList();
				if(MidYearList!=null)
				{
                    MidYearList.ForEach(a => a.EmpSignDate = null);
                    MidYearList.ForEach(a => a.EmployeeName = null);
                    db.SaveChanges();
                }

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("SubmitMidYearByManager")]
        public IActionResult SubmitMidYearByManager(vmMidYearSubmit vmMidYearSubmit)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var managerProfileDb = db.Profiles.Where(p => p.ProfileId == vmMidYearSubmit.LoggedInUser.ProfileId).SingleOrDefault();
                var midYearLstDb = db.MidYear.Where(p => p.ProfileId == vmMidYearSubmit.DisplayUser.ProfileId).ToList();
                if (midYearLstDb != null)
                {
                    midYearLstDb.ForEach(item =>
                    {
                        item.MgrSignDate = DateTime.UtcNow;
                        item.ReviewDate = vmMidYearSubmit.Objectives[0].ReviewDate;
                        item.ManagerName = managerProfileDb.EmployeeName;
                    });
                    db.SaveChanges();
                }

                //call archival procedure
                var connectionString = db.Database.GetDbConnection().ConnectionString;
                DataSet ds = new DataSet();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("[dbo].[MidYearAppraisalArchiveProcess]", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProfileId", vmMidYearSubmit.DisplayUser.ProfileId);
                    cmd.Parameters.AddWithValue("@AppraisalID", vmMidYearSubmit.DisplayUser.AppraisalId);
                    cmd.Parameters.AddWithValue("@AppraisalTypeID", vmMidYearSubmit.Objectives[0].AppraisalTypeId);
                    cmd.Parameters.AddWithValue("@ModifiedBy", vmMidYearSubmit.LoggedInUser.NetworkId);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(ds);
                    conn.Close();
                }

                return Ok(new { status = "Success" });
            }
        }

        [HttpGet]
        [Route("GetDevPlanDetails")]
        public IActionResult GetDevPlanDetails(int appraisalID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var devPlanDB = db.DevelopmentPlans.Where(p => p.AppraisalId == appraisalID).SingleOrDefault();
                var devPlanDetailsDB = db.DevelopmentPlanDetails.Where(p => p.DevelopmentPlanId == devPlanDB.DevelopmentPlanId).ToList();
                return Ok(devPlanDetailsDB);
            }
        }

        [HttpGet]
        [Route("GetEmpobjTaskStatus")]
        public IActionResult GetTaskStatus(int profileID)
        {
            using(Performance_ManagmentContextDbo db=new Performance_ManagmentContextDbo())
            {
                //var empTaskstatuses = db.tbl_EmpTaskstatus.Where(p=> p.ProfileID==profileID);
                var empTaskstatuses = db.tbl_EmpTaskstatus.FromSqlRaw("proc_EmpObjTaskStatus_List {0}",profileID).ToList();

                return Ok(empTaskstatuses);
            }
        }
        [HttpPost]
        [Route("saveEmptaskStaus")]
        public IActionResult SaveEmptaskStaus(tbl_EmpTaskstatus vmTaskstatus)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                try
                {
                    var existingEntity = db.tbl_EmpTaskstatus.Where(x=>x.ObjectiveId == vmTaskstatus.ObjectiveId).FirstOrDefault();
                    if (existingEntity != null)
                    {  // Update 
                        existingEntity.StatusID= vmTaskstatus.StatusID;
                        existingEntity.StatusComments=vmTaskstatus.StatusComments;
                        db.Entry(existingEntity).State = EntityState.Modified;
                    }
                    else
                    {
                        // Insert
                        db.tbl_EmpTaskstatus.Add(vmTaskstatus);
                    }
                    db.SaveChanges();
                    return Ok(new { status = "Success" });
                }
                catch (Exception ex)
                {

                    throw ex;
                }

               
            }
        }

    }
}
