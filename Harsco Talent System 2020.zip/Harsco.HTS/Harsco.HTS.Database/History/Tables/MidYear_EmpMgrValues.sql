﻿CREATE TABLE [History].[MidYear_EmpMgrValues] (
    [HistoryMidYearEmpValuesID] INT            IDENTITY (1, 1) NOT NULL,
    [MidYearEmpValuesID]        INT            NULL,
    [ProfileID]                 INT            NOT NULL,
    [AppraisalTypeID]           INT            NOT NULL,
    [EnterpriseCompetencyID]    INT            NOT NULL,
    [EmpValueBehavior]          NTEXT          NULL,
    [MgrValueBehavior]          NTEXT          NULL,
    [ReviewDate]                DATETIME       NULL,
    [EmployeeName]              NVARCHAR (100) NULL,
    [ManagerName]               NVARCHAR (100) NULL,
    [CreatedBy]                 VARCHAR (50)   NOT NULL,
    [CreatedOn]                 DATETIME       NOT NULL,
    [ModifiedBy]                VARCHAR (50)   NOT NULL,
    [ModifiedOn]                DATETIME       NOT NULL,
    PRIMARY KEY CLUSTERED ([HistoryMidYearEmpValuesID] ASC)
);

