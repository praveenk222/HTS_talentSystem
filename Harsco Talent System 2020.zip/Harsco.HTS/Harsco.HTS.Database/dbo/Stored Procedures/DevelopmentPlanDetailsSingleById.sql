﻿  
  
  
-- =============================================  
-- AUTHOR: Shaun Kline  
-- CREATED DATE: 2009/06/24  
-- =============================================  
CREATE PROCEDURE [dbo].[DevelopmentPlanDetailsSingleById]  
  
@DevelopmentPlanDetailID int  
  
AS  
  
BEGIN  
    SELECT DevelopmentPlanDetailID,   
        DevelopmentPlanID,   
        Category,   
        Objective,   
        Activity,   
        SupportRequired,   
        DateDue,   
        MeasurementProcess,   
        CompletionId,  
  ISNULL(PointOfEntryId,0) as PointOfEntryId,  
  ISNULL(ActivityLoopId,0) as ActivityLoopId,  
  ISNULL(DevelopmentLoopId,0) as DevelopmentLoopId,  
        CompletionDate,  
        Result,  
		CreatedBy,   
        CreatedOn,          
        ModifiedBy,   
        ModifiedOn  
    FROM DevelopmentPlanDetails  
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID  
END