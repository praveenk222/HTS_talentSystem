﻿CREATE TABLE [Archive].[DevelopmentPlanApprovals] (
    [ArchiveDevelopmentPlanApprovalID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanApprovalID] INT           NOT NULL,
    [ArchiveDevelopmentPlanStrengthID]  INT           NULL,
    [ArchiveDevelopmentPlanWeaknessID]  INT           NULL,
    [ArchiveDevelopmentPlanDetailID]    INT           NULL,
    [Comment]                           NTEXT         NULL,
    [ApprovalStatus]                    NVARCHAR (50) NOT NULL,
    [StatusChangedDate]                 DATETIME      NULL,
    [ApproverName]                      NVARCHAR (75) NOT NULL,
    [ApproverID]                        NVARCHAR (20) NOT NULL,
    [ModifiedBy]                        NVARCHAR (50) NOT NULL,
    [ModifiedOn]                        DATETIME      CONSTRAINT [DF_DevelopmentPlanApprovals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanApprovals] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanApprovalID] ASC),
    CONSTRAINT [FK_DevelopmentPlanApprovals_DevelopmentPlanDetails] FOREIGN KEY ([ArchiveDevelopmentPlanDetailID]) REFERENCES [Archive].[DevelopmentPlanDetails] ([ArchiveDevelopmentPlanDetailID]),
    CONSTRAINT [FK_DevelopmentPlanApprovals_DevelopmentPlanStrengths] FOREIGN KEY ([ArchiveDevelopmentPlanStrengthID]) REFERENCES [Archive].[DevelopmentPlanStrengths] ([ArchiveDevelopmentPlanStrengthID]),
    CONSTRAINT [FK_DevelopmentPlanApprovals_DevelopmentPlanWeaknesses] FOREIGN KEY ([ArchiveDevelopmentPlanWeaknessID]) REFERENCES [Archive].[DevelopmentPlanWeaknesses] ([ArchiveDevelopmentPlanWeaknessID])
);


GO
CREATE TRIGGER [Archive].[tr_DevelopmentPlanApprovals_PreventChanges]     ON  Archive.DevelopmentPlanApprovals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END