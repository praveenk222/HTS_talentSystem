﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_CompetencyApprovals_GetByID]
    @CompetencyApprovalID int
AS
BEGIN
    SELECT CreatedOn, 
        CompetencyApprovalID, 
        CompetencyID, 
        CompetencyTimeStamp, 
        SkillID, 
        SkillTimeStamp, 
        ApprovalStatusID, 
        ApprovalStatusTimeStamp, 
        Comment, 
        StatusChangedDate, 
        ApproverName, 
        ApproverID, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM CompetencyApprovals
    WHERE CompetencyApprovalID = @CompetencyApprovalID
    ORDER BY CreatedOn Desc
END