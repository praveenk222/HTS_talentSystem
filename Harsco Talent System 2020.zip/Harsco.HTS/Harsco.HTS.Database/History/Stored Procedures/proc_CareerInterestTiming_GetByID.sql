﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_CareerInterestTiming_GetByID]
    @CareerInterestTimingID int
AS
BEGIN
    SELECT CreatedOn, 
        CareerInterestTimingID, 
        Title, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM CareerInterestTiming
    WHERE CareerInterestTimingID = @CareerInterestTimingID
    ORDER BY CreatedOn Desc
END