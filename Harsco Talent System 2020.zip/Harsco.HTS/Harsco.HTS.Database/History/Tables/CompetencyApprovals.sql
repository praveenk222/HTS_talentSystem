﻿CREATE TABLE [History].[CompetencyApprovals] (
    [CreatedOn]               DATETIME      CONSTRAINT [DF_CompetencyApprovals_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CompetencyApprovalID]    INT           NOT NULL,
    [CompetencyID]            INT           NULL,
    [CompetencyTimeStamp]     BINARY (8)    NULL,
    [SkillID]                 INT           NULL,
    [SkillTimeStamp]          BINARY (8)    NULL,
    [ApprovalStatusID]        INT           NOT NULL,
    [ApprovalStatusTimeStamp] BINARY (8)    NOT NULL,
    [Comment]                 NTEXT         NULL,
    [StatusChangedDate]       DATETIME      NULL,
    [ApproverName]            NVARCHAR (75) NOT NULL,
    [ApproverID]              NVARCHAR (20) NOT NULL,
    [ModifiedBy]              NVARCHAR (50) NOT NULL,
    [ModifiedOn]              DATETIME      NOT NULL,
    [TimeStamp]               BINARY (50)   NOT NULL,
    CONSTRAINT [PK_CompetencyApprovals] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CompetencyApprovalID] ASC)
);

