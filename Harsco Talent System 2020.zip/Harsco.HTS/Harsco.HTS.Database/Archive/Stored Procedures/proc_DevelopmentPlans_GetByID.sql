﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlans_GetByID]
    @ArchiveDevelopmentPlanID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanID, 
        ArchiveAppraisalID, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlans
    WHERE ArchiveDevelopmentPlanID = @ArchiveDevelopmentPlanID
END