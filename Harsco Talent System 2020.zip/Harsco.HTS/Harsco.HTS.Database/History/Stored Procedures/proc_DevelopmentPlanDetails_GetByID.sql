﻿


-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlanDetails_GetByID]
    @DevelopmentPlanDetailID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanDetailID, 
        DevelopmentPlanID, 
        DevelopmentPlanTimeStamp, 
        Category, 
        Objective, 
        Activity, 
        SupportRequired, 
        DateDue, 
        MeasurementProcess, 
        Completion,
		PointOfEntryId,
		ISNULL(ActivityLoopId,0) ActivityLoopId,
		DevelopmentLoopId,
		CompletionDate,  
        Result, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanDetails
    WHERE DevelopmentPlanDetailID = @DevelopmentPlanDetailID
    ORDER BY CreatedOn Desc
END