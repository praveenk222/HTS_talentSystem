﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
	[EnableCors("AllowOrigin")]
	[ApiController]
	[Route("[controller]")]
	public class MyActionsController : ControllerBase
	{
		[HttpGet]
		[Route("GetPendingObjectiveApprovals")]
		public IActionResult GetPendingObjectiveApprovals(string profileId)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				List<vmObjective> ObjectivesListVM = new List<vmObjective>();
				try
				{
					var networkId = db.Profiles.Find(Convert.ToInt32(profileId)).NetworkId;

					var objectiveApprovalsDB = db.ObjectiveApprovals
						.Include(obj => obj.Objective)
						.Where(obj => obj.ApproverId == networkId && obj.ApprovalStatusId == 1)
						.ToList();

					var approvals = objectiveApprovalsDB
						.OrderBy(x => x.ObjectiveApprovalId)
						.GroupBy(x => x.ObjectiveId)
						.Select(g => new { g, count = g.Count() })
						.SelectMany(t => t.g.Select(b => b)
						.Zip(Enumerable.Range(1, t.count), (j, i) => new { objectiveApproval = j, rowNumber = i }));

					approvals = approvals.Where(p => p.rowNumber == 1).ToList();

					Profiles mg = db.Profiles.Where(p => p.NetworkId == networkId).FirstOrDefault();

					var listapprovals = (from _approvals in approvals
										 join profs in db.Profiles.Where(x=>x.ManagerId == mg.ProfileId)
										 on _approvals.objectiveApproval.Objective.AppraisalId equals profs.AppraisalId
										 where profs.TerminationDate == null && !profs.NetworkId.Contains("removed")
										 select _approvals).ToList();

					foreach (var item in listapprovals)
					{
						vmObjective objectiveVM = new vmObjective();
						vmObjectiveApproval objectiveApprovalVm = new vmObjectiveApproval();

						item.objectiveApproval.Objective.BindModelTo(objectiveVM);
						objectiveVM.ObjectiveApprovals = new List<vmObjectiveApproval>();
						item.objectiveApproval.BindModelTo(objectiveApprovalVm);
						objectiveVM.ObjectiveApprovals.Add(objectiveApprovalVm);
						objectiveVM.ObjectiveOwnerProfile = GetProfileByAppraisalID(item.objectiveApproval.Objective.AppraisalId);
						ObjectivesListVM.Add(objectiveVM);
					}
				}
				catch (System.Exception)
				{

				}


				return Ok(ObjectivesListVM);
			}
		}

		[HttpPost]
		[Route("ApproveObjective")]
		public IActionResult ApproveObjective(vmObjective objectiveVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var objectiveApprovalDb = db.ObjectiveApprovals.Where(p => p.ObjectiveApprovalId == objectiveVM.ObjectiveApprovals[0].ObjectiveApprovalId).OrderBy(p => p.ObjectiveApprovalId).FirstOrDefault();

				objectiveApprovalDb.ApprovalStatusId = (int)ObjectiveApprovalStatus.Approved;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("RejectObjective")]
		public IActionResult RejectObjective(vmObjective objectiveVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var objectiveApprovalDb = db.ObjectiveApprovals.Where(p => p.ObjectiveApprovalId == objectiveVM.ObjectiveApprovals[0].ObjectiveApprovalId).OrderBy(p => p.ObjectiveApprovalId).FirstOrDefault();
				objectiveApprovalDb.Comment = objectiveVM.ObjectiveApprovals[0].Comment;

				objectiveApprovalDb.ApprovalStatusId = (int)ObjectiveApprovalStatus.Rejected;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpGet]
		[Route("GetPendingDevPlanApprovals")]
		public IActionResult GetPendingDevPlanApprovals(string profileId)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				List<vmDevelopmentPlanDetails> devPlanDetlsListVM = new List<vmDevelopmentPlanDetails>();
				
				var networkId = db.Profiles.Find(Convert.ToInt32(profileId)).NetworkId;

				var devPlanApprovalsDB = db.DevelopmentPlanApprovals.Where(obj => obj.ApproverId == networkId && obj.ApprovalStatusId == 1).ToList();

				var approvals = devPlanApprovalsDB.OrderBy(x => x.DevelopmentPlanDetailId).GroupBy(x => x.DevelopmentPlanDetailId)
							   .Select(g => new { g, count = g.Count() })
							   .SelectMany(t => t.g.Select(b => b)
												   .Zip(Enumerable.Range(1, t.count), (j, i) => new { devPlanApproval = j, rowNumber = i }));

				approvals = approvals.Where(p => p.rowNumber == 1).ToList();

				foreach (var item in approvals)
				{
					vmDevelopmentPlanDetails devPlanDetailVm = new vmDevelopmentPlanDetails();
					var devPlanDetailDb = db.DevelopmentPlanDetails.Include(p => p.DevelopmentPlan).Where(p => p.DevelopmentPlanDetailId == item.devPlanApproval.DevelopmentPlanDetailId).FirstOrDefault();

					Profiles _profiles = db.Profiles.Where(x => x.AppraisalId.Equals(devPlanDetailDb.DevelopmentPlan.AppraisalId) && x.TerminationDate == null && !x.NetworkId.Contains("removed")).FirstOrDefault();
					if (_profiles != null)
					{
						devPlanDetailDb.BindModelTo(devPlanDetailVm);
						devPlanDetailVm.DevelopmentPlanApproval = new vmDevelopmentPlanApprovals();
						item.devPlanApproval.BindModelTo(devPlanDetailVm.DevelopmentPlanApproval);

						devPlanDetailVm.ObjectiveOwnerProfile = GetProfileByAppraisalID(devPlanDetailDb.DevelopmentPlan.AppraisalId);
						devPlanDetlsListVM.Add(devPlanDetailVm);
					}
				}
				return Ok(devPlanDetlsListVM);
			}
		}

		[HttpPost]
		[Route("ApproveDevPlan")]
		public IActionResult ApproveDevPlan(vmDevelopmentPlanDetails developmentPlanDetailsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var devPlanApprovalDb = db.DevelopmentPlanApprovals.Where(p => p.DevelopmentPlanDetailId == developmentPlanDetailsVM.DevelopmentPlanApproval.DevelopmentPlanDetailId).OrderByDescending(p => p.DevelopmentPlanApprovalId).FirstOrDefault();

				devPlanApprovalDb.ApprovalStatusId = (int)ObjectiveApprovalStatus.Approved;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("RejectDevPlan")]
		public IActionResult RejectDevPlan(vmDevelopmentPlanDetails developmentPlanDetailsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var devPlanApprovalDb = db.DevelopmentPlanApprovals.Where(p => p.DevelopmentPlanDetailId == developmentPlanDetailsVM.DevelopmentPlanApproval.DevelopmentPlanDetailId).OrderByDescending(p => p.DevelopmentPlanApprovalId).FirstOrDefault();
				devPlanApprovalDb.Comment = developmentPlanDetailsVM.DevelopmentPlanApproval.Comment;
				devPlanApprovalDb.ApprovalStatusId = (int)ObjectiveApprovalStatus.Rejected;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		private vmProfile GetProfileByAppraisalID(int appraisalID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				vmProfile profileModel = new vmProfile();
				var profileDB = db.Profiles.Where(p => p.AppraisalId == appraisalID && p.TerminationDate == null && !p.NetworkId.ToLower().Contains("remove")).SingleOrDefault();
				profileDB.BindModelTo(profileModel);

				return profileModel;
			}
		}

		[HttpGet]
		[Route("GetPendingSelfAssessmentApprovals")]
		public IActionResult GetPendingSelfAssessmentApprovals(string profileId)
		{
			//networkId = "rasurati1";
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var selfAssessmentApprovals = db._AppraisalsSelfAssessmentNeedsManangerStepSP.FromSqlRaw("AppraisalsSelfAssessmentNeedsManangerStep {0}", profileId).ToList();
				return Ok(selfAssessmentApprovals);
			}
		}

		[HttpGet]
		[Route("GetMidYearPendingApprovals")]
		public IActionResult GetMidYearPendingApprovals(string profileId)
		{
			//networkId = "rasurati1";
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var midYearApprovals = db._MidYearNeedManagerSign.FromSqlRaw("MidYearNeedManagerSign  {0}", profileId).ToList();
				return Ok(midYearApprovals);
			}
		}

		[HttpGet]
		[Route("GetHRReviewApprovals")]
		public IActionResult GetHRReviewApprovals(string profileId)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var hrreviewApprovals = db._AppraisalsSelfAssessmentNeedsManangerStepSP.FromSqlRaw("USP_AppraisalNeedsHRSignOff {0}", profileId).ToList();
				return Ok(hrreviewApprovals);
			}
		}

		[HttpGet]
		[Route("GetEmplSignOffApprovals")]
		public IActionResult GetEmplSignOffApprovals(string profileId)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var emplSignOffApprovals = db._AppraisalsNeedManagerSign.FromSqlRaw("AppraisalsNeedManagerSign  {0}", profileId).ToList();
				return Ok(emplSignOffApprovals);
			}
		}
        [HttpGet]
        [Route("GetEmplCompetencyApprovals")]
        public IActionResult GetEmplCompetencyApprovals(string profileId)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var pendingCompetencyApprovals = db._CompetencyNeedsManangerStepSP.FromSqlRaw("usp_EmplCompetencyApprovals  {0}", profileId).ToList();
                return Ok(pendingCompetencyApprovals);
            }
        }
    }
}