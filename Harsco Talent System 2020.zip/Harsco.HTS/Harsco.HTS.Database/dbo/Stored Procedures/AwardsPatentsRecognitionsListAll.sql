﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/24/2012
-- =============================================
CREATE PROCEDURE [dbo].[AwardsPatentsRecognitionsListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AwardPatentRecognitionID, ProfileID, [Description], DateReceived, ReferenceNumber, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM AwardsPatentsRecognitions

END
SET NOCOUNT OFF
COMMIT TRANSACTION;