﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_WorkExperienceDetails_GetByID]
    @WorkExperienceDetailID int
AS
BEGIN
    SELECT CreatedOn, 
        WorkExperienceDetailID, 
        WorkExperienceID, 
        WorkExperienceTimeStamp, 
        Title, 
        Responsibilities, 
        Sequence, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM WorkExperienceDetails
    WHERE WorkExperienceDetailID = @WorkExperienceDetailID
    ORDER BY CreatedOn Desc
END