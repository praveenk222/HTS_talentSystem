﻿CREATE TABLE [History].[DevelopmentPlanDetails] (
    [CreatedOn]                DATETIME       NOT NULL,
    [DevelopmentPlanDetailID]  INT            NOT NULL,
    [DevelopmentPlanID]        INT            NOT NULL,
    [DevelopmentPlanTimeStamp] BINARY (8)     NOT NULL,
    [Category]                 INT            NULL,
    [Objective]                NTEXT          NOT NULL,
    [Activity]                 NTEXT          NOT NULL,
    [SupportRequired]          NTEXT          NOT NULL,
    [DateDue]                  SMALLDATETIME  NOT NULL,
    [MeasurementProcess]       NVARCHAR (800) NOT NULL,
    [Completion]               INT            NULL,
    [PointOfEntryId]           INT            NULL,
    [ActivityLoopId]           INT            NULL,
    [DevelopmentLoopId]        INT            NULL,
    [CompletionDate]           SMALLDATETIME  NULL,
    [Result]                   NVARCHAR (MAX) NULL,
    [CreatedBy]                VARCHAR (50)   NULL,
    [Created]                  DATETIME       NULL,
    [ModifiedBy]               NVARCHAR (50)  NOT NULL,
    [ModifiedOn]               DATETIME       CONSTRAINT [DF_DevelopmentPlanDetails_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanDetails] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanDetailID] ASC)
);



