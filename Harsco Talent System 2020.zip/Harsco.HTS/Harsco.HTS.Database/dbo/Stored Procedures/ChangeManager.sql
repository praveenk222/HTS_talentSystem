﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/20
-- =============================================
CREATE PROCEDURE [dbo].[ChangeManager]

@Member varchar(255),
@NewManager varchar(255),
@ModifiedBy varchar(50)
                
AS

BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @NewManagerID int
	DECLARE @ManagerName varchar(255)
	DECLARE @CompetencyID int
	DECLARE @AppraisalID int

	SELECT @NewManagerID = ProfileID, @ManagerName = EmployeeName
	FROM dbo.Profiles
	WHERE NetworkId =  @NewManager
   
   	SELECT @AppraisalID = AppraisalID 
	FROM dbo.Profiles
	WHERE NetworkId =  @Member
  
	UPDATE dbo.Profiles SET ManagerID = @NewManagerID, ModifiedBy = @ModifiedBy, ModifiedOn = getdate()
	WHERE NetworkId = @Member

    UPDATE ObjectiveApprovals SET ApproverName = @ManagerName, ApproverID = @NewManager, ModifiedOn = getdate()
    WHERE ApprovalStatusID in (1,4)
    AND  ObjectiveID in (Select ObjectiveID FROM Objectives WHERE AppraisalID = @AppraisalID) 
    
    UPDATE DevelopmentPlanApprovals SET ApproverName = @ManagerName, ApproverID = @NewManager, ModifiedOn = getdate()
    WHERE ApprovalStatusID in (1,4)
	AND DevelopmentPlanDetailID in (Select DevelopmentPlanDetailID FROM DevelopmentPlans INNER JOIN DevelopmentPlanDetails ON DevelopmentPlanDetails.DevelopmentPlanID = DevelopmentPlans.DevelopmentPlanID
    WHERE AppraisalID = @AppraisalID) 
        
END
SET NOCOUNT OFF
COMMIT TRANSACTION;