﻿
-- ==================================================================
-- Author:		Ed Blair
-- Create date: 06/22/2012
-- Description: get appraisals the need employee final sign
-- 
-- Modifications:
-- ==================================================================
CREATE PROCEDURE [dbo].[AppraisalsNeedEmployeeSign] 
	@CurrentUser varchar(50)
AS
SET NOCOUNT ON
BEGIN
	
    SELECT Profiles.EmployeeName, Appraisals.AppraisalId, ProfileID, NetworkID
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
    WHERE SelfAssessmentComplete = 1
	AND Profiles.TerminationDate IS NULL
	AND Profiles.Networkid NOT IN ('removed','Duplicate','pdecker','deveritt')
	AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
    AND ManagerStepComplete = 1
    AND EmployeeSignDate is null
    AND ManagerSignDate is null
    AND Profiles.ProfileID = @CurrentUser
END
SET NOCOUNT OFF
