﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_EducationalInstitutions_GetByID]
    @ArchiveEducationalInstitutionID int
AS
BEGIN
    SELECT ArchiveEducationalInstitutionID, 
        ArchiveProfileID, 
        InstitutionName, 
        Address, 
        EducationalDegree, 
        YearsAttendedStart, 
        YearsAttendedEnd, 
        Description, 
        ModifiedBy, 
        ModifiedOn
    FROM EducationalInstitutions
    WHERE ArchiveEducationalInstitutionID = @ArchiveEducationalInstitutionID
END