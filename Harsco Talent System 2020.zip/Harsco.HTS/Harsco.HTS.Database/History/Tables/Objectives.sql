﻿CREATE TABLE [History].[Objectives] (
    [CreatedOn]             DATETIME      CONSTRAINT [DF_Objectives_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ObjectiveID]           INT           NOT NULL,
    [AppraisalID]           INT           NOT NULL,
    [Description]           NTEXT         NOT NULL,
    [YearEndResults]        NTEXT         NOT NULL,
    [ManagerYearEndResults] NTEXT         CONSTRAINT [DF_Objectives_ManagerYearEndResults_1] DEFAULT ('') NOT NULL,
    [DateDue]               SMALLDATETIME NOT NULL,
    [AchievedId]            INT           NULL,
    [ManagerAchievedId]     INT           NULL,
    [CreatedBy]             VARCHAR (50)  NOT NULL,
    [Created]               DATETIME      NOT NULL,
    [ModifiedBy]            NVARCHAR (50) NOT NULL,
    [ModifiedOn]            DATETIME      NOT NULL,
    CONSTRAINT [PK_Objectives] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ObjectiveID] ASC)
);

