﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- =============================================
CREATE PROCEDURE  [Archive].[Report_HeaderInfo]

@ProfileId int,
@AppraisalId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

   SELECT Profiles.EmployeeName, JobTitle, Email, Profiles.ManagerName, JobFamilyName, DateHired, DivisionName, LocationName, Appraisals.AppraisalType
   FROM Archive.Profiles
		INNER JOIN Archive.Appraisals ON Appraisals.ArchiveAppraisalID = Profiles.ArchiveAppraisalID
    WHERE Profiles.ArchiveProfileId = @ProfileId

END
SET NOCOUNT OFF
COMMIT TRANSACTION;