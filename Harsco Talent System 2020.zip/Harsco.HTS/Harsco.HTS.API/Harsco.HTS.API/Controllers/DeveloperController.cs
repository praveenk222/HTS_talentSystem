﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [ApiController]
    [Route("[controller]")]
    public class DeveloperController : Controller
    {
        /// <summary>
        /// Get the Division model
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetDivision")]
        public IActionResult GetDivision()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var division = db.Divisions.ToList();
                var businessgroup = db.BusinessGroups.ToList();

                return Ok(new
                {
                    division,
                    businessgroup,
                });
            }
        }

        /// <summary>
        /// Updates the Division model
        /// </summary>
        /// <param name="divisionVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateDivisions")]
        public IActionResult UpdateDivisions(vmDivisions divisionVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var divisiondbModel = db.Divisions.Where(p => p.DivisionId == divisionVM.DivisionId).FirstOrDefault();

                divisiondbModel.DivisionName = divisionVM.DivisionName;
                divisiondbModel.Abbreviation = divisionVM.Abbreviation;
                divisiondbModel.DisplayName = divisionVM.DisplayName;
                divisiondbModel.BusinessGroupId = divisionVM.BusinessGroupId;
                divisiondbModel.IsDeleted = divisionVM.IsDeleted;
                divisiondbModel.CreatedBy = divisionVM.LoggedInUser.EmployeeName;
                divisiondbModel.CreatedOn = DateTime.Now;
                divisiondbModel.ModifiedBy = divisionVM.LoggedInUser.EmployeeName;
                divisiondbModel.ModifiedOn = DateTime.Now;
                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Create the Division model
        /// </summary>
        /// <param name="divisionVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateDivision")]
        public IActionResult CreateDivision(vmDivisions divisionVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                Divisions divisionDB = new Divisions();

                divisionVM.BindModelTo(divisionDB);

                divisionDB.ModifiedOn = DateTime.Now;
                divisionDB.CreatedOn = DateTime.Now;
                divisionDB.CreatedBy = divisionVM.LoggedInUser.EmployeeName;
                divisionDB.ModifiedBy = divisionVM.LoggedInUser.EmployeeName;
                db.Divisions.Add(divisionDB);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Get the Business Group model
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetBusinessGroup")]
        public IActionResult GetBusinessGroup()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var businessgroup = db.BusinessGroups.ToList();

                return Ok(businessgroup);
            }
        }

        /// <summary>
        /// Updates the Business Group model
        /// </summary>
        /// <param name="divisionVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateBusinessGroup")]
        public IActionResult UpdateBusinessGroup(vmBusinessGroup businessGroupVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var businessgroupdbModel = db.BusinessGroups.Where(p => p.BusinessGroupId == businessGroupVM.BusinessGroupID).FirstOrDefault();

                businessgroupdbModel.BusinessGroupAdcode = businessGroupVM.BusinessGroupADCode;
                businessgroupdbModel.BusinessGroupName = businessGroupVM.BusinessGroupName;
                businessgroupdbModel.IsDeleted = businessGroupVM.IsDeleted;
                businessgroupdbModel.CreatedBy = businessGroupVM.LoggedInUser.EmployeeName;
                businessgroupdbModel.CreatedOn = DateTime.UtcNow;
                businessgroupdbModel.ModifiedBy = businessGroupVM.LoggedInUser.EmployeeName;
                businessgroupdbModel.ModifiedOn = DateTime.UtcNow;

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Create the Business Group model
        /// </summary>
        /// <param name="divisionVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateBusinessGroup")]
        public IActionResult CreateBusinessGroup(vmBusinessGroup businessGroupVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                BusinessGroups businessGroupDB = new BusinessGroups();

                businessGroupVM.BindModelTo(businessGroupDB);

                businessGroupDB.ModifiedOn = DateTime.Now;
                businessGroupDB.CreatedOn = DateTime.Now;
                businessGroupDB.CreatedBy = businessGroupVM.LoggedInUser.EmployeeName;
                businessGroupDB.ModifiedBy = businessGroupVM.LoggedInUser.EmployeeName;
                db.BusinessGroups.Add(businessGroupDB);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Get the countries model
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCountries")]
        public IActionResult GetCountries()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var countries = db.TblCountries.ToList();

                return Ok(countries);
            }
        }

        /// <summary>
        /// Updates the Countries model
        /// </summary>
        /// <param name="countriesVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateCountries")]
        public IActionResult UpdateCountries(vmCountries countriesVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var countriesdbModel = db.TblCountries.Where(p => p.CountryId == countriesVM.CountryId).FirstOrDefault();

                countriesdbModel.CountryName = countriesVM.CountryName;
                countriesdbModel.CountryCode = countriesVM.CountryCode;

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Create the Countries model
        /// </summary>
        /// <param name="countriesVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateCountries")]
        public IActionResult CreateCountries(vmCountries countriesVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                TblCountries countriesDB = new TblCountries();

                countriesVM.BindModelTo(countriesDB);
                db.TblCountries.Add(countriesDB);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Get the Job Family model
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetJobFamily")]
        public IActionResult GetJobFamily()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var jobfamily = db.JobFamily.ToList();

                return Ok(jobfamily);
            }
        }

        /// <summary>
        /// Updates the Job Family model
        /// </summary>
        /// <param name="jobFamilyVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateJobFamily")]
        public IActionResult UpdateJobFamily(vmJobFamily jobFamilyVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var jobfamilydbModel = db.JobFamily.Where(p => p.Id == jobFamilyVM.Id).FirstOrDefault();

                jobfamilydbModel.Description = jobFamilyVM.Description;
                jobfamilydbModel.IsDeleted = jobFamilyVM.IsDeleted;
                jobfamilydbModel.CreatedBy = jobFamilyVM.LoggedInUser.EmployeeName;
                jobfamilydbModel.CreatedOn = DateTime.Now;
                jobfamilydbModel.ModifiedBy = jobFamilyVM.LoggedInUser.EmployeeName;
                jobfamilydbModel.ModifiedOn = DateTime.Now;

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        /// <summary>
        /// Create the JobFamily model
        /// </summary>
        /// <param name="jobFamilyVM"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateJobFamily")]
        public IActionResult CreateJobFamily(vmJobFamily jobFamilyVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                JobFamily jobFamilyDB = new JobFamily();

                jobFamilyVM.BindModelTo(jobFamilyDB);

                jobFamilyDB.ModifiedOn = DateTime.Now;
                jobFamilyDB.CreatedOn = DateTime.Now;
                jobFamilyDB.CreatedBy = jobFamilyVM.LoggedInUser.EmployeeName;
                jobFamilyDB.ModifiedBy = jobFamilyVM.LoggedInUser.EmployeeName;
                db.JobFamily.Add(jobFamilyDB);

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpGet]
        [Route("GetDropDownValues")]
        public IActionResult GetDropDownValues()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var vwAppraisalTypes = db.AppraisalTypes.ToList();
                var vwProfiles = db.Profiles.Where(p => p.TerminationDate == null).ToList();
                return Ok(new
                {
                    vwAppraisalTypes,
                    vwProfiles
                });
            }
        }

        [HttpGet]
        [Route("UpdateEmployeeAppraisalCycle")]
        public IActionResult UpdateEmployeeAppraisalCycle(string EmployeeNumber, int AppraisalTypeId)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var successmessage = db.Set<_closeallappraisal>().FromSqlRaw("UpdateEmployeeAppraisalCycle  {0},{1}", AppraisalTypeId, EmployeeNumber).ToList();
                return Ok(new { status = successmessage });
            }
        }

        [HttpGet]
        [Route("HRITFEEDErrorLog")]
        public IActionResult HRITFEEDErrorLog()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var result = db.HritfeedErrorLog.ToList();
                return Ok(result);
            }
        }

        [HttpGet]
        [Route("HTSProfiles")]
        public IActionResult HTSProfiles()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var result = db.Profiles.Take(50).ToList();
                return Ok(result);
            }
        }

        [HttpGet]
        [Route("GetWrongAppraisalsByTypeID")]
        public IActionResult GetWrongAppraisalsByTypeID(int AppraisalTypeID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var allWrongAppraisals = db.WrongAppraisals.FromSqlRaw("USP_Report_GetallWrongAppraisals {0}", AppraisalTypeID).ToList();
                return Ok(allWrongAppraisals);
            }
        }


        [HttpGet]
        [Route("GetEmployeeAppraisalCycle")]
        public IActionResult GetEmployeeAppraisalCycle()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var EmployeeAppraisalCycle = db.EmployeeAppraisalCycle.FromSqlRaw("USP_GetEmployeeAppraisalCycle").ToList();
                return Ok(EmployeeAppraisalCycle);
            }
        }

        [HttpGet]
        [Route("GetNotMidYearEmployeeAppraisalCycle")]
        public IActionResult GetNotMidYearEmployeeAppraisalCycle()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var EmployeeAppraisalCycle = db.EmployeeAppraisalCycle.FromSqlRaw("USP_GetNotMidYearEmployeeAppraisalCycle").ToList();
                return Ok(EmployeeAppraisalCycle);
            }
        }



        [HttpGet]
        [Route("GetNotEndYearEmployeeAppraisalCycle")]
        public IActionResult GetNotEndYearEmployeeAppraisalCycle()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var EmployeeAppraisalCycle = db.EmployeeAppraisalCycle.FromSqlRaw("USP_GetNotEndYearEmployeeAppraisalCycle").ToList();
                return Ok(EmployeeAppraisalCycle);
            }
        }



   

        [HttpGet]
        [Route("GetNoteMessage")]
        public IActionResult GetNoteMessage()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var note = db.NoteMessage.FromSqlRaw("USP_GetNoteMessage").ToList();
                return Ok(note);
            }
        }


        [HttpGet]
        [Route("GetActualCycle")]
        public IActionResult GetActualCycle()
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var ActualCycle = db.ActualCycle.FromSqlRaw("USP_ActualCycle").ToList();
                return Ok(ActualCycle);
            }
        }
    }
}