﻿CREATE TABLE [Archive].[Profiles] (
    [ArchiveProfileID]   INT            IDENTITY (1, 1) NOT NULL,
    [OriginalProfileID]  INT            NOT NULL,
    [ArchiveAppraisalID] INT            NOT NULL,
    [NetworkID]          NVARCHAR (20)  NOT NULL,
    [ManagerName]        NVARCHAR (255) NULL,
    [EmployeeNumber]     NVARCHAR (20)  NULL,
    [EmployeeName]       NVARCHAR (255) NOT NULL,
    [Email]              NVARCHAR (255) NOT NULL,
    [DivisionName]       VARCHAR (50)   NULL,
    [CountryName]        VARCHAR (75)   NOT NULL,
    [LocationName]       NVARCHAR (255) NULL,
    [Address]            NVARCHAR (255) NULL,
    [PhoneNumber]        NVARCHAR (255) NULL,
    [JobTitle]           NVARCHAR (255) NULL,
    [JobFamilyName]      NVARCHAR (255) NULL,
    [DateHired]          SMALLDATETIME  NULL,
    [TerminationDate]    SMALLDATETIME  NULL,
    [ModifiedBy]         NVARCHAR (50)  NOT NULL,
    [ModifiedOn]         DATETIME       CONSTRAINT [DF_Profiles_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Profiles] PRIMARY KEY CLUSTERED ([ArchiveProfileID] ASC),
    CONSTRAINT [FK_Profiles_Appraisals] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);




GO
CREATE TRIGGER [Archive].[tr_Profiles_PreventChanges]     ON  Archive.Profiles     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END