﻿



-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- =============================================
CREATE PROCEDURE  [dbo].[CompetencyComments_Modify]

@CompetencyID int,
@Comment ntext,
@ManagerComment ntext,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.CompetencyComments WHERE @CompetencyID=CompetencyID))
		BEGIN
			UPDATE CompetencyComments
			SET Comment = @Comment, 
				ManagerComment = @ManagerComment, 
				ModifiedBy = @ModifiedBy, 
				ModifiedOn = @ModifiedOn
			WHERE CompetencyID = @CompetencyID			
		END
    ELSE
		BEGIN
			INSERT INTO CompetencyComments
			(CompetencyID, Comment, ManagerComment, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@CompetencyID, @Comment, @ManagerComment, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

		END
END