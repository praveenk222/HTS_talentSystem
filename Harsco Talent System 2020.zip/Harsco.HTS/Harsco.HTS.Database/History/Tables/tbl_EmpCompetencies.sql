﻿CREATE TABLE [History].[tbl_EmpCompetencies] (
    [CreatedOn]        DATETIME       NOT NULL,
    [ID]               INT            NOT NULL,
    [LC_ID]            INT            NULL,
    [AppraisalID]      INT            NULL,
    [AppraisalTypeID]  INT            NULL,
    [EmpRating]        INT            NULL,
    [MgrRating]        INT            NULL,
    [ApprovalStatusID] INT            NULL,
    [ApproverID]       NVARCHAR (300) NULL,
    [ModifiedBy]       NVARCHAR (300) NULL,
    [ModifiedDate]     DATETIME       NULL,
    [IsActive]         BIT            NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

