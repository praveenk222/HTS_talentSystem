﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 02/18/2013
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalTypesListAll]
    
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AppraisalTypeID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn,
        [TimeStamp]
    FROM AppraisalTypes

    
END
SET NOCOUNT OFF
COMMIT TRANSACTION;