﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Specialized;
using Harsco.HTS.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        [HttpGet]
        [Route("")]
        public ActionResult<IEnumerable<string>> Welcome()
        {
            return new string[] { "Welcome to HTS API. If you are seeing this message means the HTS API Service is up and running" };
        }

        [HttpGet]
        [Route("Translate")]
        public IActionResult Translate(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                string StorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=altekdocmanagement;AccountKey=S+lhF1gFcvwtn8ArGgIkVqcs2TVBo3c46Xkqcs7RlvigJJ4ed+77VzlcHsQpQ4YJqVHeEMQ6fEnP/2lOH6rYmQ==;EndpointSuffix=core.windows.net";

                BlobServiceClient storageAccount = new BlobServiceClient(StorageConnectionString);
                BlobContainerClient container = storageAccount.GetBlobContainerClient("hts-translations-blob");

                BlockBlobClient blockBlob = container.GetBlockBlobClient("de_DE.json");
                bool isExists = blockBlob.Exists();

                return Ok();
            }
        }

        [HttpGet]
        [Route("GetPendingApprovals")]
        public IActionResult GetPendingApprovals(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                if(profileID != 0) {
                    var profile = db.Profiles.Where(p => p.ProfileId == profileID ).SingleOrDefault();
                    
                    if(profile.TerminationDate == null && !profile.NetworkId.ToLower().Contains("removed"))
                    {
                        //var oACount = db.ObjectiveApprovals.Where(p => p.ApproverId == profile.NetworkId && p.ApprovalStatusId == 1).Count();
                        //var dPApprovalsCount = db.DevelopmentPlanApprovals.Where(p => p.ApproverId == profile.NetworkId && p.ApprovalStatusId == 1).Count();

                        var oACount = db.Objectives.FromSqlRaw("SP_objectiveApprovalsCount {0}", profile.ProfileId).AsEnumerable().Count();
                        var dPApprovalsCount = db.DevelopmentPlans.FromSqlRaw("SP_DevelopmentPlanApprovalsCount {0}", profile.ProfileId).AsEnumerable().Count();
                        var sAApprovalCount = db._AppraisalsSelfAssessmentNeedsManangerStepSP.FromSqlRaw("AppraisalsSelfAssessmentNeedsManangerStep  {0}", profile.ProfileId).AsEnumerable().Count();
                        var SelfSignOffCount = db._AppraisalsNeedEmployeeSignSP.FromSqlRaw("AppraisalsNeedEmployeeSign {0}", profile.ProfileId).AsEnumerable().Count();
                        var ManagerSignOffCount = db._AppraisalsNeedManagerSign.FromSqlRaw("AppraisalsNeedManagerSign {0}", profile.ProfileId).AsEnumerable().Count();
                        var hrreviewApprovalsCount = db._AppraisalsSelfAssessmentNeedsManangerStepSP.FromSqlRaw("USP_AppraisalNeedsHRSignOff {0}", profile.ProfileId).AsEnumerable().Count();
                        var midYearSubmitted = db._MidYearNeedManagerSign.FromSqlRaw("MidYearNeedManagerSign {0}", profile.ProfileId).AsEnumerable().Count();
                        var skillsMangerApproval=db.Skills.FromSqlRaw("CompetencyManagerApproval {0}", profile.ProfileId).AsEnumerable().Count();
                        var mycompetencyMngrApproval = db.tbl_EmpCompetencies.FromSqlRaw("usp_MYCompetencyManagerApproval {0}", profile.ProfileId).AsEnumerable().Count();

                        return Ok(new
                        {
                            objectiveApprovalsCount = oACount,
                            developmentPlanApprCount = dPApprovalsCount,
                            selfAssessmentApprCount = sAApprovalCount,
                            signOffSelfAppraisal = SelfSignOffCount,
                            signOffEmplAppraisalCount = ManagerSignOffCount,
                            hRReviewApprovalsCount = hrreviewApprovalsCount,
                            midYearSubmitted = midYearSubmitted,
                            skillsMangerApproval = skillsMangerApproval,
                            mycompetencyMngrApproval= mycompetencyMngrApproval,
                        });
                    }
                    else
                    {
                        return Ok(new
                        {
                            objectiveApprovalsCount = 0,
                            developmentPlanApprCount = 0,
                            selfAssessmentApprCount = 0,
                            signOffSelfAppraisal = 0,
                            signOffEmplAppraisalCount = 0,
                            hRReviewApprovalsCount = 0,
                            midYearSubmitted = 0,
                            skillsMangerApproval=0,
                            mycompetencyMngrApproval=0,
                        });
                    }                    
                }
                else
                {
                    return Ok(new { status = "error" });
                }
                
            }
        }

        [HttpGet]
        [Route("GetEmployeeProfile")]
        public IActionResult GetEmployeeProfile(string NetworkID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var profile = db.Profiles.Where(p => p.NetworkId == NetworkID && p.TerminationDate == null).FirstOrDefault();

                return Ok(profile);
            }
        }
    }
}