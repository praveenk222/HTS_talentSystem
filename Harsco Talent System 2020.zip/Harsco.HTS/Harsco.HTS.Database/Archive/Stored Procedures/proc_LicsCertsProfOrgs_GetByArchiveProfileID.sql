﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_LicsCertsProfOrgs_GetByArchiveProfileID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveLicCertProfOrgID, 
        ArchiveProfileID, 
        Description, 
        LicenseCategory, 
        LicenseNumber, 
        CertificationNumber, 
        ProfessionalOrganizationName, 
        ModifiedBy, 
        ModifiedOn
    FROM LicsCertsProfOrgs
    WHERE ArchiveProfileID = @ArchiveProfileID
END