﻿

-- =============================================
-- Author:		Ed Blair
-- Create date: 09/24/2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CareerAspirationListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	SELECT Id, ProfileId, Aspiration, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
	FROM dbo.CareerAspiration

END
SET NOCOUNT OFF
COMMIT TRANSACTION;