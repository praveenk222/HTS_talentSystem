﻿


-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 08/21/2012
-- =============================================
CREATE PROCEDURE  [Archive].[MidYearByAppraisalId]

@ArchiveMidYearId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ArchiveMidYear, OriginalMidYearID, ArchivedProfileID, AppraisalTypeID
    FROM Archive.MidYear
	WHERE ArchiveMidYear = @ArchiveMidYearId
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;