﻿-- =============================================  
-- AUTHOR: Ed Blair  
-- CREATED DATE: 07/26/2012  
--AppraisalsNeedManagerManagerSignoff 18  
-- =============================================  
-- EXEC AppraisalsNeedManagerManagerSignoff 22
CREATE PROCEDURE  [dbo].[AppraisalsNeedManagerManagerSignoff]  
@AppraisalTypeID int    
AS  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
BEGIN TRANSACTION;  
	SET NOCOUNT ON  
	BEGIN  
  
		SELECT 
			A.AppraisalID,   
			AppraisalTypeID,   
			COCViolation,   
			ManagerMeeting,  
			PerformanceRating,   
			CompetencyRating,   
			OverallRating,   
			ReviewDate,   
			SelfAssessmentComplete,   
			ManagerStepComplete,   
			EmployeeComment,   
			ManagerComment,   
			ObjectiveComment,   
			CompetencyComment,   
			SkillComment,   
			A.EmployeeName,   
			EmployeeSignDate,   
			ManagerName,   
			ManagerSignDate,   
			ManagersManagerName,   
			ManagersManagerSignDate,   
			A.ModifiedBy,   
			A.ModifiedOn 
		FROM Appraisals A
			INNER JOIN Profiles P ON P.AppraisalID = A.AppraisalID 
			INNER JOIN tbl_HRITMasterData H ON H.EMPLOYEE_NUMBER =P.EmployeeNumber
		WHERE 
			--ManagersManagerSignDate IS NULL AND 
			AppraisalTypeID = @AppraisalTypeID   
			AND NetworkId NOT IN ('Removed','Duplicate')  
			AND Networkid NOT IN (SELECT NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)  
			AND P.TerminationDate IS NULL 
			AND H.TERMINATIONDATE IS NULL
			AND H.DIRECT_INDIRECT = 'Indirect'
	END  
SET NOCOUNT OFF  
COMMIT TRANSACTION;









 