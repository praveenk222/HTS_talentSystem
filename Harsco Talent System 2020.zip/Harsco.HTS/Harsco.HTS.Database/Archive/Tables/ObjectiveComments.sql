﻿CREATE TABLE [Archive].[ObjectiveComments] (
    [ArchiveObjectiveCommentID]   INT           IDENTITY (1, 1) NOT NULL,
    [OriginalObjectiveCommentID]  INT           NOT NULL,
    [ArchiveObjectiveID]          INT           NULL,
    [ArchiveObjectiveMilestoneID] INT           NULL,
    [Comment]                     NTEXT         NOT NULL,
    [Confidential]                BIT           CONSTRAINT [DF_ObjectiveComments_Confidential_1] DEFAULT ((0)) NOT NULL,
    [CommentType]                 NVARCHAR (50) NOT NULL,
    [ModifiedBy]                  NVARCHAR (50) NOT NULL,
    [ModifiedOn]                  DATETIME      CONSTRAINT [DF_ObjectiveComments_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_ObjectiveComments_1] PRIMARY KEY CLUSTERED ([ArchiveObjectiveCommentID] ASC),
    CONSTRAINT [FK_ObjectiveComments_ObjectiveMilestones] FOREIGN KEY ([ArchiveObjectiveMilestoneID]) REFERENCES [Archive].[ObjectiveMilestones] ([ArchiveObjectiveMilestoneID]),
    CONSTRAINT [FK_ObjectiveComments_Objectives] FOREIGN KEY ([ArchiveObjectiveID]) REFERENCES [Archive].[Objectives] ([ArchiveObjectiveID])
);


GO
CREATE TRIGGER [Archive].[tr_ObjectiveComments_PreventChanges]     ON  Archive.ObjectiveComments     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END