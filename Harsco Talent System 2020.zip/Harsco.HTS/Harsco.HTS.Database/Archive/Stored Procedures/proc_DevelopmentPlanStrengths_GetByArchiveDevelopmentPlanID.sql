﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanStrengths_GetByArchiveDevelopmentPlanID]
    @ArchiveDevelopmentPlanID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanStrengthID, 
        ArchiveDevelopmentPlanID, 
        Strength, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanStrengths
    WHERE ArchiveDevelopmentPlanID = @ArchiveDevelopmentPlanID
END