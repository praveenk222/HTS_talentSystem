﻿CREATE TABLE [Archive].[CompetencyComments] (
    [ArchiveCompetencyCommentID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalCompetencyCommentID] INT            NOT NULL,
    [ArchiveCompetencyId]         INT            NOT NULL,
    [Comment]                     NVARCHAR (MAX) NULL,
    [ManagerComment]              NVARCHAR (MAX) CONSTRAINT [DF_CompetencyComments_ManagerComment_1] DEFAULT ('') NULL,
    [CreatedBy]                   VARCHAR (50)   NOT NULL,
    [CreatedOn]                   DATETIME       NOT NULL,
    [ModifiedBy]                  NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                  DATETIME       CONSTRAINT [DF_CompetencyComments_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_CompetencyComments] PRIMARY KEY CLUSTERED ([ArchiveCompetencyCommentID] ASC)
);
GO

CREATE TRIGGER [Archive].[tr_CompetencyComments_PreventChanges]     ON  Archive.CompetencyComments     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END