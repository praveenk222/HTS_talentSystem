﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanComments_GetByArchiveDevelopmentPlanStrengthID]
    @ArchiveDevelopmentPlanStrengthID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanCommentID, 
        ArchiveDevelopmentPlanStrengthID, 
        ArchiveDevelopmentPlanWeaknessID, 
        ArchiveDevelopmentPlanDetailID, 
        Comment, 
        Confidential, 
        CommentType, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanComments
    WHERE ArchiveDevelopmentPlanStrengthID = @ArchiveDevelopmentPlanStrengthID
END