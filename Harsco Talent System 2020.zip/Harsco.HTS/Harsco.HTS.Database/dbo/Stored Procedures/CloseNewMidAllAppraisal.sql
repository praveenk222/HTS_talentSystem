﻿
-- =============================================  
-- Author:  <Tejal Shah>  
-- Create date: <08/10/2020>  
-- Description: <Close complete appraisal period cycle>  
-- [dbo].[CloseNewMidAllAppraisal] 12  
-- =============================================  
-- Exec [dbo].[CloseNewMidAllAppraisal] 19
CREATE PROCEDURE [dbo].[CloseNewMidAllAppraisal] 
	@AppraisalTypeId INT
AS
BEGIN
--SET NOCOUNT ON
BEGIN TRANSACTION;
-- Mid year cycle
BEGIN TRY
    DECLARE @Count int
	DECLARE @RowNumber int
	
    DECLARE @NewProfiles TABLE 
	(
		Id int Identity(1,1) Primary Key,
		MidYearID int ,
		ProfileID int  ,
		AppraisalTypeID int  ,
		EmpObjective ntext ,
		MgrObjective ntext ,
		EmpValueBehavior ntext ,
		MgrValueBehavior ntext ,
		EmpDevelopmentPlan ntext ,
		MgrDevelopmentPlan ntext ,
		ReviewDate datetime ,
		EmpSignDate datetime ,
		EmployeeName nvarchar(100) ,
		MgrSignDate datetime ,
		ManagerName nvarchar(100) ,
		CreatedBy varchar(50)  ,
		CreatedOn datetime  ,
		ModifiedBy varchar(50)  ,
		ModifiedOn datetime  ,
		ObjectiveID int 
	)
	
	Declare @EmployeeSign datetime
	Declare @MgrSign datetime
	Declare @MidYearId int
	Declare @ProfileId int
	Declare @AppraisalId int
	
	INSERT INTO  @NewProfiles(MidYearID, ProfileID, AppraisalTypeID, EmpObjective, MgrObjective, EmpValueBehavior, MgrValueBehavior, EmpDevelopmentPlan, MgrDevelopmentPlan, ReviewDate, EmpSignDate, EmployeeName, MgrSignDate, ManagerName, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn, ObjectiveID)
	SELECT MidYearID, M.ProfileID, M.AppraisalTypeID, M.EmpObjective, M.MgrObjective, M.EmpValueBehavior, M.MgrValueBehavior, M.EmpDevelopmentPlan, M.MgrDevelopmentPlan, M.ReviewDate, M.EmpSignDate, M.EmployeeName, M.MgrSignDate, M.ManagerName, M.CreatedBy, M.CreatedOn, M.ModifiedBy, M.ModifiedOn, M.ObjectiveID
	FROM [dbo].[MidYear] M 
	JOIN [dbo].[Profiles] P On P.ProfileId = M.ProfileId AND  M.AppraisalTypeID = 19
	AND P.Networkid NOT IN ('removed','Duplicate','pdecker','deveritt')			
	AND P.TerminationDate IS Null 
	
	SET @Count = @@ROWCOUNT
	Print 'Count'
	Print @Count
	SET @RowNumber = 1
	WHILE @RowNumber <= @Count
	BEGIN --while begin
		SELECT 
			@EmployeeSign=EmpSignDate, 
			@MgrSign=MgrSignDate,
			@MidYearId=MidYearID, 
			@ProfileId=ProfileID
		FROM @NewProfiles 
		WHERE Id=@RowNumber
		
		If(@EmployeeSign is null)
		BEGIN --If Begin
			update MidYear set 
				EmployeeName='HR Close',
				EmpSignDate=GETDATE() ,
				ModifiedBy='Auto HR Close',
				ModifiedOn=GETDATE()
			where MidYearID=@MidYearId
		END --If End
		
		If(@MgrSign is null)
		BEGIN --If Begin
			update MidYear set 
				ManagerName='HR Close',
				MgrSignDate=GETDATE() ,
				ModifiedBy='Auto HR Close',
				ModifiedOn=GETDATE()
			WHERE MidYearID=@MidYearId
		END --If End
		
		SELECT 
			@AppraisalId=AppraisalID 
		FROM Profiles 
		WHERE ProfileId=@ProfileId

		Exec [dbo].[MidYearAppraisalArchiveProcess] @ProfileId, @AppraisalId, @AppraisalTypeId, 'HR Close'
		SET @RowNumber = @RowNumber + 1
	END 

	DELETE FROM @NewProfiles

	DECLARE @CountEmptyProfiles int
	DECLARE @RowNumberEmptyProfile int
	DECLARE @EmptyAppraisal Table
	(
		Id int Identity(1,1) Primary key,
		ProfileID int ,
		AppraisalID int
	)

	INSERT INTO @EmptyAppraisal(ProfileID, AppraisalID)
	Select P.ProfileID, p.AppraisalID From Appraisals A 
	INNER JOIN Profiles p on a.AppraisalID = p.AppraisalID
	AND a.AppraisalTypeID=@AppraisalTypeID
	AND p.NetworkID  NOT IN ('removed','Duplicate','pdecker','deveritt')
	AND P.TerminationDate IS Null 

	SET @CountEmptyProfiles = @@ROWCOUNT
	Print 'CountEmptyProfiles' 
	print @CountEmptyProfiles 
	SET @RowNumberEmptyProfile = 1
	WHILE @RowNumberEmptyProfile <= @CountEmptyProfiles
	BEGIN --while begin
		SELECT 
			@AppraisalId=AppraisalID, 
			@ProfileId=ProfileID
		FROM @EmptyAppraisal 
		WHERE Id=@RowNumberEmptyProfile
		Exec [dbo].[MidYearAppraisalArchiveProcess] @ProfileId, @AppraisalId, @AppraisalTypeId, 'HR Close'
		SET @RowNumberEmptyProfile = @RowNumberEmptyProfile + 1
	END  
	
	DELETE FROM @EmptyAppraisal

	SELECT 'Success' as [Status]

COMMIT TRANSACTION;
END TRY
    BEGIN CATCH
	ROLLBACK TRANSACTION
	SELECT 'false' as 'Status' 
		INSERT INTO tbl_Errors(ErrorNumber,ErrorState,ErrorSeverity,ErrorLine,ErrorProcedure,ErrorMessage,ErrorDateTime )    
		SELECT      
			ERROR_NUMBER() AS ErrorNumber, ERROR_STATE() AS ErrorState, ERROR_SEVERITY() AS ErrorSeverity     
			,ERROR_LINE() AS ErrorLine, ERROR_PROCEDURE() AS ErrorProcedure, ERROR_MESSAGE() AS ErrorMessage, GETDATE()    
	END CATCH 

END

