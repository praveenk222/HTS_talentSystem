﻿CREATE TABLE [Archive].[DevelopmentPlanDetails] (
    [ArchiveDevelopmentPlanDetailID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanDetailID] INT            NOT NULL,
    [ArchiveDevelopmentPlanID]        INT            NOT NULL,
    [Category]                        NVARCHAR (50)  NULL,
    [Objective]                       NTEXT          NOT NULL,
    [Activity]                        NTEXT          NOT NULL,
    [SupportRequired]                 NTEXT          NOT NULL,
    [DateDue]                         SMALLDATETIME  NOT NULL,
    [MeasurementProcess]              NVARCHAR (MAX) NOT NULL,
    [ModifiedBy]                      NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                      DATETIME       CONSTRAINT [DF_DevelopmentPlanDetails_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    [PointOfEntryId]                  INT            NULL,
    [ActivityLoopId]                  INT            NULL,
    [DevelopmentLoopId]               INT            NULL,
    CONSTRAINT [PK_DevelopmentPlanDetails] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanDetailID] ASC),
    CONSTRAINT [FK_DevelopmentPlanDetails_DevelopmentPlans] FOREIGN KEY ([ArchiveDevelopmentPlanID]) REFERENCES [Archive].[DevelopmentPlans] ([ArchiveDevelopmentPlanID])
);




GO
CREATE TRIGGER [Archive].[tr_DevelopmentPlanDetails_PreventChanges]     ON  Archive.DevelopmentPlanDetails     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END