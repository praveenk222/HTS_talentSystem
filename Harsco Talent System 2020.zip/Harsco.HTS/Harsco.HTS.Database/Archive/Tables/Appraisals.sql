﻿CREATE TABLE [Archive].[Appraisals] (
    [ArchiveAppraisalID]      INT           IDENTITY (1, 1) NOT NULL,
    [OriginalAppraisalID]     INT           NOT NULL,
    [AppraisalYear]           INT           NOT NULL,
    [AppraisalType]           NVARCHAR (50) NOT NULL,
    [COCViolation]            VARCHAR (1)   NULL,
    [ManagerMeeting]          VARCHAR (1)   NULL,
    [PerformanceRating]       NVARCHAR (10) NULL,
    [CompetencyRating]        NVARCHAR (10) NULL,
    [OverallRating]           NVARCHAR (10) NULL,
    [ReviewDate]              SMALLDATETIME NULL,
    [SelfAssessmentComplete]  BIT           NULL,
    [ManagerStepComplete]     BIT           NULL,
    [EmployeeComment]         NTEXT         NULL,
    [ManagerComment]          NTEXT         NULL,
    [ObjectiveComment]        NTEXT         NULL,
    [CompetencyComment]       NTEXT         NULL,
    [SkillComment]            NTEXT         NULL,
    [EmployeeName]            NVARCHAR (75) NULL,
    [EmployeeSignDate]        DATETIME      NULL,
    [ManagerName]             NVARCHAR (75) NULL,
    [ManagerSignDate]         DATETIME      NULL,
    [ManagersManagerName]     NVARCHAR (75) NULL,
    [ManagersManagerSignDate] DATETIME      NULL,
    [ModifiedBy]              NVARCHAR (50) NOT NULL,
    [ModifiedOn]              DATETIME      CONSTRAINT [DF_Appraisals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Appraisals] PRIMARY KEY CLUSTERED ([ArchiveAppraisalID] ASC)
);


GO
CREATE TRIGGER [Archive].tr_Appraisals_PreventChanges     ON  Archive.Appraisals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END