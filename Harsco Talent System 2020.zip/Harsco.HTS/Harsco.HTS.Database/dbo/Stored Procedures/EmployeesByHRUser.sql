﻿
-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/05/2012
-- [dbo].[EmployeesByHRUser] 'eblair'
-- =============================================
CREATE PROCEDURE [dbo].[EmployeesByHRUser]

@HRUser varchar(50)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

DECLARE @SupperUser int
SET @SupperUser = (Select count(HRUsers.HRUserId)
	FROM HRUsers
	INNER JOIN dbo.HRPermissions ON HRPermissions.HRUserId = HRUsers.HRUserId
		AND  userName = @HRUser
		AND HRBP = 1)

DECLARE @ReportTo TABLE(NetworkID varchar(20))
INSERT INTO @ReportTo
		exec [ProfilesGetManagerHierarchy] @HRUser
	
IF @SupperUser > 0 
	BEGIN
		SELECT NetWorkId, EmployeeName
		FROM Profiles
		WHERE EXISTS(
			Select HRUsers.HRUserId
			FROM HRUsers
			INNER JOIN dbo.HRPermissions ON HRPermissions.HRUserId = HRUsers.HRUserId
				AND  userName = @HRUser
			WHERE (Profiles.DivisionID =  BusinessGroupID AND CountryId is Null)
			OR (Profiles.DivisionID =  BusinessGroupID AND CountryId = Profiles.CountryID))
			AND NetWorkId not in ('Removed','Duplicate','pdecker')
			AND Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
			AND ProfileID NOT IN (Select NetworkID FROM @ReportTo)
		ORDER BY Profiles.EmployeeName
	END
ELSE
	BEGIN
		SELECT NetWorkId, EmployeeName
		FROM Profiles
		WHERE EXISTS(
			Select HRUsers.HRUserId
			FROM HRUsers
			INNER JOIN dbo.HRPermissions ON HRPermissions.HRUserId = HRUsers.HRUserId
				AND  userName = @HRUser
			WHERE (Profiles.DivisionID =  BusinessGroupID AND CountryId is Null)
			OR (Profiles.DivisionID =  BusinessGroupID AND CountryId = Profiles.CountryID))
		AND NetWorkId NOT IN (Select ADName From ExcludeFromHR)
		AND NetWorkId not in ('Removed','Duplicate','pdecker')
		AND Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND ProfileID NOT IN (Select NetworkID FROM @ReportTo)
	ORDER BY Profiles.EmployeeName
	END
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;