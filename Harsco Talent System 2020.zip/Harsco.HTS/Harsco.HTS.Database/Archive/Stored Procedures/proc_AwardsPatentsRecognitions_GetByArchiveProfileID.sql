﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_AwardsPatentsRecognitions_GetByArchiveProfileID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveAwardPatentRecognitionID, 
        ArchiveProfileID, 
        Description, 
        DateReceived, 
        ReferenceNumber, 
        ModifiedBy, 
        ModifiedOn
    FROM AwardsPatentsRecognitions
    WHERE ArchiveProfileID = @ArchiveProfileID
END