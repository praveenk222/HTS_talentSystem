﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_JobFamilies_GetByID]
    @JobFamilyID int
AS
BEGIN
    SELECT CreatedOn, 
        JobFamilyID, 
        Title, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM JobFamilies
    WHERE JobFamilyID = @JobFamilyID
    ORDER BY CreatedOn Desc
END