﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 8/16/2012
-- =============================================
CREATE PROCEDURE [dbo].[EducationalDegreesListActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT EducationalDegreeID, ISNULL(Translations.TranslatedText, EducationalDegrees.Title) as Title
    FROM EducationalDegrees
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = EducationalDegrees.Title 
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = TranslationLanguageId
			and Code = @TranslationCode
	WHERE IsDeleted = 0
	ORDER BY ISNULL(Translations.TranslatedText, EducationalDegrees.Title)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;