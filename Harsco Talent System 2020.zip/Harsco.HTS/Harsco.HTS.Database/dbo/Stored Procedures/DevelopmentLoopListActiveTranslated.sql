﻿



-- ===================================================
-- AUTHOR:		 Ed Blair
-- CREATED DATE: 10/20/2017
--
-- [dbo].[DevelopmentLoopListActiveTranslated] 'en'
-- ===================================================
CREATE PROCEDURE  [dbo].[DevelopmentLoopListActiveTranslated]
    
@LanguageCode varchar(20)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  	DECLARE @Translate TABLE
	(Keyphrase nvarchar(255),
	TranslatedText nvarchar(2000))

	INSERT INTO @Translate 
	SELECT KeyPhrase, TranslatedText 
		FROM dbo.Translations
		INNER JOIN dbo.TranslationLanguages ON TranslationLanguages.ID = Translations.TranslationLanguageId
			AND TranslationLanguages.Code = @LanguageCode
	
    SELECT DevelopmentLoop.ID, ISNULL((SELECT TranslatedText FROM @Translate WHERE Keyphrase = DevelopmentLoop.Description),DevelopmentLoop.Description) as Description
    FROM DevelopmentLoop
    WHERE IsDeleted = 0


END
SET NOCOUNT OFF
COMMIT TRANSACTION;