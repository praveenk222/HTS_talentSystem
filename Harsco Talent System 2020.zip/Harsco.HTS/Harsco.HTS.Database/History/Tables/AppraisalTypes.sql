﻿CREATE TABLE [History].[AppraisalTypes] (
    [CreatedOn]       DATETIME      CONSTRAINT [DF_AppraisalTypes_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [AppraisalTypeID] INT           NOT NULL,
    [Title]           NVARCHAR (50) NOT NULL,
    [Code]            NVARCHAR (6)  NOT NULL,
    [IsDeleted]       BIT           NOT NULL,
    [ModifiedBy]      NVARCHAR (50) NOT NULL,
    [ModifiedOn]      DATETIME      NOT NULL,
    [TimeStamp]       BINARY (50)   NOT NULL,
    CONSTRAINT [PK_AppraisalTypes] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [AppraisalTypeID] ASC)
);

