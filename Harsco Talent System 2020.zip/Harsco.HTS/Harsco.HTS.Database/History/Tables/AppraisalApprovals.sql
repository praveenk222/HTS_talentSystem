﻿CREATE TABLE [History].[AppraisalApprovals] (
    [CreatedOn]               DATETIME      CONSTRAINT [DF_AppraisalApprovals_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [AppraisalApprovalID]     INT           NOT NULL,
    [AppraisalID]             INT           NOT NULL,
    [AppraisalTimeStamp]      BINARY (8)    NOT NULL,
    [Comment]                 NTEXT         NOT NULL,
    [ApprovalStatusID]        INT           NOT NULL,
    [ApprovalStatusTimeStamp] BINARY (8)    NOT NULL,
    [StatusChangedDate]       DATETIME      NOT NULL,
    [ApproverName]            NVARCHAR (75) NOT NULL,
    [ApproverID]              NVARCHAR (20) NOT NULL,
    [ModifiedBy]              NVARCHAR (50) NOT NULL,
    [ModifiedOn]              DATETIME      NOT NULL,
    [TimeStamp]               BINARY (50)   NOT NULL,
    CONSTRAINT [PK_AppraisalApprovals] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [AppraisalApprovalID] ASC)
);

