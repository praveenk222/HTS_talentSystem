﻿    
  
-- =============================================    
-- AUTHOR: Shaun Kline    
-- CREATED DATE: 2009/06/24    
-- =============================================    
CREATE PROCEDURE [dbo].[DevelopmentPlanDetailsByDevelopmentPlanID]    
    
@DevelopmentPlanID int    
    
AS    
    
BEGIN    
    SELECT DevelopmentPlanDetailID,     
        DevelopmentPlanID,     
        Category,     
        Objective,     
        Activity,     
        SupportRequired,     
        DateDue,     
        MeasurementProcess,     
        CompletionId,    
  PointOfEntryId,    
  ActivityLoopId,    
  DevelopmentLoopId,    
   CompletionDate 'CompletionDate',  
  Result, 
        CreatedBy,     
        CreatedOn,    
        ModifiedBy,     
        ModifiedOn    
    FROM DevelopmentPlanDetails    
    WHERE DevelopmentPlanID = @DevelopmentPlanID    
 ORDER BY DateDue asc    
END