﻿CREATE TABLE [Archive].[AppraisalAttachments] (
    [ArchiveAppraisalAttachmentID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalAppraisalAttachmentID] INT            NOT NULL,
    [ArchiveAppraisalID]            INT            NOT NULL,
    [FileName]                      NVARCHAR (100) NOT NULL,
    [FileSize]                      INT            NOT NULL,
    [ContentType]                   NVARCHAR (100) NOT NULL,
    [Attachment]                    IMAGE          NOT NULL,
    [ModifiedBy]                    NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                    DATETIME       CONSTRAINT [DF_AppraisalAttachments_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_AppraisalAttachments] PRIMARY KEY CLUSTERED ([ArchiveAppraisalAttachmentID] ASC),
    CONSTRAINT [FK_AppraisalAttachments_Appraisals_Archive] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);


GO
CREATE TRIGGER [Archive].tr_AppraisalAttachments_PreventChanges     ON  Archive.AppraisalAttachments     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END