﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalRatings_Modify]

@Id int,
@Description varchar(50),
@IsDeleted bit,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.AppraisalRatings WHERE Id = @Id))
		BEGIN
			UPDATE AppraisalRatings
			SET Description = @Description, 
				IsDeleted = @IsDeleted, 
				ModifiedBy = @ModifiedBy, 
				ModifiedOn = @ModifiedOn
			WHERE Id = @ID
		END
    ELSE
		BEGIN
			INSERT INTO AppraisalRatings
			(Description, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@Description, @IsDeleted, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

		END
END