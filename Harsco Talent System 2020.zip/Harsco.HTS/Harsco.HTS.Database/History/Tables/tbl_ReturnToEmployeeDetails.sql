﻿CREATE TABLE [History].[tbl_ReturnToEmployeeDetails] (
    [CreatedOn]       DATETIME        NOT NULL,
    [ID]              INT             NOT NULL,
    [ManagerID]       INT             NOT NULL,
    [EmployeeID]      INT             NOT NULL,
    [ActionerID]      INT             NULL,
    [AppraisalTypeID] INT             NOT NULL,
    [ActionType]      NVARCHAR (150)  NULL,
    [Description]     NVARCHAR (1500) NOT NULL,
    [ModifiedBy]      NVARCHAR (50)   NOT NULL,
    [ModifiedOn]      DATETIME        NOT NULL,
    [IsActive]        BIT             NULL,
    CONSTRAINT [PK_tbl_ReturnToEmployeeDetails] PRIMARY KEY CLUSTERED ([ID] ASC)
);

