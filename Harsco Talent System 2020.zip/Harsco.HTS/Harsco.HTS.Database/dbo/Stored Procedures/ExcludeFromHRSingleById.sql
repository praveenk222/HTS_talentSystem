﻿

-- =========================================================================
-- Author:		Ed Blair
-- Create date: 8/15/2013
-- Description:	get a single ExcludeFromHR record
--
-- =========================================================================
CREATE PROCEDURE [dbo].[ExcludeFromHRSingleById]

@Id int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  SELECT Id, ADName, ELTFlag, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
  FROM dbo.ExcludeFromHR
  WHERE Id = @Id
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;