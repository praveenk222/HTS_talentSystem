﻿CREATE TABLE [History].[CompetencyComments] (
    [CreatedOn]           DATETIME      CONSTRAINT [DF_CompetencyComments_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CompetencyCommentID] INT           NOT NULL,
    [CompetencyID]        INT           NOT NULL,
    [Comment]             NVARCHAR (MAX)           NULL,
    [ManagerComment]      NVARCHAR (MAX)          CONSTRAINT [DF_CompetencyComments_ManagerComment_1] DEFAULT ('')  NULL,
    [CreatedBy]           VARCHAR (50)  NOT NULL,
    [Created]             DATETIME      NOT NULL,
    [ModifiedBy]          NVARCHAR (50) NOT NULL,
    [ModifiedOn]          DATETIME      NOT NULL,
    CONSTRAINT [PK_CompetencyComments] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CompetencyCommentID] ASC)
);

