﻿CREATE TABLE [History].[MilestoneStatus] (
    [CreatedOn]         DATETIME      CONSTRAINT [DF_MilestoneStatus_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [MilestoneStatusID] INT           NOT NULL,
    [Title]             NVARCHAR (50) NOT NULL,
    [IsDeleted]         BIT           NOT NULL,
    [ModifiedBy]        NVARCHAR (50) NOT NULL,
    [ModifiedOn]        DATETIME      NOT NULL,
    [TimeStamp]         BINARY (8)    NOT NULL,
    CONSTRAINT [PK_MilestoneStatus] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [MilestoneStatusID] ASC)
);

