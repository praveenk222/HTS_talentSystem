﻿



-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/12
-- =============================================
-- Exec [CompetenciesViewListbyAppraisalId] 8386
CREATE PROCEDURE  [dbo].[CompetenciesViewListbyAppraisalId]

@AppraisalId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT CompetencyId, AppraisalId, EnterpriseCompetencyID, EmployeeSkillRatingId, ManagerSkillRatingId, Comment, ManagerComment, Title, CompetencyCommentId
    FROM CompetenciesView
	WHERE AppraisalId = @AppraisalId
	ORDER BY Title
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;