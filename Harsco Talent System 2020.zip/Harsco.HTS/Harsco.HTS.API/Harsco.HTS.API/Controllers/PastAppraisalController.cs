﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using Harsco.HTS.API.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Harsco.HTS.ViewModels;
namespace Harsco.HTS.API.Controllers
{
	[EnableCors("AllowOrigin")]
	[ApiController]
	[Route("[controller]")]
	public class PastAppraisalController : Controller
	{
		//List<_MidYearAppraisal> objectivesListVM = new List<_MidYearAppraisal>();
		[HttpGet]
		[Route("GetPastAppraisals")]
		public IActionResult GetPastAppraisals(int ProfileId, int AppraisalID)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var AppraisalsByOriginalAppraisalID = db.PastAppraisals.FromSqlRaw("[Archive].[AppraisalsByOriginalAppraisalID] {0},{1}", AppraisalID, ProfileId).ToList();
					return Ok(AppraisalsByOriginalAppraisalID);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		[HttpGet]
		[Route("GetMidyearAppraisalPDF")]
		public IActionResult GetMidyearAppraisalPDF(int ProfileID, string AppraisalType)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var appraisaltype = db.AppraisalTypes.Where(p => p.Title == AppraisalType).SingleOrDefault();

					int a = ProfileID;
					int b = appraisaltype.AppraisalTypeId;
					string _lang = "en";

					var AppraisalsByOriginalAppraisalID = db._MidYearAppraisals.FromSqlRaw("Report_ArchivedMidYearById_Test {0},{1},{2}", a, b, _lang).ToList();

					return Ok(AppraisalsByOriginalAppraisalID);
					////Generate Dynamic HTML
					//string html= GetHTMLString(AppraisalsByOriginalAppraisalID.FirstOrDefault());

					////PDF Create section 
					//html = html.Replace("StrTag", "<").Replace("EndTag", ">");
					//HtmlToPdf oHtmlToPdf = new HtmlToPdf();
					//PdfDocument opdfDocument = oHtmlToPdf.ConvertHtmlString(html);
					//byte[] pdf = opdfDocument.Save();

					//opdfDocument.Close();

					//return File(pdf, "Application/pdf", "MidYearApprasial.pdf");
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



		// public IActionResult GeneratePDF( string html)
		//{
		//    html = html.Replace("StrTag", "<").Replace("EndTag", ">");
		//    HtmlToPdf oHtmlToPdf = new HtmlToPdf();
		//    PdfDocument opdfDocument = oHtmlToPdf.ConvertHtmlString(html);
		//    byte[] pdf = opdfDocument.Save();
		//    opdfDocument.Close();

		//return File(opdfDocument,"Application/pdf","MidYearApprasial.pdf");

		//}

		[HttpGet]
		[Route("GetHeaderInfo")]
		public IActionResult GetHeaderInfo(int profileID)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					//int p = 8849;

					var PastAppraisalHeaderInfo = db.ReportHeaderInfo.FromSqlRaw("[Archive].[ArchiveReport_GetHeaderInfo] {0}", profileID).ToList();
					return Ok(PastAppraisalHeaderInfo);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpGet]
		[Route("GetArchiveObjective")]
		public IActionResult GetArchiveObjective(int appraisalid)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					//  int appraisalid = 21335;
					var pastapprasialendofyearInfo = db.ArchiveObjectives.FromSqlRaw("[dbo].[Report_GetArchiveObjectivesByAppraisalId] {0}", appraisalid).ToList();
					return Ok(pastapprasialendofyearInfo);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpGet]
		[Route("GetArchiveValueBehaviors")]
		public IActionResult GetArchiveValueBehaviors(int appraisalid)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					//int appraisalid = 21335;
					var pastapprasialendofyearInfo = db.ArchivevalueBehaviors.FromSqlRaw("[dbo].[Report_GetArchiveCompetenciesByAppraisalId] {0}", appraisalid).ToList();
					return Ok(pastapprasialendofyearInfo);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		[HttpGet]
		[Route("GetArchiveApprasialSummary")]
		public IActionResult GetArchiveApprasialSummary(int appraisalid)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var pastapprasialendofyearInfo = db.ArchiveAppraisalSummary.FromSqlRaw("[dbo].[Report_GetArchiveAppraisalInformationByAppraisalId] {0}", appraisalid).ToList();
				return Ok(pastapprasialendofyearInfo);
			}
		}

		[HttpGet]
		[Route("GetMidYearArchiveObjectiveByID")]
		public IActionResult GetMidYearArchiveObjectiveByID(int ProfileID, string AppraisalType)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisaltype = db.AppraisalTypes.Where(p => p.Title == AppraisalType).SingleOrDefault();
				var archivemidobj = db.ArchiveMidEMPObj.FromSqlRaw("GetMidYearArchiveObjectiveByID {0},{1}", ProfileID, appraisaltype.AppraisalTypeId).ToList();
				return Ok(archivemidobj);
			}
		}

		[HttpGet]
		[Route("GetMidYearArchiveValuesByID")]
		public IActionResult GetMidYearArchiveValuesByID(int ProfileID, string AppraisalType)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisaltype = db.AppraisalTypes.Where(p => p.Title == AppraisalType).SingleOrDefault();
				var archivemidvalue = db.ArchiveMidValues.FromSqlRaw("GetMidYearArchiveValuesByID {0},{1}", ProfileID, appraisaltype.AppraisalTypeId).ToList();
				return Ok(archivemidvalue);
			}
		}

		[HttpGet]
		[Route("GetMidYearArchiveDevPlanByID")]
		public IActionResult GetMidYearArchiveDevPlanByID(int ProfileID, string AppraisalType)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisaltype = db.AppraisalTypes.Where(p => p.Title == AppraisalType).SingleOrDefault();
				var archiveDevvalue = db.ArchiveMidDevPlan.FromSqlRaw("GetMidYearArchiveDevPlanByID {0},{1}", ProfileID, appraisaltype.AppraisalTypeId).ToList();
				return Ok(archiveDevvalue);
			}
		}

		[HttpGet]
		[Route("GetMidYearArchiveObjective")]
		public IActionResult GetMidYearArchiveObjective(int ProfileID, string AppraisalType)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisaltype = db.AppraisalTypes.Where(p => p.Title == AppraisalType).SingleOrDefault();
				var archiveobj = db.archivemidyrobj.FromSqlRaw("GetMidYearArchiveObjective {0},{1}", ProfileID, appraisaltype.AppraisalTypeId).ToList();
				return Ok(archiveobj);
			}
		}
	}
}

