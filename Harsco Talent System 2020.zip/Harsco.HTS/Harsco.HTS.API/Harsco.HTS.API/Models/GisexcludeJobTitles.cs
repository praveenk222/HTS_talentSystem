﻿using System;
using System.Collections.Generic;

namespace Harsco.HTS.API.Models
{
    public partial class GisexcludeJobTitles
    {
        public string JobTitle { get; set; }
    }
}
