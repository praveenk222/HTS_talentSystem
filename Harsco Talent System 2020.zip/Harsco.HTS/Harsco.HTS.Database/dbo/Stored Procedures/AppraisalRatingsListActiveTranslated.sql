﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/17/2012
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalRatingsListActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AppraisalRatings.Id, ISNULL(Translations.TranslatedText,AppraisalRatings.Description) as Description, IsDeleted, 
		AppraisalRatings.CreatedBy, AppraisalRatings.CreatedOn, AppraisalRatings.ModifiedBy, AppraisalRatings.ModifiedOn
    FROM AppraisalRatings
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = AppraisalRatings.Description 
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = TranslationLanguageId
			and Code = @TranslationCode
	WHERE IsDeleted = 0
	Order by ISNULL(Translations.TranslatedText,AppraisalRatings.Description)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;