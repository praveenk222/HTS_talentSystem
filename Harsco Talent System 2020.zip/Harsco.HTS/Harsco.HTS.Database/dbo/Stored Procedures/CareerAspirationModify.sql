﻿

-- =============================================
-- Author:		Ed Blair
-- Create date: 09/24/2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CareerAspirationModify]

@Id int,
@ProfileID int,
@Aspiration ntext,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy varchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM [dbo].[CareerAspiration] WHERE @Id=Id))
		BEGIN
			UPDATE [dbo].[CareerAspiration] SET 
				ProfileID = @ProfileID,
				Aspiration = @Aspiration,
				ModifiedBy = @ModifiedBy,
				ModifiedOn = @ModifiedOn
			WHERE Id = @Id			
		END
    ELSE
		BEGIN
			INSERT INTO [dbo].[CareerAspiration]
			(ProfileID, Aspiration, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@ProfileID, @Aspiration, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

		END
END