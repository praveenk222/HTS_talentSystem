﻿CREATE TABLE [Archive].[LicsCertsProfOrgs] (
    [ArchiveLicCertProfOrgID]      INT           IDENTITY (1, 1) NOT NULL,
    [OriginalLicCertProfOrgID]     INT           NOT NULL,
    [ArchiveProfileID]             INT           NOT NULL,
    [Description]                  NTEXT         NOT NULL,
    [LicenseCategory]              NVARCHAR (50) NOT NULL,
    [LicenseNumber]                NVARCHAR (20) NULL,
    [CertificationNumber]          NVARCHAR (20) NULL,
    [ProfessionalOrganizationName] NVARCHAR (50) NULL,
    [DateReceived]                 DATETIME      NULL,
    [ExpirationDate]               DATETIME      NULL,
    [ModifiedBy]                   NVARCHAR (50) NOT NULL,
    [ModifiedOn]                   DATETIME      CONSTRAINT [DF_LicsCertsProfOrgs_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_LicsCertsProfOrgs] PRIMARY KEY CLUSTERED ([ArchiveLicCertProfOrgID] ASC),
    CONSTRAINT [FK_LicsCertsProfOrgs_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);




GO
CREATE TRIGGER [Archive].[tr_LicsCertsProfOrgs_PreventChanges]     ON  Archive.LicsCertsProfOrgs     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END