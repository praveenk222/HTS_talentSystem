﻿

-- ==================================================================      
-- Author:  Praveen    
-- Create date: 02/22//2023    
-- Description:       
--       
-- Modifications:      
-- Exec [CompetencyManagerApproval] 'JReddy'      
-- ==================================================================      
CREATE PROCEDURE [dbo].[CompetencyManagerApproval]       
@CurrentUser varchar(50)      
AS      
BEGIN      
 SET NOCOUNT ON      
 BEGIN      
      
  --DECLARE @ManagerId int      
  --SELECT @ManagerId = ProfileID FROM Profiles WHERE NetworkId = @CurrentUser 
  
	DECLARE @CurrentUserId NVARCHAR(300)

	SELECT @CurrentUserId = NetworkID FROM Profiles WHERE ProfileID = @CurrentUser
        
	SELECT S.*,  ER.Title as EmpRatingDesc, MR.Title as MngrRatingDesc,P.EmployeeName as [EmployeeName] 
	FROM   Skills S    
	LEFT JOIN SkillRatings MR ON S.MngrRating = MR.SkillRatingID    
	LEFT JOIN SkillRatings ER ON S.EmpRating = ER.SkillRatingID 
	LEFT JOIN Profiles P ON P.ProfileID = S.ProfileId
	WHERE  S.ApproverID=@CurrentUserId and S.ApprovalStatusID=2    
	ORDER BY S.ModifiedOn DESC    
	--AND TerminationDate IS NULL      
	--AND Profiles.Networkid NOT IN ('removed','Duplicate','pdecker')      
	--AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)      
	--AND Profiles.TerminationDate IS NULL      
 END      
 SET NOCOUNT OFF      
END