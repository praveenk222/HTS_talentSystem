﻿CREATE TABLE [History].[LanguageFluency] (
    [CreatedOn]         DATETIME      CONSTRAINT [DF_LanguageFluency_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [LanguageFluencyID] INT           NOT NULL,
    [Title]             NVARCHAR (50) NOT NULL,
    [IsDeleted]         BIT           NOT NULL,
    [ModifiedBy]        NVARCHAR (50) NOT NULL,
    [ModifiedOn]        DATETIME      NOT NULL,
    [TimeStamp]         BINARY (50)   NOT NULL,
    CONSTRAINT [PK_LanguageFluency] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [LanguageFluencyID] ASC)
);

