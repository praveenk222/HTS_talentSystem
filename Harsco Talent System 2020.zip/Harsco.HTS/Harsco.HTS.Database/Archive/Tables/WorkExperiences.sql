﻿CREATE TABLE [Archive].[WorkExperiences] (
    [ArchiveWorkExperienceID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalWorkExperienceID] INT            NOT NULL,
    [ArchiveProfileID]         INT            NOT NULL,
    [EmployerName]             NVARCHAR (75)  NOT NULL,
    [JobTitle]                 VARCHAR (255)  NOT NULL,
    [Address]                  NVARCHAR (255) NOT NULL,
    [DateEmploymentStarted]    SMALLDATETIME  NOT NULL,
    [DateEmploymentEnded]      SMALLDATETIME  NULL,
    [ModifiedBy]               NVARCHAR (50)  NOT NULL,
    [ModifiedOn]               DATETIME       CONSTRAINT [DF_WorkExperiences_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_WorkExperiences_1] PRIMARY KEY CLUSTERED ([ArchiveWorkExperienceID] ASC),
    CONSTRAINT [FK_WorkExperiences_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);




GO
CREATE TRIGGER [Archive].[tr_WorkExperiences_PreventChanges]     ON  Archive.WorkExperiences     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END