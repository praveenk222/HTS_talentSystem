﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_AppraisalApprovals_GetByArchiveAppraisalID]
    @ArchiveAppraisalID int
AS
BEGIN
    SELECT ArchiveAppraisalApprovalID, 
        ArchiveAppraisalID, 
        Comment, 
        ApprovalStatus, 
        StatusChangedDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM AppraisalApprovals
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID
END