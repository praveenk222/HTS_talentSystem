﻿CREATE TABLE [History].[DevelopmentPlanComments] (
    [CreatedOn]                        DATETIME      CONSTRAINT [DF_DevelopmentPlanComments_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [DevelopmentPlanCommentID]         INT           NOT NULL,
    [DevelopmentPlanStrengthID]        INT           NULL,
    [DevelopmentPlanStrengthTimeStamp] BINARY (8)    NULL,
    [DevelopmentPlanWeaknessID]        INT           NULL,
    [DevelopmentPlanWeaknessTimeStamp] BINARY (8)    NULL,
    [DevelopmentPlanDetailID]          INT           NULL,
    [DevelopmentPlanDetailTimeStamp]   BINARY (8)    NULL,
    [Comment]                          NTEXT         NOT NULL,
    [Confidential]                     BIT           CONSTRAINT [DF_DevelopmentPlanComments_Confidential_1] DEFAULT ((0)) NOT NULL,
    [CommentTypeID]                    INT           NOT NULL,
    [CommentTypeTimeStamp]             BINARY (8)    NULL,
    [ModifiedBy]                       NVARCHAR (50) NOT NULL,
    [ModifiedOn]                       DATETIME      NOT NULL,
    [TimeStamp]                        BINARY (8)    NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanComments] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanCommentID] ASC)
);

