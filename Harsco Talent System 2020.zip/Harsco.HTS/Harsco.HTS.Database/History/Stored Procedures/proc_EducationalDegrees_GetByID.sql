﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_EducationalDegrees_GetByID]
    @EducationalDegreeID int
AS
BEGIN
    SELECT CreatedOn, 
        EducationalDegreeID, 
        Abbreviation, 
        Title, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM EducationalDegrees
    WHERE EducationalDegreeID = @EducationalDegreeID
    ORDER BY CreatedOn Desc
END