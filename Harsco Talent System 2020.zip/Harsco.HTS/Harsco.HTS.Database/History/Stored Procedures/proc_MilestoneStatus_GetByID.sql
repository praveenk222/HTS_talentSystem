﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_MilestoneStatus_GetByID]
    @MilestoneStatusID int
AS
BEGIN
    SELECT CreatedOn, 
        MilestoneStatusID, 
        Title, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM MilestoneStatus
    WHERE MilestoneStatusID = @MilestoneStatusID
    ORDER BY CreatedOn Desc
END