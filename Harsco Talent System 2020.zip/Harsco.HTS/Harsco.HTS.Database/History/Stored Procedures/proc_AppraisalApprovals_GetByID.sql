﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_AppraisalApprovals_GetByID]
    @AppraisalApprovalID int
AS
BEGIN
    SELECT CreatedOn, 
        AppraisalApprovalID, 
        AppraisalID, 
        AppraisalTimeStamp, 
        Comment, 
        ApprovalStatusID, 
        ApprovalStatusTimeStamp, 
        StatusChangedDate, 
        ApproverName, 
        ApproverID, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM AppraisalApprovals
    WHERE AppraisalApprovalID = @AppraisalApprovalID
    ORDER BY CreatedOn Desc
END