﻿

-- =========================================================================
-- Author:		Ed Blair
-- Create date: 8/15/2013
-- Description:	get ExcludeFromHRs for admin grid
--
-- =========================================================================
CREATE PROCEDURE [dbo].[ExcludeFromHRAdminGrid]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  SELECT Id, ADName, EmployeeName, ELTFlag
  FROM dbo.ExcludeFromHR
	LEFT JOIN dbo.Profiles ON dbo.Profiles.NetworkId = dbo.ExcludeFromHR.ADName
  WHERE EmployeeName IS NOT NULL
ORDER BY EmployeeName	
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;