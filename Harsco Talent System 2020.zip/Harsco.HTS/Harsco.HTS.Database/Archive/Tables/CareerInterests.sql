﻿CREATE TABLE [Archive].[CareerInterests] (
    [ArchiveCareerInterestID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalCareerInterestID] INT           NOT NULL,
    [ArchiveProfileID]         INT           NOT NULL,
    [Description]              NTEXT         NOT NULL,
    [JobFamily]                NVARCHAR (50) NOT NULL,
    [CareerInterestTiming]     NVARCHAR (50) NOT NULL,
    [WillingToRelocate]        VARCHAR (50)  NOT NULL,
    [ModifiedBy]               NVARCHAR (50) NOT NULL,
    [ModifiedOn]               DATETIME      CONSTRAINT [DF_CareerInterests_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_CareerInterests] PRIMARY KEY CLUSTERED ([ArchiveCareerInterestID] ASC),
    CONSTRAINT [FK_CareerInterests_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);


GO
CREATE TRIGGER [Archive].[tr_CareerInterests_PreventChanges]     ON  Archive.CareerInterests     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END