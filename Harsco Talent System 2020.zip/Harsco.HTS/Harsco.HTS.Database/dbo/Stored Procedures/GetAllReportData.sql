﻿-- =========================================================================      
-- Author:  Tejal Shah      
-- Create date: 6/01/2020      
-- Description: get all report data      
-- [dbo].[GetAllReportData] 17, '','','','','','en' ,'9'     
-- =========================================================================      
  
  
CREATE Procedure [dbo].[GetAllReportData]  
 @AppraisalTypeId int,   
 @CountryID varchar(1000),    
 @DivisionID varchar(1000),    
 @JobFamilyID varchar(1000),    
 @ManagerId varchar(50),  
 @Location Varchar(255) ,  
 @LanguageCode varchar(20),  
 @ReportID varchar(50)   
  
  
AS  
  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
BEGIN TRANSACTION;  
SET NOCOUNT ON  
BEGIN  
  
 DECLARE @Proc nvarchar(max)      
 SELECT  @Proc = ProcedureName     
 FROM ReportMaster      
 WHERE ReportID = @ReportID  
 --  PRINT @Proc  
 if @Proc != ''      
 BEGIN      
  EXECUTE  @Proc @AppraisalTypeId,@CountryID,@DivisionID,@JobFamilyID,@ManagerId,@Location,@LanguageCode  
 END    
  
END  
SET NOCOUNT OFF      
COMMIT TRANSACTION;