﻿CREATE TABLE [History].[Competencies] (
    [CreatedOn]              DATETIME      CONSTRAINT [DF_Competencies_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CompetencyID]           INT           NOT NULL,
    [AppraisalID]            INT           NOT NULL,
    [EnterpriseCompetencyID] INT           NOT NULL,
    [EmployeeSkillRatingId]  INT           NULL,
    [ManagerSkillRatingId]   NCHAR (10)    NULL,
    [CreatedBy]              VARCHAR (50)  NULL,
    [Created]                DATETIME      NULL,
    [ModifiedBy]             NVARCHAR (50) NOT NULL,
    [ModifiedOn]             DATETIME      NOT NULL,
    CONSTRAINT [PK_Competencies] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CompetencyID] ASC)
);

