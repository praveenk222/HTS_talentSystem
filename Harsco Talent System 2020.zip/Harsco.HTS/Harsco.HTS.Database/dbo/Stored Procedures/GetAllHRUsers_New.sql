﻿CREATE PROCEDURE [dbo].[GetAllHRUsers_New]  
AS  
BEGIN  

	SET NOCOUNT ON;  
	SELECT HU.HRUserId, HU.UserName, HU.SecurityUser, HU.SuperUser, p.EmployeeName, p.ProfileID    
	FROM dbo.HRUsers_New HU  
	JOIN dbo.Profiles p ON HU.UserName = P.NetworkID
	WHERE P.NetworkID NOT IN ('removed')
	AND P.TerminationDate IS NULL
 
END