﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanWeaknesses_GetByID]
    @ArchiveDevelopmentPlanWeaknessID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanWeaknessID, 
        ArchiveDevelopmentPlanID, 
        Weakness, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanWeaknesses
    WHERE ArchiveDevelopmentPlanWeaknessID = @ArchiveDevelopmentPlanWeaknessID
END