﻿
-- =============================================      
-- Author:  <Tejal Shah>      
-- Create date: <08/10/2020>      
-- Description: <Close complete appraisal period cycle>
-- ============================================= 

-- EXEC [dbo].[CloseAllAppraisal] 20
CREATE PROCEDURE [dbo].[CloseAllAppraisal]     
	@AppraisalTypeId INT       
AS    
BEGIN    
	--SET NOCOUNT ON    
	BEGIN TRANSACTION;    
	-- End of year cycle    
	BEGIN TRY
			
		DECLARE @Count int    
		DECLARE @RowNumber int    
		DECLARE @EmployeeName varchar(300)    
		DECLARE @Appraisalid int 

		DECLARE @NewProfiles TABLE
		(    
			Id int Identity(1,1),    
			AppraisalID int,    
			AppraisalTypeID  int,    
			COCViolation varchar(1),    
			ManagerMeeting varchar(1),    
			PerformanceRating ntext,    
			CompetencyRating ntext,    
			OverallRating ntext,    
			ReviewDate smalldatetime,    
			SelfAssessmentComplete bit,    
			ManagerStepComplete bit,    
			EmployeeComment ntext,    
			ManagerComment ntext,    
			ObjectiveComment ntext,    
			CompetencyComment ntext,    
			SkillComment ntext,    
			EmployeeName nvarchar(75),    
			EmployeeSignDate datetime,    
			ManagerName nvarchar(75),    
			ManagerSignDate datetime,    
			ManagersManagerName nvarchar(75),    
			ManagersManagerSignDate datetime,    
			ModifiedBy nvarchar(50),    
			ModifiedOn datetime    
			--[TimeStamp] timestamp DEFAULT CURRENT_TIMESTAMP    
		)    
	
		INSERT  @NewProfiles    
		EXEC [dbo].[AppraisalsNeedManagerManagerSignoff] @AppraisalTypeId 
	
		SET @Count = @@ROWCOUNT  
		PRINT 'Count' PRINT @Count

		SET @RowNumber = 1    
		WHILE @RowNumber <= @Count    
		BEGIN    
			SELECT --@EmployeeName=EmployeeName,
				@Appraisalid=AppraisalID 
			FROM 
				@NewProfiles     
			WHERE 
				Id=@RowNumber    
      
			UPDATE Appraisals set 
				EmployeeName = ISNULL(EmployeeName, 'HR Close'),
				EmployeeSignDate = ISNULL(EmployeeSignDate, GETDATE()),
				ManagerName = ISNULL(ManagerName, 'HR Close'),
				ManagerSignDate = ISNULL(ManagerSignDate, GETDATE()),
				ManagersManagerName='HR Close',    
				ManagersManagerSignDate= ISNULL(ManagersManagerSignDate, GETDATE()),
				ModifiedBy='Auto HR Close' ,    
				ModifiedOn=GETDATE()    
			WHERE AppraisalID=@Appraisalid    
      
			EXEC [dbo].[proc_Appraisal_Archive] @Appraisalid
		
			SET @RowNumber = @RowNumber + 1  
		END    
	
		SELECT 'Success' as [Status]

		COMMIT TRANSACTION;    
	END TRY    
	BEGIN CATCH    
		ROLLBACK TRANSACTION    
		SELECT 'false' as [Status]    
		INSERT INTO tbl_Errors(ErrorNumber,ErrorState,ErrorSeverity,ErrorLine,ErrorProcedure,ErrorMessage,ErrorDateTime )        
		SELECT          
			ERROR_NUMBER() AS ErrorNumber, ERROR_STATE() AS ErrorState, ERROR_SEVERITY() AS ErrorSeverity         
			,ERROR_LINE() AS ErrorLine, ERROR_PROCEDURE() AS ErrorProcedure, ERROR_MESSAGE() AS ErrorMessage, GETDATE()        
	END CATCH    
END