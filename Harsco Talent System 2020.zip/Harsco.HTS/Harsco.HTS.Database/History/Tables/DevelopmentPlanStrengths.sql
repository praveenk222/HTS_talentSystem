﻿CREATE TABLE [History].[DevelopmentPlanStrengths] (
    [CreatedOn]                 DATETIME      CONSTRAINT [DF_DevelopmentPlanStrengths_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [DevelopmentPlanStrengthID] INT           NOT NULL,
    [DevelopmentPlanID]         INT           NOT NULL,
    [DevelopmentPlanTimeStamp]  BINARY (8)    NOT NULL,
    [Strength]                  NTEXT         NOT NULL,
    [ModifiedBy]                NVARCHAR (50) NOT NULL,
    [ModifiedOn]                DATETIME      NOT NULL,
    [TimeStamp]                 BINARY (50)   NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanStrengths] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanStrengthID] ASC)
);

