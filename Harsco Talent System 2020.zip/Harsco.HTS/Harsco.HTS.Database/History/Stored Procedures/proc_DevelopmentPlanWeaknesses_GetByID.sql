﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlanWeaknesses_GetByID]
    @DevelopmentPlanWeaknessID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanWeaknessID, 
        DevelopmentPlanID, 
        DevelopmentPlanTimeStamp, 
        Weakness, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM DevelopmentPlanWeaknesses
    WHERE DevelopmentPlanWeaknessID = @DevelopmentPlanWeaknessID
    ORDER BY CreatedOn Desc
END