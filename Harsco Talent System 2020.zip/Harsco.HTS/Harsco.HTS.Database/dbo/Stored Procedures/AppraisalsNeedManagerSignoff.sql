﻿-- =============================================    
-- AUTHOR: Ed Blair    
-- CREATED DATE: 07/26/2012     
-- AppraisalsNeedManagerSignoff 2    
-- =============================================    
CREATE PROCEDURE [dbo].[AppraisalsNeedManagerSignoff]    
@AppraisalTypeID int    
AS    
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;    
BEGIN TRANSACTION;    
SET NOCOUNT ON    
BEGIN    
    
    SELECT Appraisals.AppraisalID,     
        AppraisalTypeID,     
        COCViolation,     
        ManagerMeeting,    
        PerformanceRating,     
        CompetencyRating,     
        OverallRating,     
        ReviewDate,     
        SelfAssessmentComplete,     
        ManagerStepComplete,     
        EmployeeComment,     
        ManagerComment,     
        ObjectiveComment,     
        CompetencyComment,     
        SkillComment,     
        Appraisals.EmployeeName,     
        EmployeeSignDate,     
        ManagerName,     
        ManagerSignDate,     
        ManagersManagerName,     
        ManagersManagerSignDate,     
        Appraisals.ModifiedBy,     
        Appraisals.ModifiedOn   
      --  [TimeStamp]    
    FROM Appraisals    
  INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID    
 WHERE ManagerSignDate IS NULL    
 AND NetworkId NOT IN ('Removed','Duplicate')    
 AND NetworkID NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)    
 AND AppraisalTypeID = @AppraisalTypeID    
 AND TerminationDate IS NULL    
    
END    
SET NOCOUNT OFF    
COMMIT TRANSACTION;








