﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_CompetencyApprovals_GetByID]
    @ArchiveCompetencyApprovalID int
AS
BEGIN
    SELECT ArchiveCompetencyApprovalID, 
        ArchiveCompetencyID, 
        ArchiveSkillID, 
        ApprovalStatus, 
        Comment, 
        StatusChangedDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM CompetencyApprovals
    WHERE ArchiveCompetencyApprovalID = @ArchiveCompetencyApprovalID
END