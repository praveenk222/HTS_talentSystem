﻿CREATE TABLE [History].[CareerInterests] (
    [CreatedOn]                     DATETIME      CONSTRAINT [DF_CareerInterests_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CareerInterestID]              INT           NOT NULL,
    [EmployeeProfileID]             INT           NOT NULL,
    [Description]                   NTEXT         NOT NULL,
    [JobFamilyID]                   INT           NOT NULL,
    [CareerInterestTimingID]        INT           NOT NULL,
    [WillingToRelocate]             VARCHAR (50)  NULL,
    [CareerInterestTimingTimeStamp] BINARY (8)    NOT NULL,
    [ModifiedBy]                    NVARCHAR (50) NOT NULL,
    [ModifiedOn]                    DATETIME      NOT NULL,
    [TimeStamp]                     BINARY (50)   NOT NULL,
    CONSTRAINT [PK_CareerInterests] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CareerInterestID] ASC)
);

