﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_UnderstoodLanguages_GetByArchiveProfileID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveUnderstoodLanguageID, 
        ArchiveProfileID, 
        Language, 
        Description, 
        LanguageFluency, 
        ModifiedBy, 
        ModifiedOn
    FROM UnderstoodLanguages
    WHERE ArchiveProfileID = @ArchiveProfileID
END