﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanStrengths_GetByID]
    @ArchiveDevelopmentPlanStrengthID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanStrengthID, 
        ArchiveDevelopmentPlanID, 
        Strength, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanStrengths
    WHERE ArchiveDevelopmentPlanStrengthID = @ArchiveDevelopmentPlanStrengthID
END