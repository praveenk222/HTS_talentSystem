﻿CREATE TABLE [Archive].[AppraisalApprovals] (
    [ArchiveAppraisalApprovalID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalAppraisalApprovalID] INT           NOT NULL,
    [ArchiveAppraisalID]          INT           NOT NULL,
    [Comment]                     NTEXT         NOT NULL,
    [ApprovalStatus]              NVARCHAR (50) NOT NULL,
    [StatusChangedDate]           DATETIME      NOT NULL,
    [ApproverName]                NVARCHAR (75) NOT NULL,
    [ApproverID]                  NVARCHAR (20) NOT NULL,
    [ModifiedBy]                  NVARCHAR (50) NOT NULL,
    [ModifiedOn]                  DATETIME      CONSTRAINT [DF_AppraisalApprovals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_AppraisalApprovals] PRIMARY KEY CLUSTERED ([ArchiveAppraisalApprovalID] ASC),
    CONSTRAINT [FK_AppraisalApproval_Appraisals_Archive] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);


GO
CREATE TRIGGER [Archive].tr_AppraisalApprovals_PreventChanges     ON  Archive.AppraisalApprovals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END