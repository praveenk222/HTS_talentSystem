﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_AppraisalApprovals_GetByID]
    @ArchiveAppraisalApprovalID int
AS
BEGIN
    SELECT ArchiveAppraisalApprovalID, 
        ArchiveAppraisalID, 
        Comment, 
        ApprovalStatus, 
        StatusChangedDate, 
        ApproverName,
        ApproverID,
        ModifiedBy, 
        ModifiedOn
    FROM AppraisalApprovals
    WHERE ArchiveAppraisalApprovalID = @ArchiveAppraisalApprovalID
END