﻿

-- =========================================================================
-- Author:		Ed Blair
-- Create date: 3/5/2015
-- Description:	get apprasial period based on date
--
-- =========================================================================
CREATE PROCEDURE [dbo].[GetAppraisalTypeByDate]

@CheckDate datetime

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @ThisYear int
    DECLARE @AppraisalId int
    DECLARE @TestNumber int
    DECLARE @StartDate datetime
    
    set @Startdate = @CheckDate
    
	SET @ThisYear = Year(getdate()) 
	SELECT @AppraisalId=AppraisalTypeID
	FROM AppraisalTypes
	WHERE Title=convert(varchar(10),@ThisYear)+' Mid-Year'

	SELECT @TestNumber = DATEDIFF("d",'5/10/' + convert(varchar(10),@ThisYear), @StartDate)
	If @TestNumber > 0
	BEGIN
		SELECT @AppraisalId=AppraisalTypeID
		FROM AppraisalTypes
		WHERE Title=convert(varchar(10),@ThisYear)+' End of Year'
	END
	
	SELECT @TestNumber = DATEDIFF("d",'9/1/' + convert(varchar(10),@ThisYear), @StartDate)
	If @TestNumber > 0
	BEGIN
		SELECT @AppraisalId=AppraisalTypeID
		FROM AppraisalTypes
		WHERE Title=convert(varchar(10),(@ThisYear+1))+' Mid-Year'
	END
	        
   SELECT @AppraisalId as AppraislTypeID

END
SET NOCOUNT OFF
COMMIT TRANSACTION;