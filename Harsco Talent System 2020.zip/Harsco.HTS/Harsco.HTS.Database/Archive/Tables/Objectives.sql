﻿CREATE TABLE [Archive].[Objectives] (
    [ArchiveObjectiveID]    INT           IDENTITY (1, 1) NOT NULL,
    [OriginalObjectiveID]   INT           NOT NULL,
    [ArchiveAppraisalID]    INT           NOT NULL,
    [Description]           NTEXT         NOT NULL,
    [YearEndResults]        NTEXT         NOT NULL,
    [ManagerYearEndResults] NTEXT         CONSTRAINT [DF_Objectives_ManagerYearEndResults_1] DEFAULT ('') NOT NULL,
    [DateDue]               SMALLDATETIME NOT NULL,
    [Achieved]              NVARCHAR (50) CONSTRAINT [DF_Objectives_Achieved_1] DEFAULT ((0)) NULL,
    [ManagerAchieved]       NVARCHAR (50) CONSTRAINT [DF_Objectives_ManagerAchieved] DEFAULT ('') NULL,
    [CreatedBy]             VARCHAR (50)  NOT NULL,
    [CreatedOn]             DATETIME      NOT NULL,
    [ModifiedBy]            NVARCHAR (50) NOT NULL,
    [ModifiedOn]            DATETIME      CONSTRAINT [DF_Objectives_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Objectives_1] PRIMARY KEY CLUSTERED ([ArchiveObjectiveID] ASC),
    CONSTRAINT [FK_Objectives_Appraisals] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);


GO
CREATE TRIGGER [Archive].[tr_Objectives_PreventChanges]     ON  Archive.Objectives     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END