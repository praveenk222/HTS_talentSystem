﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.Plotform.Helpers;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
	[EnableCors("AllowOrigin")]
	[ApiController]
	[Route("[controller]")]
	public class ProfileController : ControllerBase
	{
		private IConfiguration _iconfiguration;

		public ProfileController(IConfiguration iconfiguration)
		{
			_iconfiguration = iconfiguration;
		}

		[HttpGet]
		[Route("Welcome")]
		public IActionResult Welcome()
		{
			return Ok("Welcome");
		}

		#region WorkExperienceComponent

		/// <summary>
		/// Get Work Experience Details based on ProfileID
		/// </summary>
		/// <param name="profileID"></param>
		/// <returns></returns>
		[HttpGet]
		[Route("GetWorkExpDetailsByID")]
		public IActionResult GetWorkExpDetailsByProfileID(int profileID)
		{
			List<vmWorkExp> workExpList = new List<vmWorkExp>();

			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var workExpDetails = db.WorkExperiences.Where(p => p.ProfileId == profileID).ToList();
				foreach (var workExp in workExpDetails)
				{
					vmWorkExp workExpVM = new vmWorkExp();
					workExpVM.WorkExperienceId = workExp.WorkExperienceId;
					workExpVM.ProfileId = workExp.ProfileId;
					workExpVM.EmployerName = workExp.EmployerName;
					workExpVM.JobTitle = workExp.JobTitle;
					workExpVM.Address = workExp.Address;
					workExpVM.DateEmploymentStarted = workExp.DateEmploymentStarted;
					workExpVM.DateEmploymentEnded = workExp.DateEmploymentEnded;
					workExpVM.CreatedBy = workExp.CreatedBy;
					workExpVM.CreatedOn = workExp.CreatedOn;
					workExpVM.ModifiedBy = workExp.ModifiedBy;
					workExpVM.ModifiedOn = workExp.ModifiedOn;

					workExpList.Add(workExpVM);
				}

				return Ok(workExpList.OrderByDescending(w => w.DateEmploymentEnded));
			}
		}

		/// <summary>
		/// Updates the Work Experience model
		/// </summary>
		/// <param name="workExpVM"></param>
		/// <returns></returns>
		[HttpPost]
		[Route("UpdateWorkExperience")]
		public IActionResult UpdateWorkExperience(vmWorkExp workExpVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var workExpdbModel = db.WorkExperiences.Where(p => p.WorkExperienceId == workExpVM.WorkExperienceId).FirstOrDefault();

				workExpdbModel.EmployerName = workExpVM.EmployerName;
				workExpdbModel.JobTitle = workExpVM.JobTitle;
				workExpdbModel.Address = workExpVM.Address;
				workExpdbModel.DateEmploymentStarted = workExpVM.DateEmploymentStarted;
				workExpdbModel.DateEmploymentEnded = workExpVM.DateEmploymentEnded;

				workExpdbModel.ModifiedOn = DateTime.Now;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateWorkExperience")]
		public IActionResult CreateWorkExperience(vmWorkExp workExpVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				WorkExperiences workExperienceDB = new WorkExperiences();

				workExpVM.BindModelTo(workExperienceDB);

				workExperienceDB.ModifiedOn = DateTime.UtcNow;
				workExperienceDB.CreatedOn = DateTime.UtcNow;
				workExperienceDB.CreatedBy = workExpVM.CreatedBy; //need to change
				workExperienceDB.ModifiedBy = workExpVM.ModifiedBy;
				db.WorkExperiences.Add(workExperienceDB);

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteWorkExperience")]
		public IActionResult DeleteWorkExperience(vmWorkExp workExpModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var workExpDB = db.WorkExperiences.Where(p => p.WorkExperienceId == workExpModel.WorkExperienceId).SingleOrDefault();
				db.WorkExperiences.Remove(workExpDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteEducation")]
		public IActionResult DeleteEducation(vmEducation educationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var educationDB = db.EducationalInstitutions.Where(p => p.EducationalInstitutionId == educationVM.EducationalInstitutionId).SingleOrDefault();
				db.EducationalInstitutions.Remove(educationDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteTrainingAndDev")]
		public IActionResult DeleteTrainingAndDev(vmTrainingDevelopment trainingDevelopmentVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var trainingDevDB = db.TrainingDevelopment.Where(p => p.TrainingDevelopmentId == trainingDevelopmentVM.TrainingDevelopmentId).SingleOrDefault();
				db.TrainingDevelopment.Remove(trainingDevDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteAwardsPatentsRec")]
		public IActionResult DeleteAwardsPatentsRec(vmAwardsPatentsRecognitions awardsPatentsRecognitionsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var awardsPatentsRecognitionsDB = db.AwardsPatentsRecognitions.Where(p => p.AwardPatentRecognitionId == awardsPatentsRecognitionsVM.AwardPatentRecognitionId).SingleOrDefault();
				db.AwardsPatentsRecognitions.Remove(awardsPatentsRecognitionsDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteLicsCerts")]
		public IActionResult DeleteLicsCerts(vmLicsCertsProfOrgs licsCertsProfOrgsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var licsCertsProfOrgsDB = db.LicsCertsProfOrgs.Where(p => p.LicCertProfOrgId == licsCertsProfOrgsVM.LicCertProfOrgId).SingleOrDefault();
				db.LicsCertsProfOrgs.Remove(licsCertsProfOrgsDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteLanguage")]
		public IActionResult DeleteLanguage(vmUnderstoodLanguages understoodLanguagesVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var understoodLanguagesDB = db.UnderstoodLanguages.Where(p => p.UnderstoodLanguageId == understoodLanguagesVM.UnderstoodLanguageId).SingleOrDefault();
				db.UnderstoodLanguages.Remove(understoodLanguagesDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteCareerAspiration")]
		public IActionResult DeleteCareerAspiration(vmCareerAspiration careerAspirationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var CareerAspirationDB = db.CareerAspiration.Where(p => p.Id == careerAspirationVM.Id).SingleOrDefault();
				db.CareerAspiration.Remove(CareerAspirationDB);
				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("DeleteCareerInterest")]
		public IActionResult DeleteCareerInterest(vmCareerInterests careerInterestsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var careerInterestsDB = db.CareerInterests.Where(p => p.CareerInterestId == careerInterestsVM.CareerInterestId).SingleOrDefault();
				db.CareerInterests.Remove(careerInterestsDB);
				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		/// <summary>
		/// Gets the degree master table values
		/// </summary>
		/// <returns></returns>
		[HttpGet]
		[Route("GetDegrees")]
		public IActionResult GetEducationalDegrees()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var educationalDegrees = db.EducationalDegrees.ToList();

				return Ok(educationalDegrees);
			}
		}

		[HttpGet]
		[Route("GetLicenseCategories")]
		public IActionResult GetLicenseCategories()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var licenseCategories = db.LicenseCategories.ToList();

				return Ok(licenseCategories);
			}
		}

		[HttpGet]
		[Route("GetJobFamilyMaster")]
		public IActionResult GetJobFamilyMaster()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var jobFamiliesLst = db.CareerInterestsJobFamily.ToList();

				return Ok(jobFamiliesLst);
			}
		}

		[HttpGet]
		[Route("GetCareerInterestTiming")]
		public IActionResult GetCareerInterestTiming()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var careerInterestTimingLst = db.CareerInterestTiming.ToList();

				return Ok(careerInterestTimingLst);
			}
		}

		[HttpGet]
		[Route("GetWillingToRelocate")]
		public IActionResult GetWillingToRelocate()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var WillingToRelocateLst = db.WillingToRelocate.ToList();

				return Ok(WillingToRelocateLst);
			}
		}

		#endregion WorkExperienceComponent

		#region Education Component

		/// <summary>
		/// Gets Education Details Based on Profile ID
		/// </summary>
		/// <param name="profileID"></param>
		/// <returns></returns>
		[HttpGet]
		[Route("GetEducationDetailsByID")]
		public IActionResult GetEducationDetailsByProfileID(int profileID)
		{
			List<vmEducation> educationList = new List<vmEducation>();
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var educationalDetails = db.EducationalInstitutions.Include(x => x.EducationalDegree).Where(p => p.ProfileId == profileID).ToList();

				foreach (var educationalDetail in educationalDetails)
				{
					vmEducation education = new vmEducation();

					education.ProfileId = educationalDetail.ProfileId;

					education.Address = educationalDetail.Address;
					education.DegreeObtainedOther = educationalDetail.DegreeObtainedOther;
					education.Description = educationalDetail.Description;
					education.EducationalDegreeId = educationalDetail.EducationalDegreeId;
					education.EducationalDegreeName = educationalDetail.EducationalDegree.Title;
					education.EducationalInstitutionId = educationalDetail.EducationalInstitutionId;
					education.InstitutionName = educationalDetail.InstitutionName;
					education.ModifiedBy = educationalDetail.ModifiedBy;
					education.ModifiedOn = educationalDetail.ModifiedOn;
					education.YearsAttendedStart = educationalDetail.YearsAttendedStart;
					education.YearsAttendedEnd = educationalDetail.YearsAttendedEnd;

					educationList.Add(education);
				}

				return Ok(educationList.OrderByDescending(e => e.YearsAttendedEnd));
			}
		}

		/// <summary>
		/// Updates Educational Details
		/// </summary>
		/// <param name="educationalInstitutions"></param>
		/// <returns></returns>
		[HttpPost]
		[Route("UpdateEducationDetails")]
		public IActionResult UpdateEducationDetails(vmEducation educationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var educationDB = db.EducationalInstitutions.Where(p => p.EducationalInstitutionId == educationVM.EducationalInstitutionId).SingleOrDefault();
				educationVM.BindModelTo(educationDB);
				educationDB.ModifiedBy = educationVM.LoggedInUser.EmployeeName;
				educationDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateEducationDetails")]
		public IActionResult CreateEducationDetails(vmEducation educationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				//var profile = db.Profiles.Where(p => p.ProfileId == educationVM.ProfileId).SingleOrDefault();
				EducationalInstitutions educationDB = new EducationalInstitutions();
				educationVM.BindModelTo(educationDB);
				educationDB.ModifiedBy = educationVM.LoggedInUser.EmployeeName;
				educationDB.ModifiedOn = DateTime.Now;
				educationDB.ProfileId = educationVM.DisplayUser.ProfileId;
				db.EducationalInstitutions.Add(educationDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		#endregion Education Component

		#region Competency Component

		/// <summary>
		/// Gets the Skills based on profile ID
		/// </summary>
		/// <param name="profileID"></param>
		/// <returns></returns>
		[HttpGet]
		[Route("GetSkillsByProfileIDOLD")]
		public IActionResult GetSkillsByProfileIDOLD(int profileID)
		{
			List<vmSkills> skillsList = new List<vmSkills>();
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var skillDetails = db.Skills.Where(p => p.ProfileId == profileID).ToList();

				//var ratings = db.SkillRatings.ToList();

				foreach (var skill in skillDetails)
				{
					vmSkills skillsVM = new vmSkills();

					skillsVM.ProfileId = skill.ProfileId;
					skillsVM.SkillId = skill.SkillId;
					skillsVM.EnterpriseCompetencies = skill.EnterpriseCompetencies;
					skillsVM.CreatedBy = skill.CreatedBy;
					skillsVM.CreatedOn = skill.CreatedOn;
					skillsVM.ModifiedBy = skill.ModifiedBy;
					//skillsVM.ApprovalStatusID = skill.ApprovalStatusID;
					//skillsVM.ApproverID= skill.ApproverID;
					//skillsVM.Year = skill.Year;
					//skillsVM.EmpRating = (int)skill.EmpRating;
					//skillsVM.MngrRating = (int)skill.MngrRating;
					//var EmpRatingfilter = ratings.Where(r => r.SkillRatingID == skill.EmpRating).SingleOrDefault();
					//var MngrRatingfilter = ratings.Where(r => r.SkillRatingID == skill.MngrRating).SingleOrDefault();

					//if (EmpRatingfilter != null)
					//{

					//	skillsVM.EmpRatingDesc = EmpRatingfilter.Title;
					//}
					//if (MngrRatingfilter != null)
					//{
					//	skillsVM.MngrRatingDesc = MngrRatingfilter.Title;

					//}

					//skillsVM.MngrRagting=skill.MngrRagting;
					if (skillsVM.ModifiedOn != null)
					{
						skillsVM.ModifiedOn = skill.ModifiedOn;
					}
					else
					{
						skillsVM.ModifiedOn = skill.CreatedOn;
					}

					skillsList.Add(skillsVM);
				}

				return Ok(skillsList.OrderByDescending(s => s.ModifiedOn));
			}
		}

		/// <summary>
		/// Updates the skill based on SkillID
		/// </summary>
		/// <param name="skillsModel"></param>
		/// <returns></returns>
		[HttpPost]
		[Route("UpdateSkillOld")]
		public IActionResult UpdateSkillOld(vmSkills skillsModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var profile = db.Profiles.Where(p => p.ProfileId == skillsModel.ProfileId).SingleOrDefault();

				var skillDB = db.Skills.Where(p => p.SkillId == skillsModel.SkillId).SingleOrDefault();

				skillsModel.ModifiedOn = DateTime.Now;
				skillsModel.BindModelTo(skillDB);
				skillDB.ModifiedBy = profile.EmployeeName;
				db.Skills.Update(skillDB);
				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		/// <summary>
		/// Created a new Skill
		/// </summary>
		/// <param name="skillsModel"></param>
		/// <returns></returns>
		[HttpPost]
		[Route("CreateSkillOld")]
		public IActionResult CreateSkillOld(vmSkills skillsModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var profile = db.Profiles.Where(p => p.ProfileId == skillsModel.ProfileId).SingleOrDefault();
				var managerProfile = db.Profiles.Where(p => p.ProfileId == profile.ManagerId).SingleOrDefault();
				Skills skillDB = new Skills();
				skillsModel.BindModelTo(skillDB);
				//skillDB.ModifiedOn = DateTime.Now;
				skillDB.ApproverID = managerProfile.NetworkId;
				skillDB.CreatedOn = DateTime.Now;
				skillDB.CreatedBy = profile.EmployeeName;
				skillDB.ModifiedBy = profile.EmployeeName;
				db.Skills.Add(skillDB);

				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		/// <summary>
		/// Delete Skill based on skillID
		/// </summary>
		/// <param name="skillModel"></param>
		/// <returns></returns>
		[HttpPost]
		[Route("DeleteSkillOld")]
		public IActionResult DeleteSkillBySkillID(vmSkills skillModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var skillsDB = db.Skills.Where(p => p.SkillId == skillModel.SkillId).SingleOrDefault();
				db.Skills.Remove(skillsDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		#endregion Competency Component

		#region Training and Development Component

		[HttpGet]
		[Route("GetTrainingCategories")]
		public IActionResult GetTrainingCategories()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var trainingCategories = db.TrainingCategories.ToList();

				return Ok(trainingCategories);
			}
		}

		[HttpPost]
		[Route("UpdateTrainingAndDev")]
		public IActionResult UpdateTrainingAndDev(vmTrainingDevelopment trainingDevelopmentVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var trainingAndDevDB = db.TrainingDevelopment.Where(p => p.TrainingDevelopmentId == trainingDevelopmentVM.TrainingDevelopmentId).SingleOrDefault();
				trainingDevelopmentVM.BindModelTo(trainingAndDevDB);
				trainingAndDevDB.ModifiedBy = trainingDevelopmentVM.LoggedInUser.EmployeeName;
				trainingAndDevDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateTrainingAndDevDetails")]
		public IActionResult CreateTrainingAndDevDetails(vmTrainingDevelopment trainingDevelopmentVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				TrainingDevelopment trainingAndDevDB = new TrainingDevelopment();
				trainingDevelopmentVM.BindModelTo(trainingAndDevDB);
				trainingAndDevDB.ModifiedBy = trainingDevelopmentVM.LoggedInUser.EmployeeName;
				trainingAndDevDB.ModifiedOn = DateTime.Now;
				trainingAndDevDB.ProfileId = trainingDevelopmentVM.DisplayUser.ProfileId;

				db.TrainingDevelopment.Add(trainingAndDevDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		/// <summary>
		/// Gets the profile Details
		/// </summary>
		/// <param name="profileID"></param>
		/// <returns></returns>
		[HttpGet]
		[Route("GetTrainingAndDevDetails")]
		public IActionResult GetTrainingAndDevDetails(int profileID)
		{
			// profileID = 8547;
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())

			{
				List<vmTrainingDevelopment> trainingDevelopmentsList = new List<vmTrainingDevelopment>();
				var trainingDevmntDB = db.TrainingDevelopment.Include(x => x.TrainingCategory).Where(p => p.ProfileId == profileID).ToList();

				foreach (var trainingDBModel in trainingDevmntDB)
				{
					vmTrainingDevelopment traningDevpmntModel = new vmTrainingDevelopment();
					trainingDBModel.BindModelTo(traningDevpmntModel);
					traningDevpmntModel.TrainingCategoryName = trainingDBModel.TrainingCategory.Title;
					trainingDevelopmentsList.Add(traningDevpmntModel);
				}

				return Ok(trainingDevelopmentsList.OrderByDescending(t => t.YearObtained));
			}
		}

		#endregion Training and Development Component

		#region Awards Patents Recognition Component

		[HttpGet]
		[Route("GetAwardsPatentsRecognitions")]
		public IActionResult GetAwardsPatentsRecognitions(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())

			{
				List<vmAwardsPatentsRecognitions> awardsPatentsRecognitionsListVM = new List<vmAwardsPatentsRecognitions>();
				var awardsPatentsRecognitionsListDB = db.AwardsPatentsRecognitions.Where(p => p.ProfileId == profileID).ToList();

				foreach (var awardsPatentsDB in awardsPatentsRecognitionsListDB)
				{
					vmAwardsPatentsRecognitions awardsPatentsRecognitionsVM = new vmAwardsPatentsRecognitions();
					awardsPatentsDB.BindModelTo(awardsPatentsRecognitionsVM);
					awardsPatentsRecognitionsListVM.Add(awardsPatentsRecognitionsVM);
				}

				return Ok(awardsPatentsRecognitionsListVM.OrderByDescending(a => a.DateReceived));
			}
		}

		[HttpPost]
		[Route("CreateAwardsPatents")]
		public IActionResult CreateAwardsPatents(vmAwardsPatentsRecognitions awardsPatentsRecognitionsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				AwardsPatentsRecognitions awardsPatentsRecognitionsDB = new AwardsPatentsRecognitions();

				awardsPatentsRecognitionsVM.BindModelTo(awardsPatentsRecognitionsDB);
				awardsPatentsRecognitionsDB.ModifiedOn = DateTime.Now;
				awardsPatentsRecognitionsDB.CreatedOn = DateTime.Now;
				awardsPatentsRecognitionsDB.CreatedBy = awardsPatentsRecognitionsVM.LoggedInUser.NetworkId;
				awardsPatentsRecognitionsDB.ModifiedBy = awardsPatentsRecognitionsVM.LoggedInUser.NetworkId;
				awardsPatentsRecognitionsDB.ProfileId = awardsPatentsRecognitionsVM.DisplayUser.ProfileId;

				db.AwardsPatentsRecognitions.Add(awardsPatentsRecognitionsDB);

				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateAwardsPatents")]
		public IActionResult UpdateAwardsPatents(vmAwardsPatentsRecognitions awardsPatentsRecognitionsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var profile = db.Profiles.Where(p => p.ProfileId == awardsPatentsRecognitionsVM.ProfileId).SingleOrDefault();

				var awardsPatentsRecognitionsDB = db.AwardsPatentsRecognitions.Where(p => p.AwardPatentRecognitionId == awardsPatentsRecognitionsVM.AwardPatentRecognitionId).SingleOrDefault();

				awardsPatentsRecognitionsVM.BindModelTo(awardsPatentsRecognitionsDB);
				awardsPatentsRecognitionsDB.ModifiedOn = DateTime.Now;

				awardsPatentsRecognitionsDB.ModifiedBy = awardsPatentsRecognitionsVM.LoggedInUser.NetworkId;

				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		#endregion Awards Patents Recognition Component

		#region Language Component

		[HttpGet]
		[Route("GetLanuagesList")]
		public IActionResult GetLanuagesList(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var languagesListDB = db.Languages.ToList();

				return Ok(languagesListDB);
			}
		}

		[HttpGet]
		[Route("GetLanuageFluencyList")]
		public IActionResult GetLanuageFluencyList(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var languageFluencyList = db.LanguageFluency.ToList();

				return Ok(languageFluencyList);
			}
		}

		[HttpGet]
		[Route("GetLanguagesByID")]
		public IActionResult GetLanguagesByID(int profileID)
		{
			List<vmUnderstoodLanguages> languageVMList = new List<vmUnderstoodLanguages>();
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var languagesListDB = db.UnderstoodLanguages.Include(x => x.LanguageFluency).Where(p => p.ProfileId == profileID).ToList();

				foreach (var languageDB in languagesListDB)
				{
					vmUnderstoodLanguages languageVM = new vmUnderstoodLanguages();
					languageDB.BindModelTo(languageVM);
					languageVM.LanguageFluencyName = languageDB.LanguageFluency.Title;

					languageVMList.Add(languageVM);
				}

				return Ok(languageVMList.OrderByDescending(l => l.ModifiedOn));
			}
		}

		[HttpPost]
		[Route("AddNewLanguage")]
		public IActionResult AddNewLanguage(vmUnderstoodLanguages languageVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				UnderstoodLanguages languagesDB = new UnderstoodLanguages();

				languageVM.BindModelTo(languagesDB);
				languagesDB.ModifiedOn = DateTime.Now;

				languagesDB.ModifiedBy = languageVM.LoggedInUser.EmployeeName;
				languagesDB.ProfileId = languageVM.DisplayUser.ProfileId;

				db.UnderstoodLanguages.Add(languagesDB);

				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateLanguageDetails")]
		public IActionResult UpdateLanguageDetails(vmUnderstoodLanguages languagesVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var profile = db.Profiles.Where(p => p.ProfileId == languagesVM.ProfileId).SingleOrDefault();

				var languagesDB = db.UnderstoodLanguages.Where(p => p.UnderstoodLanguageId == languagesVM.UnderstoodLanguageId).SingleOrDefault();

				languagesVM.BindModelTo(languagesDB);
				languagesDB.ModifiedOn = DateTime.Now;

				languagesDB.ModifiedBy = languagesVM.LoggedInUser.EmployeeName;
				languagesDB.ProfileId = languagesVM.DisplayUser.ProfileId;

				db.SaveChanges();
				return Ok(new { status = "Success" });
			}
		}

		#endregion Language Component

		/// <summary>
		/// Gets the profile Details
		/// </summary>
		/// <param name="profileID"></param>
		/// <returns></returns>
		[HttpGet]
		[Route("GetProfileDetails")]
		public IActionResult GetProfileDetails(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				vmProfile profileModel = new vmProfile();
				var profileDB = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
				profileDB.BindModelTo(profileModel);
				if (profileModel.NetworkId.ToLower() == "ngrasberger")
				{
					profileModel.ManagerName = "";
				}
				else
					profileModel.ManagerName = db.Profiles.Where(p => p.ProfileId == profileModel.ManagerId).SingleOrDefault().EmployeeName;
				profileModel.DivisionName = db.VwBusinessUnits.Where(p => p.BusinessUnitId == profileDB.DivisionId).FirstOrDefault().DisplayName;

				var user = db.HrusersNew.Where(h => h.UserName == profileModel.NetworkId).FirstOrDefault();

				if (user != null)
				{
					if (user.SuperUser == true)
					{
						profileModel.IsAdmin = true;
					}
					else
					{
						profileModel.IsHR = true;
					}
					if (user.SecurityUser == true)
					{
						profileModel.IsSecurityUser = true;
					}
					else
					{
						profileModel.IsSecurityUser = false;
					}
				}
				if (db.Profiles.Where(p => p.ManagerId == profileModel.ProfileId).Count() > 0)
				{
					profileModel.IsManager = true;
				}
                profileModel.JobFamilyName = db.JobFamily.Where(p => p.Id == profileDB.JobFamilyId).FirstOrDefault().Description;
                return Ok(profileModel);
			}
		}

		[HttpGet]
		[Route("GetLoggedInADuser")]
		public IActionResult GetLoggedInADuser(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				vmProfile profileModel = new vmProfile();
				var profileDB = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();

				profileDB.BindModelTo(profileModel);
				var managerDB = db.Profiles.Where(p => p.ProfileId == profileModel.ManagerId).SingleOrDefault();

				profileModel.ManagerName = managerDB == null ? string.Empty : managerDB.EmployeeName;
				profileModel.DivisionName = db.VwBusinessUnits.Where(p => p.BusinessUnitId == profileDB.DivisionId).FirstOrDefault().DisplayName;
				return Ok(profileModel);
			}
		}

		[HttpGet]
		[Route("GetLoggedInADuserByEmailID")]
		public IActionResult GetLoggedInADuserByEmailID(string EmailID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				vmProfile profileModel = new vmProfile();
				var profileDB = db.Profiles.Where(p => p.Email == EmailID && p.TerminationDate == null).OrderByDescending(p => p.ProfileId).FirstOrDefault();

				if (profileDB != null)
				{
					profileDB.BindModelTo(profileModel);
					var hritProfile = db.TblHritmasterData.Where(t => t.EmployeeNumber == profileDB.EmployeeNumber).FirstOrDefault();

					if (hritProfile != null)
						profileModel.IsDirect = ((hritProfile.DirectIndirect ?? "").ToLower() == "direct") ? true : false;
					else
						profileModel.IsDirect = true;

					var user = db.HrusersNew.Where(h => h.UserName == profileModel.NetworkId).FirstOrDefault();

					if (user != null)
					{
						if (user.SuperUser == true)
						{
							profileModel.IsAdmin = true;
						}
						else
						{
							profileModel.IsHR = true;
						}
						if (user.SecurityUser == true)
						{
							profileModel.IsSecurityUser = true;
						}
						else
						{
							profileModel.IsSecurityUser = false;
						}
					}
					if (db.Profiles.Where(p => p.ManagerId == profileModel.ProfileId).Count() > 0)
					{
						profileModel.IsManager = true;
					}

					var managerDB = db.Profiles.Where(p => p.ProfileId == profileModel.ManagerId).SingleOrDefault();
					profileModel.ManagerName = managerDB == null ? string.Empty : managerDB.EmployeeName;
					profileModel.DivisionName = db.VwBusinessUnits.Where(p => p.BusinessUnitId == profileDB.DivisionId).FirstOrDefault().DisplayName;
					profileModel.JobFamilyName = db.JobFamily.Where(p => p.Id == profileDB.JobFamilyId).FirstOrDefault().Description;
				}

				return Ok(profileModel);
			}
		}

		[HttpGet]
		[Route("Login")]
		public IActionResult Login(string NetworkID, string EmployeeNumber)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				vmProfile profileModel = new vmProfile();

                #region checking user termination in profile and hrittable

                var data = db.postResults.FromSqlRaw("USP_CheckTerminationStatus {0}, {1}", NetworkID,EmployeeNumber).ToList();
               
				if (data[0].Status == "true")
					return Ok(profileModel);
                #endregion
                var profileDB = db.Profiles.Where(p => p.NetworkId == NetworkID && p.EmployeeNumber == EmployeeNumber && p.TerminationDate == null).OrderByDescending(p => p.ProfileId).FirstOrDefault();
				if (profileDB != null )
				{
						if (profileDB.TerminationDate < DateTime.UtcNow)
							return Ok(profileModel);
					profileDB.BindModelTo(profileModel);
					var hritProfile = db.TblHritmasterData.Where(t => t.EmployeeNumber == EmployeeNumber).FirstOrDefault();

					if (hritProfile.Terminationdate < DateTime.UtcNow)
					{
						return Ok(profileModel);
					}
						else { 

					if (hritProfile != null)
						profileModel.IsDirect = ((hritProfile.DirectIndirect ?? "").ToLower() == "direct") ? true : false;
					else
						profileModel.IsDirect = true;

					var user = db.HrusersNew.Where(h => h.UserName == profileModel.NetworkId).FirstOrDefault();

					if (user != null)
					{
						if (user.SuperUser == true)
						{
							profileModel.IsAdmin = true;
						}
						else
						{
							profileModel.IsHR = true;
						}
						if (user.SecurityUser == true)
						{
							profileModel.IsSecurityUser = true;
						}
						else
						{
							profileModel.IsSecurityUser = false;
						}
					}
					if (db.Profiles.Where(p => p.ManagerId == profileModel.ProfileId).Count() > 0)
					{
						profileModel.IsManager = true;
					}

					var managerDB = db.Profiles.Where(p => p.ProfileId == profileModel.ManagerId).SingleOrDefault();
					profileModel.ManagerName = managerDB == null ? string.Empty : managerDB.EmployeeName;
					profileModel.DivisionName = db.VwBusinessUnits.Where(p => p.BusinessUnitId == profileDB.DivisionId).FirstOrDefault().DisplayName;
					profileModel.JobFamilyName = db.JobFamily.Where(p => p.Id == profileDB.JobFamilyId).FirstOrDefault().Description;
							} 
				}

				return Ok(profileModel);
			}
		}

		[HttpGet]
		[Route("CheckIfManagersManager")]
		public IActionResult CheckIfManagersManager(int empProfileId, int managersManagerProfileId)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var recordDb = (from emp in db.Profiles
								join mgr in db.Profiles
								on emp.ManagerId equals mgr.ProfileId
								where emp.ProfileId == empProfileId
								select new
								{
									managersManagerId = mgr.ManagerId
								}).ToList();

				int? managersManagerDB = 0;

				foreach (var item in recordDb)
				{
					if (item.managersManagerId != null)
						managersManagerDB = item.managersManagerId;
				}

				if (managersManagerDB == managersManagerProfileId)
				{
					return Ok(true);
				}
				return Ok(false);
			}
		}

		[HttpGet]
		[Route("GetCareerAspirationsByID")]
		public IActionResult GetCareerAspirationsByID(int profileID)
		{
			try
			{
				List<vmCareerAspiration> careerAspirationsVMLst = new List<vmCareerAspiration>();
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())

				{
					var careerAspirationsLstDB = db.CareerAspiration.Where(p => p.ProfileId == profileID).ToList();
					careerAspirationsLstDB.ForEach((item) =>
					{
						vmCareerAspiration careerAspirationVM = new vmCareerAspiration();
						item.BindModelTo(careerAspirationVM);
						careerAspirationsVMLst.Add(careerAspirationVM);
						if (item.ModifiedOn >= item.CreatedOn)
						{
							careerAspirationVM.ModifiedOn = item.ModifiedOn;
						}
						else
						{
							careerAspirationVM.ModifiedOn = item.CreatedOn;
						}
					});
				}

				return Ok(careerAspirationsVMLst.OrderByDescending(a => a.ModifiedOn));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpGet]
		[Route("GetCareerInterestsByID")]
		public IActionResult GetCareerInterestsByID(int profileID)
		{
			try
			{
				List<vmCareerInterests> careerInterestsVMLst = new List<vmCareerInterests>();
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())

				{
					var careerInterestsDBLst = db.CareerInterests.Where(p => p.ProfileId == profileID).ToList();
					careerInterestsDBLst.ForEach((item) =>
					{
						vmCareerInterests careerInterestsVM = new vmCareerInterests();
						item.BindModelTo(careerInterestsVM);
						careerInterestsVMLst.Add(careerInterestsVM);
					});
				}

				return Ok(careerInterestsVMLst.OrderByDescending(i => i.ModifiedOn));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpGet]
		[Route("GetLicsCertsProfOrgsByID")]
		public IActionResult GetLicsCertsProfOrgsByID(int profileID)
		{
			try
			{
				List<vmLicsCertsProfOrgs> licsCertsProfOrgsVMLst = new List<vmLicsCertsProfOrgs>();
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var careerInterestsDBLst = db.LicsCertsProfOrgs.Where(p => p.ProfileId == profileID).ToList();
					careerInterestsDBLst.ForEach((item) =>
					{
						vmLicsCertsProfOrgs licsCertsProfOrgsVM = new vmLicsCertsProfOrgs();
						item.BindModelTo(licsCertsProfOrgsVM);
						licsCertsProfOrgsVM.LicenseCategoryName = db.LicenseCategories.Where(l => l.LicenseCategoryId == item.LicenseCategoryId).FirstOrDefault().Title;
						licsCertsProfOrgsVMLst.Add(licsCertsProfOrgsVM);
					});
				}

				return Ok(licsCertsProfOrgsVMLst.OrderByDescending(l => l.DateReceived));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpGet]
		[Route("GetDirectReportsTree")]
		public IActionResult GetDirectReportsTree()
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var createdPath = db._DirectReportsSP.FromSqlRaw("ProfilesGetDirectReports  {0}", "rasurati1").ToList();
				}

				return Ok("");
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		[HttpPost]
		[Route("UpdateCareerAspiration")]
		public IActionResult UpdateCareerAspiration(vmCareerAspiration careerAspirationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var careerAspirationDB = db.CareerAspiration.Where(p => p.Id == careerAspirationVM.Id).FirstOrDefault();

				careerAspirationVM.BindModelTo(careerAspirationDB);

				careerAspirationDB.ModifiedOn = DateTime.Now;
				careerAspirationDB.ModifiedBy = careerAspirationVM.LoggedInUser.NetworkId;
				careerAspirationDB.ProfileId = careerAspirationVM.DisplayUser.ProfileId;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateCareerInterest")]
		public IActionResult UpdateCareerInterest(vmCareerInterests careerInterestsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var careerInterestsDB = db.CareerInterests.Where(p => p.CareerInterestId == careerInterestsVM.CareerInterestId).FirstOrDefault();

				careerInterestsVM.BindModelTo(careerInterestsDB);

				careerInterestsDB.ModifiedOn = DateTime.Now;
				careerInterestsDB.ModifiedBy = careerInterestsVM.LoggedInUser.NetworkId;
				careerInterestsDB.ProfileId = careerInterestsVM.DisplayUser.ProfileId;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateLicsCertsProfOrgs")]
		public IActionResult UpdateLicsCertsProfOrgs(vmLicsCertsProfOrgs licsCertsProfOrgsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var licsCertsProfOrgsDB = db.LicsCertsProfOrgs.Where(p => p.LicCertProfOrgId == licsCertsProfOrgsVM.LicCertProfOrgId).FirstOrDefault();

				licsCertsProfOrgsVM.BindModelTo(licsCertsProfOrgsDB);

				licsCertsProfOrgsDB.ModifiedOn = DateTime.Now;
				licsCertsProfOrgsDB.ModifiedBy = licsCertsProfOrgsVM.LoggedInUser.NetworkId;
				licsCertsProfOrgsDB.ProfileId = licsCertsProfOrgsVM.DisplayUser.ProfileId;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateCareerAspiration")]
		public IActionResult CreateCareerAspiration(vmCareerAspiration careerAspirationVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				CareerAspiration careerAspirationDB = new CareerAspiration();

				careerAspirationVM.BindModelTo(careerAspirationDB);

				careerAspirationDB.ModifiedOn = DateTime.Now;
				careerAspirationDB.CreatedOn = DateTime.Now;
				careerAspirationDB.ModifiedBy = careerAspirationVM.LoggedInUser.NetworkId;
				careerAspirationDB.CreatedBy = careerAspirationVM.LoggedInUser.NetworkId;
				careerAspirationDB.ProfileId = careerAspirationVM.DisplayUser.ProfileId;
				db.CareerAspiration.Add(careerAspirationDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateCareerInterest")]
		public IActionResult CreateCareerInterest(vmCareerInterests careerInterestsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				CareerInterests careerInterestsDB = new CareerInterests();

				careerInterestsVM.BindModelTo(careerInterestsDB);

				careerInterestsDB.ModifiedOn = DateTime.Now;
				careerInterestsDB.ModifiedBy = careerInterestsVM.LoggedInUser.NetworkId;
				careerInterestsDB.ProfileId = careerInterestsVM.DisplayUser.ProfileId;
				db.CareerInterests.Add(careerInterestsDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateLicsCertsProfOrgs")]
		public IActionResult CreateLicsCertsProfOrgs(vmLicsCertsProfOrgs licsCertsProfOrgsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				LicsCertsProfOrgs licsCertsProfOrgsDB = new LicsCertsProfOrgs();

				licsCertsProfOrgsVM.BindModelTo(licsCertsProfOrgsDB);

				licsCertsProfOrgsDB.ModifiedOn = DateTime.Now;
				licsCertsProfOrgsDB.ModifiedBy = licsCertsProfOrgsVM.LoggedInUser.NetworkId;
				licsCertsProfOrgsDB.CreatedBy = licsCertsProfOrgsVM.LoggedInUser.NetworkId;
				licsCertsProfOrgsDB.CreatedOn = DateTime.Now;
				licsCertsProfOrgsDB.ProfileId = licsCertsProfOrgsVM.DisplayUser.ProfileId;
				db.Add(licsCertsProfOrgsDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpGet]
		[Route("GetEmployeeReportees")]
		public IActionResult GetEmployeeReportees(int ProfileID)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var result = db.EmployeeReporteesSP.FromSqlRaw("GetEmployeeReportees {0}", ProfileID).ToList();

					int maxEmpLevel = 0;
					EmployeeReporteesSP maxEmpLevelReportee = result.OrderByDescending(r => r.EmpLevel).FirstOrDefault();
					if (maxEmpLevelReportee != null)
					{
						maxEmpLevel = maxEmpLevelReportee.EmpLevel;
					}
					int k = maxEmpLevel;
					List<vmEmployeereportees> list = new List<vmEmployeereportees>();
					List<vmEmployeereportees> Sublist = new List<vmEmployeereportees>();

					for (int i = maxEmpLevel; maxEmpLevel >= 1; maxEmpLevel--)
					{
						if (list.Count > 0)
						{
							Sublist = new List<vmEmployeereportees>();
							Sublist = list;
							list = new List<vmEmployeereportees>();
						}
						foreach (EmployeeReporteesSP model in result.Where(e => e.EmpLevel == maxEmpLevel))
						{
							if (Sublist.Count > 0 && Sublist.Any(p => p.ManagerID == model.ProfileID))
							{
								List<vmEmployeereportees> _subReporteesList = Sublist.Where(p => p.ManagerID == model.ProfileID).ToList();
								vmEmployeereportees _reportees = new vmEmployeereportees();
								_reportees.ProfileID = model.ProfileID;
								_reportees.EmployeeName = model.EmployeeName;
								_reportees.NetworkID = model.NetworkID;
								_reportees.ManagerID = model.ManagerID;
								_reportees.EmpLevel = model.EmpLevel;
								foreach (vmEmployeereportees r in _subReporteesList)
								{
									_reportees.SubReportees.Add(r);
								}
								//list[index].SubReportees.Add(_reportees);
								list.Add(_reportees);
								//Sublist.RemoveAt(index);
								Sublist.RemoveAll(p => p.ManagerID == model.ProfileID);
							}
							else if ((Sublist.Count > 0 || list.Count > 0) && k != maxEmpLevel)
							{
								vmEmployeereportees _reportees = new vmEmployeereportees();
								_reportees.ProfileID = model.ProfileID;
								_reportees.EmployeeName = model.EmployeeName;
								_reportees.NetworkID = model.NetworkID;
								_reportees.ManagerID = model.ManagerID;
								_reportees.EmpLevel = model.EmpLevel;
								_reportees.SubReportees = null;
								list.Add(_reportees);
							}
							else
							{
								vmEmployeereportees _reportees = new vmEmployeereportees();
								_reportees.ProfileID = model.ProfileID;
								_reportees.EmployeeName = model.EmployeeName;
								_reportees.NetworkID = model.NetworkID;
								_reportees.ManagerID = model.ManagerID;
								_reportees.EmpLevel = model.EmpLevel;
								_reportees.SubReportees = null;
								Sublist.Add(_reportees);
							}
						}
					}

					if (k == 1 && list.Count == 0)
					{
						list = Sublist;
					}

					return Ok(list);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		//not using 
		//[HttpGet("SkillRatings")]
		//public IActionResult GetSkillsRating()
		//{
		//	//List<vmSkills> skillsList = new List<vmSkills>();
		//	using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
		//	{
		//		var skillDetails = db.Skills.ToList();

		//		return Ok(skillDetails);
		//	}
		//}
		//not using
		[HttpGet("CompetencyDDL")]
		public IActionResult GetCompetencyDDL()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var connectionString = db.Database.GetDbConnection().ConnectionString;
				var result = new List<CompetencyDDL>();
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					DataSet ds = SqlHelper.ExecuteDataset(conn, "GetCompetencyDDL");
					result = DataTableHelper.ConvertDataTable<CompetencyDDL>(ds.Tables[0]);
					conn.Close();
					return Ok(result);
				}
			}
		}
		[HttpGet("EmployeeCommentsDDL")]
		public IActionResult GetEmployeeCommentsDDL()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{

				var connectionString = db.Database.GetDbConnection().ConnectionString;
				var result = new List<EmployeeCommentsDDL>();
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					DataSet ds = SqlHelper.ExecuteDataset(conn, "GetEmployeeCommentsDDL");
					result = DataTableHelper.ConvertDataTable<EmployeeCommentsDDL>(ds.Tables[0]);
					conn.Close();
					return Ok(result);
				}
			}
		}

		//[HttpPost]
		//[Route("SubmitSkillsApproval")]
		//public IActionResult SkillsApproval(vmSkills skillsModel)
		//{
		//    using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
		//    {


		//            var successmessage = db.Set<_closeallappraisal>().FromSqlRaw("UpdateSkillsApprovalStatus  {0},{1}", skillsModel.ApprovalStatusID,skillsModel.SkillId);

		//        return Ok(new { status = "Success" });
		//    }
		//}

		[HttpGet]
		[Route("skillsMangerApproval")]
		public IActionResult SkillsManagerApproval(string NetworkId)
		{

			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var Approvaldata = db.vmSkills.FromSqlRaw("CompetencyManagerApproval {0}", NetworkId).ToList();

				return Ok(Approvaldata);

			}

		}
		[HttpGet]
		[Route("GetSkillsByProfileID")]
		public IActionResult GetSkillsByProfileID(int profileID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var data = db.vmSkills.FromSqlRaw("GetSkillsByProfileID {0}", profileID).ToList();
				return Ok(data);
			}
		}
		[HttpPost]
		[Route("CreateSkill")]
		public IActionResult CreateSkill(Skills skillsModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{

				var profile = db.Profiles.Where(p => p.ProfileId == skillsModel.ProfileId).SingleOrDefault();
				var managerProfile = db.Profiles.Where(p => p.ProfileId == profile.ManagerId).SingleOrDefault();

				var connectionString = db.Database.GetDbConnection().ConnectionString;
				DataSet ds = new DataSet();
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					SqlCommand cmd = new SqlCommand("[dbo].[proc_Skills_Insert]", conn);
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@ProfileId", skillsModel.ProfileId);
					cmd.Parameters.AddWithValue("@EnterpriseCompetencies", skillsModel.EnterpriseCompetencies);
					cmd.Parameters.AddWithValue("@CreatedBy", profile.EmployeeName);
					cmd.Parameters.AddWithValue("@ModifiedBy", profile.EmployeeName);
					cmd.Parameters.AddWithValue("@ApproverID", managerProfile.NetworkId);
					cmd.Parameters.AddWithValue("@EmpRating", skillsModel.EmpRating);
					cmd.Parameters.AddWithValue("@Year", skillsModel.Year);
					cmd.Parameters.AddWithValue("@MngrRating", skillsModel.MngrRating);
					cmd.Parameters.AddWithValue("@ApprovalStatusID", skillsModel.ApprovalStatusID);
					SqlDataAdapter adapter = new SqlDataAdapter(cmd);
					adapter.Fill(ds);
					conn.Close();
				}
				return Ok(new { status = "Success" });
			}
		}
		[HttpPost]
		[Route("UpdateSkill")]
		public IActionResult UpdateSkill(Skills skillsModel)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{

				var profile = db.Profiles.Where(p => p.ProfileId == skillsModel.ProfileId).SingleOrDefault();
				var managerProfile = db.Profiles.Where(p => p.ProfileId == profile.ManagerId).SingleOrDefault();

				var connectionString = db.Database.GetDbConnection().ConnectionString;
				DataSet ds = new DataSet();
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					SqlCommand cmd = new SqlCommand("[dbo].[proc_Skills_Update]", conn);
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@SkillId", skillsModel.SkillId);
					cmd.Parameters.AddWithValue("@ProfileId", skillsModel.ProfileId);
					cmd.Parameters.AddWithValue("@EnterpriseCompetencies", skillsModel.EnterpriseCompetencies);
					cmd.Parameters.AddWithValue("@ModifiedBy", profile.EmployeeName);
					cmd.Parameters.AddWithValue("@ApproverID", managerProfile.NetworkId);
					cmd.Parameters.AddWithValue("@EmpRating", skillsModel.EmpRating);
					cmd.Parameters.AddWithValue("@Year", skillsModel.Year);
					cmd.Parameters.AddWithValue("@MngrRating", skillsModel.MngrRating);
					cmd.Parameters.AddWithValue("@ApprovalStatusID", skillsModel.ApprovalStatusID);
					SqlDataAdapter adapter = new SqlDataAdapter(cmd);
					adapter.Fill(ds);
					conn.Close();
				}
				return Ok(new { status = "Success" });
			}
		}
		[HttpGet]
		[Route("DeleteSkill")]
		public IActionResult DeleteSkill(int SkillID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				//if result =1 true else false;
				var result = db.Database.ExecuteSqlRaw("proc_Skills_Delete {0}", SkillID);

				return Ok(new { status = "Success" });
			}
		}

	}
}