﻿CREATE TABLE [Archive].[EducationalInstitutions] (
    [ArchiveEducationalInstitutionID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalEducationalInstitutionID] INT            NOT NULL,
    [ArchiveProfileID]                 INT            NOT NULL,
    [InstitutionName]                  NVARCHAR (75)  NOT NULL,
    [Address]                          NVARCHAR (255) NOT NULL,
    [EducationalDegree]                NVARCHAR (75)  NOT NULL,
    [DegreeObtainedOther]              NVARCHAR (75)  NULL,
    [YearsAttendedStart]               INT            NOT NULL,
    [YearsAttendedEnd]                 INT            NULL,
    [Description]                      NTEXT          NOT NULL,
    [ModifiedBy]                       NVARCHAR (50)  NOT NULL,
    [ModifiedOn]                       DATETIME       CONSTRAINT [DF_EducationalInstitutions_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_EducationalInstitutions] PRIMARY KEY CLUSTERED ([ArchiveEducationalInstitutionID] ASC),
    CONSTRAINT [FK_EducationalInstitutions_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);




GO
CREATE TRIGGER [Archive].[tr_EducationalInstitutions_PreventChanges]     ON  Archive.EducationalInstitutions     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END