﻿CREATE TABLE [Archive].[DevelopmentPlans] (
    [ArchiveDevelopmentPlanID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanID] INT           NOT NULL,
    [ArchiveAppraisalID]        INT           NOT NULL,
    [ModifiedBy]                NVARCHAR (50) NOT NULL,
    [ModifiedOn]                DATETIME      CONSTRAINT [DF_DevelopmentPlans_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlans] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanID] ASC),
    CONSTRAINT [FK_DevelopmentPlans_Appraisals] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);


GO
CREATE TRIGGER [Archive].tr_DevelopmentPlans_PreventChanges     ON  Archive.DevelopmentPlans     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END