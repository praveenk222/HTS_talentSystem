﻿CREATE TABLE [Archive].[CommunicationsLog] (
    [CommunicationsLogID] INT            NOT NULL,
    [AppraisalID]         INT            NOT NULL,
    [Recipients]          NVARCHAR (500) NOT NULL,
    [Subject]             NVARCHAR (200) NOT NULL,
    [Body]                NTEXT          NOT NULL,
    [DateSent]            DATETIME       NOT NULL,
    [ModifiedBy]          VARCHAR (50)   NOT NULL,
    [ModifiedOn]          DATETIME       NOT NULL
);

