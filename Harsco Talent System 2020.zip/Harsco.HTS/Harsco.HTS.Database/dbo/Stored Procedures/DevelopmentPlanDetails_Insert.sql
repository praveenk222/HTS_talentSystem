﻿  
  
  
-- =============================================  
-- AUTHOR: Ed Blair  
-- CREATED DATE: 2028/06/24  
-- =============================================  
CREATE PROCEDURE [dbo].[DevelopmentPlanDetails_Insert]  
  
@DevelopmentPlanID int,  
@Category int,  
@Objective ntext,  
@Activity ntext,  
@SupportRequired ntext,  
@DateDue smalldatetime,  
@MeasurementProcess nvarchar(255),  
@CompletionId int,  
@PointOfEntryId int,   
@ActivityLoopId int,   
@DevelopmentLoopId int,  
@CompletionDate smalldatetime,
@Result nvarchar(255),
@CreatedBy varchar(50),  
@CreatedOn datetime,  
@ModifiedBy nvarchar(50),  
@ModifiedOn datetime  
  
AS  
  
BEGIN  
    INSERT INTO DevelopmentPlanDetails  
    (DevelopmentPlanID, Category, Objective, Activity, SupportRequired, DateDue, MeasurementProcess, CompletionId, PointOfEntryId, ActivityLoopId, DevelopmentLoopId,   
  CompletionDate,Result,CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)  
    VALUES (@DevelopmentPlanID, @Category, @Objective, @Activity, @SupportRequired, @DateDue, @MeasurementProcess, @CompletionID, @PointOfEntryId, @ActivityLoopId, @DevelopmentLoopId,  
   @CompletionDate,@Result,@CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)  
  
    SELECT DevelopmentPlanDetailID from DevelopmentPlanDetails WHERE DevelopmentPlanDetailID = SCOPE_IDENTITY();  
END