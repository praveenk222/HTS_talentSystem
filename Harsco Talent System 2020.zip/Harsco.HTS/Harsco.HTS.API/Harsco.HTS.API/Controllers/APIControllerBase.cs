﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Harsco.HTS.API.Controllers
{
    public abstract class APIControllerBase : ControllerBase
    {
        public int UserId { get; set; } = 0;

        public string LoginId
        {
            get
            {
                return User?.FindFirst(ClaimTypes.Name)?.Value;
            }
        }

        public string LoginIdShort
        {
            get
            {
                return this.LoginId?.Replace("@harsco.com", string.Empty);
            }
        }

        public short UserRoleAccessLevel { get; set; } = 0;

        public string UserRoleAccessLevelEntity { get; set; } = "0";

        public string DeptEntity { get; set; } = "";

        public APIControllerBase() { }

        public IActionResult Unauthorized(string message)
        {
            this.ModelState.AddModelError("", message);

            return base.Unauthorized(this.ModelState);
        }

        public IActionResult BadRequest(string message)
        {
            this.ModelState.AddModelError("", message);

            return base.BadRequest(this.ModelState);
        }

        public IActionResult BadRequest(Exception ex)
        {
            this.ModelState.AddModelError("", ex, null);

            return base.BadRequest(this.ModelState);
        }

        public new IActionResult BadRequest()
        {
            return base.BadRequest(this.ModelState);
        }
    }
}
