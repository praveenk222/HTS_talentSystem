﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2017/10/20
-- =============================================
CREATE PROCEDURE [dbo].[ActivityLoopListActive]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ID, Description, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM dbo.ActivityLoop
	WHERE IsDeleted = 0

	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;