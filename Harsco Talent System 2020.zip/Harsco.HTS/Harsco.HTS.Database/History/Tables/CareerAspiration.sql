﻿CREATE TABLE [History].[CareerAspiration] (
    [CreatedOn]          DATETIME     NOT NULL,
    [CareerAspirationId] INT          NOT NULL,
    [ProfileId]          INT          NOT NULL,
    [Aspiration]         NTEXT        NOT NULL,
    [CreatedBy]          VARCHAR (50) NOT NULL,
    [Created]            DATETIME     NOT NULL,
    [ModifiedBy]         VARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME     NOT NULL,
    CONSTRAINT [PK_CareerAspiration_1] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CareerAspirationId] ASC)
);

