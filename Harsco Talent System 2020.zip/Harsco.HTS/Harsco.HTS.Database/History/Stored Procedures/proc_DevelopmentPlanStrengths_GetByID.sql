﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlanStrengths_GetByID]
    @DevelopmentPlanStrengthID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanStrengthID, 
        DevelopmentPlanID, 
        DevelopmentPlanTimeStamp, 
        Strength, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM DevelopmentPlanStrengths
    WHERE DevelopmentPlanStrengthID = @DevelopmentPlanStrengthID
    ORDER BY CreatedOn Desc
END