﻿CREATE TABLE [Archive].[DevelopmentPlanWeaknesses] (
    [ArchiveDevelopmentPlanWeaknessID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanWeaknessID] INT           NOT NULL,
    [ArchiveDevelopmentPlanID]          INT           NOT NULL,
    [Weakness]                          NTEXT         NOT NULL,
    [ModifiedBy]                        NVARCHAR (50) NOT NULL,
    [ModifiedOn]                        DATETIME      CONSTRAINT [DF_DevelopmentPlanWeaknesses_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanWeaknesses] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanWeaknessID] ASC),
    CONSTRAINT [FK_DevelopmentPlanWeaknesses_DevelopmentPlans] FOREIGN KEY ([ArchiveDevelopmentPlanID]) REFERENCES [Archive].[DevelopmentPlans] ([ArchiveDevelopmentPlanID])
);


GO
CREATE TRIGGER [Archive].[tr_DevelopmentPlanWeaknesses_PreventChanges]     ON  Archive.DevelopmentPlanWeaknesses     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END