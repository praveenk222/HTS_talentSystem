﻿
-- ==================================================================
-- Author:		Ed Blair
-- Create date: 04/22/2013
-- Description: Get list of users that have actions to send email
--		Just Canada so send email in 2 languages
-- 
-- Modifications:
--  [dbo].[GETHTSActionsCanada] 'a','z'
-- ==================================================================
CREATE PROCEDURE [dbo].[GETHTSActionsCanada] 

@StartLetter char(1),
@EndLetter char(1)

AS
   
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN   
	DECLARE @ListofApprovers TABLE (ApproverId nvarchar(100), LanguageCode nvarchar(5), CountryId int)

	--Objective Approvals
    INSERT INTO @ListofApprovers
    SELECT ApproverId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
    FROM ObjectiveApprovals
		INNER JOIN Objectives ON Objectives.ObjectiveID = ObjectiveApprovals.ObjectiveID
		INNER JOIN Profiles ON Profiles.AppraisalId = Objectives.AppraisalId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId
    WHERE ApprovalStatusID = (SELECT ApprovalStatusID FROM ApprovalStatuses WHERE Title = 'Pending') 
		AND ObjectiveApprovals.ObjectiveID IS NOT NULL
		AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
		AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND Profiles.TerminationDate IS NULL		  
		AND Profiles.DivisionID != 14
		
	-- Development Plan Approvals
    INSERT INTO @ListofApprovers
    SELECT ApproverId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
	FROM DevelopmentPlanApprovals
		INNER JOIN DevelopmentPlanDetails ON DevelopmentPlanDetails.DevelopmentPlanDetailId = DevelopmentPlanApprovals.DevelopmentPlanDetailId
		INNER JOIN dbo.DevelopmentPlans ON DevelopmentPlans.DevelopmentPlanId = DevelopmentPlanDetails.DevelopmentPlanId
    	INNER JOIN Profiles ON Profiles.AppraisalId = DevelopmentPlans.AppraisalId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId    	
    WHERE DevelopmentPlanApprovals.ApprovalStatusID = (SELECT ApprovalStatusID FROM ApprovalStatuses WHERE Title = 'Pending') 
		AND DevelopmentPlanApprovals.DevelopmentPlanDetailID IS NOT NULL
		AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
		AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND Profiles.TerminationDate IS NULL
		AND Profiles.DivisionID != 14
		
	-- Employee Self Assessment Submitted
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN HumanResource ON HumanResource.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 0
    AND (HumanResource.Id IS NULL or (HumanResource.SendToHr IS NOT NULL
    AND HumanResource.SendToManager IS NOT NULL))
	AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
	AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
	AND Profiles.TerminationDate IS NULL	
	AND Profiles.DivisionID != 14
	
	-- Signoff on Employee's Appraisal
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
	FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and EmployeeSignDate is not null
    AND ManagerSignDate is null
    AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
    AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
    AND Profiles.DivisionID != 14
    AND Profiles.TerminationDate IS NULL		  
    UNION ALL
    SELECT ManagerManager.NetworkId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		INNER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerId
		LEFT OUTER JOIN Profiles ManagerManager ON ManagerManager.ProfileId = Manager.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and ManagerSignDate is not null
    AND ManagersManagerSignDate is null
	AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
	AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
	AND Profiles.TerminationDate IS NULL	
	AND Profiles.DivisionID != 14
			
	-- Signoff on Your Appraisal
    INSERT INTO @ListofApprovers 
    SELECT Profiles.NetworkId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Profiles.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and EmployeeSignDate is null
    AND ManagerSignDate is null
    AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
    AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
	AND Profiles.TerminationDate IS NULL	
	AND Profiles.DivisionID != 14
	
    -- Mid Year Submitted
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en'), CountryLanguage.CountryId
    FROM dbo.MidYear
		INNER JOIN Profiles ON Profiles.ProfileId = MidYear.ProfileId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE EmpSignDate is not null
    AND MgrSignDate is null
	AND Profiles.Networkid NOT IN ('removed','Duplicate','deveritt','pdecker')
	AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
	AND Profiles.TerminationDate IS NULL	
    AND Profiles.DivisionID != 14
    
	SELECT Top 0 ApproverId, LanguageCode, LOA.CountryId, vw_Countries.CountryCode
	--SELECT DISTINCT ApproverId, LanguageCode, LOA.CountryId, vw_Countries.CountryCode
	FROM @ListofApprovers LOA
		INNER JOIN vw_Countries on vw_Countries.CountryID = LOA.CountryId
	WHERE ApproverId != ''
	AND SUBSTRING(ApproverId, 1, 1) between @StartLetter and @EndLetter
	AND vw_Countries.CountryCode = 'CA'
	Order by LanguageCode

END 
SET NOCOUNT OFF
COMMIT TRANSACTION;