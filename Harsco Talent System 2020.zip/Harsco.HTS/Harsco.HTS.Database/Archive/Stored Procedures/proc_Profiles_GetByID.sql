﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_Profiles_GetByID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveProfileID, 
        ArchiveAppraisalID, 
        NetworkID, 
        ManagerName, 
        EmployeeNumber, 
        EmployeeName, 
        Email, 
        DivisionName, 
        CountryName, 
        LocationName, 
        Address, 
        PhoneNumber, 
        JobTitle, 
        JobFamilyName,
        DateHired, 
        ModifiedBy, 
        ModifiedOn
    FROM Profiles
    WHERE ArchiveProfileID = @ArchiveProfileID
END