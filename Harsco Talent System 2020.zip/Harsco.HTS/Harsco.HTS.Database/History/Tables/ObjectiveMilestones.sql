﻿CREATE TABLE [History].[ObjectiveMilestones] (
    [CreatedOn]                DATETIME      CONSTRAINT [DF_ObjectiveMilestones_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ObjectiveMilestoneID]     INT           NOT NULL,
    [ObjectiveID]              INT           NOT NULL,
    [Title]                    NVARCHAR (50) NOT NULL,
    [DateDue]                  SMALLDATETIME NOT NULL,
    [MilestoneStatusID]        INT           NOT NULL,
    [MilestoneStatusTimeStamp] BINARY (8)    NOT NULL,
    [ModifiedBy]               NVARCHAR (50) NOT NULL,
    [ModifiedOn]               DATETIME      NOT NULL,
    [TimeStamp]                BINARY (50)   NOT NULL,
    CONSTRAINT [PK_ObjectiveMilestones] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ObjectiveMilestoneID] ASC)
);

