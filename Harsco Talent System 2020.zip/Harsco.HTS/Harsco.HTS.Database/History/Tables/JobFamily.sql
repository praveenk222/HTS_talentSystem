﻿CREATE TABLE [History].[JobFamily] (
    [CreatedOn]   DATETIME      NOT NULL,
    [JobFamilyId] INT           NOT NULL,
    [Description] VARCHAR (255) NOT NULL,
    [IsDeleted]   BIT           NOT NULL,
    [CreatedBy]   VARCHAR (50)  NOT NULL,
    [Created]     DATETIME      NOT NULL,
    [ModifiedBy]  VARCHAR (50)  NOT NULL,
    [ModifiedOn]  DATETIME      NOT NULL,
    CONSTRAINT [PK_JobFamily_1] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [JobFamilyId] ASC)
);

