﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 07/13/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetenciesListActive]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT Id, 
        Competency, 
        IsDeleted,
        CreatedBy, 
        CreatedOn,        
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentalCompetencies
	WHERE IsDeleted = 0
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;