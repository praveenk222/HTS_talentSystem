﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 07/13/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetenciesListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT Id, 
        Competency, 
        IsDeleted,
        CreatedBy, 
        CreatedOn,        
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentalCompetencies

END
SET NOCOUNT OFF
COMMIT TRANSACTION;