﻿CREATE TABLE [Archive].[MidYear_EmpMgrDevPlan] (
    [ArchiveMidYearEmpMgrDevID]  INT            IDENTITY (1, 1) NOT NULL,
    [OriginalMidYearEmpMgrDevID] INT            NULL,
    [ProfileID]                  INT            NOT NULL,
    [AppraisalTypeID]            INT            NOT NULL,
    [EmpDevPlan]                 NTEXT          NULL,
    [MgrDevPlan]                 NTEXT          NULL,
    [ReviewDate]                 DATETIME       NULL,
    [EmployeeName]               NVARCHAR (100) NULL,
    [ManagerName]                NVARCHAR (100) NULL,
    [CreatedBy]                  VARCHAR (50)   NOT NULL,
    [CreatedOn]                  DATETIME       NOT NULL,
    [ModifiedBy]                 VARCHAR (50)   NOT NULL,
    [ModifiedOn]                 DATETIME       NOT NULL,
    [DevPlanDetailId]            INT            NULL,
    PRIMARY KEY CLUSTERED ([ArchiveMidYearEmpMgrDevID] ASC)
);

