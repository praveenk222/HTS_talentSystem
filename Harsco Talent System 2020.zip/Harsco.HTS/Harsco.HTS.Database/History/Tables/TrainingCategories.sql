﻿CREATE TABLE [History].[TrainingCategories] (
    [CreatedOn]          DATETIME      CONSTRAINT [DF_TrainingCategories_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [TrainingCategoryID] INT           NOT NULL,
    [Title]              NVARCHAR (50) NOT NULL,
    [IsDeleted]          BIT           NOT NULL,
    [CreatedBy]          VARCHAR (50)  NOT NULL,
    [Created]            DATETIME      NOT NULL,
    [ModifiedBy]         NVARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME      NOT NULL,
    CONSTRAINT [PK_TrainingCategories] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [TrainingCategoryID] ASC)
);

