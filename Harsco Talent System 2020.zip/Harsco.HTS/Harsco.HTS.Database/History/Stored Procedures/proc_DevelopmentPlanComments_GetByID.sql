﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_DevelopmentPlanComments_GetByID]
    @DevelopmentPlanCommentID int
AS
BEGIN
    SELECT CreatedOn, 
        DevelopmentPlanCommentID, 
        DevelopmentPlanStrengthID, 
        DevelopmentPlanStrengthTimeStamp, 
        DevelopmentPlanWeaknessID, 
        DevelopmentPlanWeaknessTimeStamp, 
        DevelopmentPlanDetailID, 
        DevelopmentPlanDetailTimeStamp, 
        Comment, 
        Confidential, 
        CommentTypeID, 
        CommentTypeTimeStamp, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM DevelopmentPlanComments
    WHERE DevelopmentPlanCommentID = @DevelopmentPlanCommentID
    ORDER BY CreatedOn Desc
END