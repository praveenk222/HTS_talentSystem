﻿using System;
using System.Collections.Generic;

namespace Harsco.HTS.API.Models
{
    public partial class VwLanguages
    {
        public int LanguageId { get; set; }
        public string LanguageName { get; set; }
    }
}
