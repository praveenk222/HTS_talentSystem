﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 01/31/2013
-- [dbo].[AppraisalsModify] 564, 'N', 'Y', true, false, 'test','1/1/2013'
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalsModify]

@AppraisalID int,
@COCViolation varchar(1),
@ManagerMeeting varchar(1),
@SelfAssessment bit,
@SignEmployee bit,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime
    
AS
BEGIN
	IF (@SignEmployee = 1)
	BEGIN 
	   UPDATE Appraisals
		SET EmployeeName = 'HR Sign',
			EmployeeSignDate = @ModifiedOn, 
			ModifiedBy = @ModifiedBy, 
			ModifiedOn = @ModifiedOn
		WHERE AppraisalID = @AppraisalID
	END    
	                    
    UPDATE Appraisals
    SET COCViolation = @COCViolation, 
        ManagerMeeting = @ManagerMeeting,
		SelfAssessmentComplete = @SelfAssessment,
        ModifiedBy = @ModifiedBy, 
        ModifiedOn = @ModifiedOn
    WHERE AppraisalID = @AppraisalID
END