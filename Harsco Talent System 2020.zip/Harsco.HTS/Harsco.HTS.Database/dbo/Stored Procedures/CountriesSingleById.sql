﻿

-- =============================================
-- Author:		Ed Blair
-- Create date: 5/1/2013
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CountriesSingleById]

@Id int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

		SELECT CountryID, CountryName, CountryCode
		FROM dbo.vw_Countries 
		WHERE CountryID = @Id
	  
END
SET NOCOUNT OFF
COMMIT TRANSACTION;