﻿


-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 05/13/2013
--  [dbo].[DevelopmentPlansNotApprovedByAppraisalId] 591
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentPlansNotApprovedByAppraisalId]

@AppraisalId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  select *
  from DevelopmentPlans
	INNER JOIN DevelopmentPlanDetails ON DevelopmentPlanDetails.DevelopmentPlanId = DevelopmentPlans.DevelopmentPlanId
	INNER JOIN DevelopmentPlanApprovals on DevelopmentPlanApprovals.DevelopmentPlanDetailId = DevelopmentPlanDetails.DevelopmentPlanDetailId
		AND StatusChangedDate = (select Max(StatusChangedDate) FROM DevelopmentPlanApprovals WHERE DevelopmentPlanDetailID = DevelopmentPlanDetails.DevelopmentPlanDetailId)
  WHERE AppraisalID = @AppraisalId
  AND DevelopmentPlanApprovals.ApprovalStatusId != 2
  
END
SET NOCOUNT OFF
COMMIT TRANSACTION;