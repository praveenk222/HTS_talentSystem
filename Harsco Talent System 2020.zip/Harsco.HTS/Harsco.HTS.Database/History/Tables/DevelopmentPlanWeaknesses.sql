﻿CREATE TABLE [History].[DevelopmentPlanWeaknesses] (
    [CreatedOn]                 DATETIME      CONSTRAINT [DF_DevelopmentPlanWeaknesses_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [DevelopmentPlanWeaknessID] INT           NOT NULL,
    [DevelopmentPlanID]         INT           NOT NULL,
    [DevelopmentPlanTimeStamp]  BINARY (8)    NOT NULL,
    [Weakness]                  NTEXT         NOT NULL,
    [ModifiedBy]                NVARCHAR (50) NOT NULL,
    [ModifiedOn]                DATETIME      NOT NULL,
    [TimeStamp]                 BINARY (50)   NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanWeaknesses] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanWeaknessID] ASC)
);

