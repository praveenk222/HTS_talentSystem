﻿
-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 09/26/2012
-- =============================================
CREATE PROCEDURE [dbo].[GIS_HeadCount_FindManager]

AS

DECLARE @ADName varchar(50)
DECLARE @Count int
DECLARE @RowNumber int
DECLARE @ProfileId int
DECLARE @CurrentProfile varchar(50)
DECLARE @SuperLastName varchar(255)
DECLARE @SuperFirstName varchar(255)
DECLARE @CurrentManager int
	
DECLARE @EmployeeTable TABLE
(Id int IDENTITY(1,1),
Row_Wid varchar(255),
NetWorkId varchar(50),
SuperLastName varchar(255),
SuperFirstName varchar(255))

BEGIN
	INSERT INTO  @EmployeeTable
	SELECT convert(varchar(355), ROW_WID), ADName,	
		CASE WHEN charindex(',',SuperVisor_NM) > 0 THEN
			RTRIM(LTRIM(left(SuperVisor_NM,charindex(',',SuperVisor_NM)-1)))
		else
			CASE WHEN charindex(' ',Supervisor_NM) > 0 THEN
				RTRIM(LTRIM(SUBSTRING(SuperVisor_NM, charindex(' ',SuperVisor_NM)+1, len(Supervisor_NM))))
			
		ELSE
			SubString(SuperVisor_NM,charindex(',',SuperVisor_NM)+2, len(Supervisor_NM))

		END end as LastName,

		LTRIM(RTRIM(REPLACE(CASE WHEN charindex(',',SuperVisor_NM) > 0 THEN
			 RTRIM(LTRIM(SUBSTRING(SuperVisor_NM, charindex(' ',SuperVisor_NM)+1, len(Supervisor_NM))))
		else
			CASE WHEN charindex(' ',SuperVisor_NM) > 0 THEN
				RTRIM(LTRIM(left(SuperVisor_NM,charindex(' ',SuperVisor_NM)-1)))
		else
			SuperVisor_NM
		END END,'Mr.',''))) as firstName
		FROM dbo.GIS_HeadCount_Import
			INNER JOIN Profiles on Profiles.NetWorkID = GIS_HeadCount_Import.ADName
	WHERE ISNULL(SuperVisor_NM,'') NOT IN ('','N/A')
	AND Profiles.ManagerID IS NULL
	
	SET @Count = @@ROWCOUNT
	SET @RowNumber = 1

	--now loop through the temp table to remove initials from first name
	WHILE @RowNumber <= @Count
	BEGIN
		SELECT @SuperLastName = SuperLastName, @SuperFirstName = SuperFirstName
		FROM @EmployeeTable
		WHERE ID = @RowNumber
		
		if (charindex(' ',@SuperFirstName) > 0) 
			set @SuperFirstName = SUBSTRING(@SuperFirstName, 1, charindex(' ',@SuperFirstName))
		
		UPDATE @EmployeeTable SET SuperFirstName = LTRIM(RTRIM(@SuperFirstName))
		WHERE Id = @RowNumber
		
		set @RowNumber = @RowNumber + 1
	END


	SET @RowNumber = 1

	--now loop through the temp table
	WHILE @RowNumber <= @Count
	BEGIN
		SELECT @CurrentProfile = NetWorkId, @SuperLastName = SuperLastName, @SuperFirstName = SuperFirstName
		FROM @EmployeeTable em
		WHERE em.Id = @RowNumber 

		-- get AD of manager
		SELECT TOP 1 @ADName = ADName
		FROM GIS_HeadCount_Import
		WHERE First_Name = @SuperFirstName
		AND Last_Name = @SuperLastName
		
		if @@Rowcount > 0
		BEGIN
			--get profileId of manager
			select @ProfileId = ProfileID
			from Profiles
			WHERE NetWorkId = @ADName
			if @@Rowcount > 0
			BEGIN
				-- make sure they don't already have a manager
				--SELECT @CurrentManager= ManagerId FROM Profiles WHERE NetworkId = @CurrentProfile
				
				--if @CurrentManager IS Null
				UPDATE Profiles SET ManagerId = @ProfileId
					WHERE NetworkId = @CurrentProfile
			END
		END
		
		SET @RowNumber = @RowNumber + 1	
		
	END	
END		
SET NOCOUNT OFF