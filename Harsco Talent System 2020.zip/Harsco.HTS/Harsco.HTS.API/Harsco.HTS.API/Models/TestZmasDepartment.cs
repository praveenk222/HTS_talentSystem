﻿using System;
using System.Collections.Generic;

namespace Harsco.HTS.API.Models
{
    public partial class TestZmasDepartment
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
        public bool? Status { get; set; }
    }
}
