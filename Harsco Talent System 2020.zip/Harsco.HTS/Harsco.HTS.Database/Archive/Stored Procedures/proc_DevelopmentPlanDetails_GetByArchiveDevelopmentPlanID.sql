﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanDetails_GetByArchiveDevelopmentPlanID]
    @ArchiveDevelopmentPlanID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanDetailID, 
        ArchiveDevelopmentPlanID, 
        Category, 
        Objective, 
        Activity, 
        SupportRequired, 
        DateDue, 
        MeasurementProcess, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanDetails
    WHERE ArchiveDevelopmentPlanID = @ArchiveDevelopmentPlanID
END