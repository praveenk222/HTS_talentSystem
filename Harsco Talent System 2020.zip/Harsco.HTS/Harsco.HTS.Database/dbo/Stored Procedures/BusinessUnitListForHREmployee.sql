﻿


-- =============================================
-- Author:		Ed Blair
-- Create date: 03/08/2013
-- Description:	
-- [BusinessUnitListForHREmployee] 'emartinez'
-- =============================================
CREATE PROCEDURE [dbo].[BusinessUnitListForHREmployee]

@CurrentUser nvarchar(50)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @seeAll int
	
	SELECT @seeAll=ISNULL(HRBP,0) 
	FROM HRUsers
	INNER JOIN HRPermissions ON HRPermissions.HRUserId = HRUsers.HRUserId
	WHERE HRUsers.UserName = @CurrentUser
		
	If (@seeAll = 1) 
	BEGIN
		SELECT BusinessUnitId, BusinessUnitName, Abbreviation, DisplayName 
		FROM vw_BusinessUnits
		ORDER BY BusinessUnitName
	END
	ELSE
	BEGIN
		SELECT distinct vw_BusinessUnits.BusinessUnitId, vw_BusinessUnits.BusinessUnitName, vw_BusinessUnits.Abbreviation, vw_BusinessUnits.DisplayName 
		FROM HRUsers
			INNER JOIN HRPermissions on HRPermissions.HRUserId = HRUsers.HRUserId
			LEFT OUTER JOIN dbo.vw_BusinessUnits ON vw_BusinessUnits.BusinessUnitId = HRPermissions.BusinessGroupId
		WHERE UserName = @CurrentUser
		AND HRPermissions.BusinessGroupId IN (SELECT BusinessGroupId FROM dbo.vw_BusinessUnits)
		AND BusinessUnitName IS NOT NULL
		ORDER BY BusinessUnitName
	END

END
SET NOCOUNT OFF
COMMIT TRANSACTION;