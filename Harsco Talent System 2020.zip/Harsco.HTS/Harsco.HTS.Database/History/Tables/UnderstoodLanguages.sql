﻿CREATE TABLE [History].[UnderstoodLanguages] (
    [CreatedOn]                DATETIME      CONSTRAINT [DF_UnderstoodLanguages_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [UnderstoodLanguageID]     INT           NOT NULL,
    [ProfileID]                INT           NOT NULL,
    [Language]                 NVARCHAR (50) NOT NULL,
    [Description]              NTEXT         NULL,
    [LanguageFluencyID]        INT           NOT NULL,
    [LanguageFluencyTimeStamp] BINARY (8)    NOT NULL,
    [ModifiedBy]               NVARCHAR (50) NOT NULL,
    [ModifiedOn]               DATETIME      NOT NULL,
    [TimeStamp]                BINARY (50)   NOT NULL,
    CONSTRAINT [PK_UnderstoodLanguages] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [UnderstoodLanguageID] ASC)
);

