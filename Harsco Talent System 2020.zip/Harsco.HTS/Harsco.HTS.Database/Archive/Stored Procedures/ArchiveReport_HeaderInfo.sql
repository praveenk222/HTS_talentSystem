﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/24
-- [Archive].[ArchiveReport_HeaderInfo] 36, 37, 'es'
-- =============================================
CREATE PROCEDURE  [Archive].[ArchiveReport_HeaderInfo]

@ProfileId int,
@AppraisalId int,
@LanguageCode varchar(20)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

	DECLARE @Translate TABLE
	(Keyphrase varchar(255),
	TranslatedText varchar(1000))

	INSERT INTO @Translate 
	SELECT KeyPhrase, TranslatedText 
		FROM dbo.Translations
		INNER JOIN dbo.TranslationLanguages ON TranslationLanguages.ID = Translations.TranslationLanguageId
			AND TranslationLanguages.Code = @LanguageCode
			
	SELECT Profiles.EmployeeName, JobTitle, Email, Profiles.ManagerName, JobFamilyName, DateHired, DivisionName, LocationName, Appraisals.AppraisalType,
	(SUBSTRING(Appraisals.AppraisalType,0,6) + (SELECT TranslatedText FROM @Translate WHERE Keyphrase = SUBSTRING(AppraisalType,6, len(AppraisalType)-4))) as Title,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblName') AS NameHeader,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblManager') AS ManagerHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblBusinessUnit') AS BusinessUnitHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblJobTitle') AS JobTitleHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblJobFamily') AS JobFamilyHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblCurrentLocation') AS CurrentLocationHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblJoinDate') AS DateofJoiningHeading,
	(SELECT TranslatedText FROM @Translate WHERE Keyphrase = 'lblAppraisalPeriod') AS AppraisalPeriodHeading
	FROM Archive.Profiles
		INNER JOIN Archive.Appraisals ON Appraisals.ArchiveAppraisalID = Profiles.ArchiveAppraisalID
    WHERE Profiles.ArchiveProfileId = @ProfileId

END
SET NOCOUNT OFF
COMMIT TRANSACTION;