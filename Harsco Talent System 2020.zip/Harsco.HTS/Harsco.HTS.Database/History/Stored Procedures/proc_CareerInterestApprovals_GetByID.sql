﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_CareerInterestApprovals_GetByID]
    @CareerInterestApprovalID int
AS
BEGIN
    SELECT CreatedOn, 
        CareerInterestApprovalID, 
        CareerInterestID, 
        CareerInterestTimeStamp, 
        ApprovalStatusID, 
        ApprovalStatusTimeStamp, 
        Comment, 
        StatusChangedDate, 
        ApproverName, 
        ApproverID, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM CareerInterestApprovals
    WHERE CareerInterestApprovalID = @CareerInterestApprovalID
    ORDER BY CreatedOn Desc
END