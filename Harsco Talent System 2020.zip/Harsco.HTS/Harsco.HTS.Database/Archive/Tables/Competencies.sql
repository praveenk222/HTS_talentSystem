﻿CREATE TABLE [Archive].[Competencies] (
    [ArchiveCompetencyID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalCompetencyID] INT           NOT NULL,
    [ArchiveAppraisalID]   INT           NOT NULL,
    [EnterpriseCompetency] NVARCHAR (50) NOT NULL,
    [EmployeeSkillRating]  NVARCHAR (50) NULL,
    [ManagerSkillRating]   VARCHAR (50)  NULL,
    [CreatedBy]            VARCHAR (50)  NOT NULL,
    [CreatedOn]            DATETIME      NOT NULL,
    [ModifiedBy]           NVARCHAR (50) NOT NULL,
    [ModifiedOn]           DATETIME      CONSTRAINT [DF_Competencies_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Competencies] PRIMARY KEY CLUSTERED ([ArchiveCompetencyID] ASC),
    CONSTRAINT [FK_Competencies_Appraisals] FOREIGN KEY ([ArchiveAppraisalID]) REFERENCES [Archive].[Appraisals] ([ArchiveAppraisalID])
);


GO
CREATE TRIGGER [Archive].[tr_Competencies_PreventChanges]     ON  Archive.Competencies     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END