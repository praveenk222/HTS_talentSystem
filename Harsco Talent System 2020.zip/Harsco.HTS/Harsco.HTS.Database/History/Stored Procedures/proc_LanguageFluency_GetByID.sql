﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_LanguageFluency_GetByID]
    @LanguageFluencyID int
AS
BEGIN
    SELECT CreatedOn, 
        LanguageFluencyID, 
        Title, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM LanguageFluency
    WHERE LanguageFluencyID = @LanguageFluencyID
    ORDER BY CreatedOn Desc
END