﻿CREATE TABLE [Archive].[CareerInterestApprovals] (
    [ArchiveCareerInterestApprovalID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalCareerInterestApprovalID] INT           NOT NULL,
    [ArchiveCareerInterestID]          INT           NOT NULL,
    [ApprovalStatus]                   NVARCHAR (50) NOT NULL,
    [Comment]                          NTEXT         NULL,
    [StatusChangeDate]                 DATETIME      NULL,
    [ApproverName]                     NVARCHAR (75) NOT NULL,
    [ApproverID]                       NVARCHAR (20) NOT NULL,
    [ModifiedBy]                       NVARCHAR (50) NOT NULL,
    [ModifiedOn]                       DATETIME      CONSTRAINT [DF_CareerInterestApprovals_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_CareerInterestApprovals] PRIMARY KEY CLUSTERED ([ArchiveCareerInterestApprovalID] ASC),
    CONSTRAINT [FK_CareerInterestApprovals_CareerInterests] FOREIGN KEY ([ArchiveCareerInterestID]) REFERENCES [Archive].[CareerInterests] ([ArchiveCareerInterestID])
);


GO
CREATE TRIGGER [Archive].[tr_CareerInterestApprovals_PreventChanges]     ON  Archive.CareerInterestApprovals     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END