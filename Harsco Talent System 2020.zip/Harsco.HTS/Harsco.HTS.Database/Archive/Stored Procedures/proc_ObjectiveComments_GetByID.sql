﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_ObjectiveComments_GetByID]
    @ArchiveObjectiveCommentID int
AS
BEGIN
    SELECT ArchiveObjectiveCommentID, 
        ArchiveObjectiveID, 
        ArchiveObjectiveMilestoneID, 
        Comment, 
        Confidential, 
        CommentType, 
        ModifiedBy, 
        ModifiedOn
    FROM ObjectiveComments
    WHERE ArchiveObjectiveCommentID = @ArchiveObjectiveCommentID
END