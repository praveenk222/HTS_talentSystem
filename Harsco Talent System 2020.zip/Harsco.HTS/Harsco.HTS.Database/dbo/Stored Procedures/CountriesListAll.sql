﻿


-- =============================================
-- Author:		Ed Blair
-- Create date: 10/3/2012
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CountriesListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

		SELECT CountryID, CountryName, CountryCode
		FROM dbo.vw_Countries 
		ORDER BY CountryName
	  
END
SET NOCOUNT OFF
COMMIT TRANSACTION;