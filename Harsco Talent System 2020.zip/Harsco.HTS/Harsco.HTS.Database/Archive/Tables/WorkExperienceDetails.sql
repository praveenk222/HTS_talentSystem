﻿CREATE TABLE [Archive].[WorkExperienceDetails] (
    [ArchiveWorkExperienceDetailID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalWorkExperienceDetailID] INT           NOT NULL,
    [ArchiveWorkExperienceID]        INT           NOT NULL,
    [Title]                          NVARCHAR (75) NOT NULL,
    [Responsibilities]               NTEXT         NOT NULL,
    [Sequence]                       INT           NOT NULL,
    [ModifiedBy]                     NVARCHAR (50) NOT NULL,
    [ModifiedOn]                     DATETIME      CONSTRAINT [DF_WorkExperienceDetails_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_WorkExperienceDetails_1] PRIMARY KEY CLUSTERED ([ArchiveWorkExperienceDetailID] ASC),
    CONSTRAINT [FK_WorkExperienceDetails_WorkExperiences] FOREIGN KEY ([ArchiveWorkExperienceID]) REFERENCES [Archive].[WorkExperiences] ([ArchiveWorkExperienceID])
);


GO
CREATE TRIGGER [Archive].[tr_WorkExperienceDetails_PreventChanges]     ON  Archive.WorkExperienceDetails     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END