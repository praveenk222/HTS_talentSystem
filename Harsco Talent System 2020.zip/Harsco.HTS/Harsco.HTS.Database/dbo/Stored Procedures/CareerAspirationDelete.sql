﻿
-- =============================================
-- Author:		Ed Blair
-- Create date: 09/24/2014
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CareerAspirationDelete]

@Id int

AS

BEGIN
	DELETE FROM CareerAspiration
	WHERE Id = @Id
	
END