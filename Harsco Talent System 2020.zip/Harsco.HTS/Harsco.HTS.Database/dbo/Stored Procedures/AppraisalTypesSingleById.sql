﻿

-- =============================================
-- AUTHOR:		Ed Blair
-- CREATED DATE: 05/1/2013
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalTypesSingleById]

@Id int
    
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT AppraisalTypeID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn,
        [TimeStamp]
    FROM AppraisalTypes
    WHERE AppraisalTypeID = @Id
    
END
SET NOCOUNT OFF
COMMIT TRANSACTION;