﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [ApiController]
    [Route("[controller]")]
    public class PerformancePlanController : ControllerBase
    {
        [HttpGet]
        [Route("GetObjectivesByID")]
        public IActionResult GetObjectivesByID(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                List<vmObjective> objectivesListVM = new List<vmObjective>();
                var profile = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
                List<Objectives> objectivesListDB = db.Objectives.Include(x => x.ObjectiveApprovals).Where(p => p.AppraisalId == profile.AppraisalId).OrderBy(p => p.DateDue).ToList();
                var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == profile.AppraisalId).SingleOrDefault();
                foreach (var objectiveDB in objectivesListDB)
                {
                    vmObjective objectiveVM = new vmObjective();
                    objectiveVM.ObjectiveApprovals = new List<vmObjectiveApproval>();
                    objectiveDB.BindModelTo(objectiveVM);
                    foreach (var objectiveApprDB in objectiveDB.ObjectiveApprovals)
                    {
                        vmObjectiveApproval objectiveApprovalVM = new vmObjectiveApproval();
                        objectiveApprDB.BindModelTo(objectiveApprovalVM);
                        objectiveVM.ObjectiveApprovals.Add(objectiveApprovalVM);
                    }

                    if (appraisalDB.SelfAssessmentComplete || appraisalDB.ManagerStepComplete)
                    {
                        objectiveVM.IsEndYearSubmitted = true;
                    }
                    else
                    {
                        objectiveVM.IsEndYearSubmitted = false;
                    }
                    objectivesListVM.Add(objectiveVM);
                }

                return Ok(objectivesListVM);
            }
        }

        [HttpGet]
        [Route("GetObjectivesApprovalsByID")]
        public IActionResult GetObjectivesApprovalsByID(int ObjectiveID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                List<vmObjectiveApproval> objectivesApprovalListVM = new List<vmObjectiveApproval>();
                var objectiveApprovalsListDB = db.ObjectiveApprovals.Where(p => p.ObjectiveId == ObjectiveID).ToList();
                foreach (var objectiveApprovalDB in objectiveApprovalsListDB)
                {
                    vmObjectiveApproval objectiveApprVM = new vmObjectiveApproval();
                    objectiveApprovalDB.BindModelTo(objectiveApprVM);
                    objectivesApprovalListVM.Add(objectiveApprVM);
                }

                return Ok(objectivesApprovalListVM);
            }
        }

        [HttpPost]
        [Route("CreateObjective")]
        public IActionResult CreateObjective(vmObjective objectiveVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var managerProfile = db.Profiles.Where(p => p.ProfileId == objectiveVM.DisplayUser.ManagerId).SingleOrDefault();
                Objectives objectivesDB = new Objectives();
                ObjectiveApprovals objectiveApprovalsDB = new ObjectiveApprovals();
                MidYear midYearDB = new MidYear();
                objectiveVM.BindModelTo(objectivesDB);
                objectivesDB.AppraisalId = objectiveVM.DisplayUser.AppraisalId;
                objectivesDB.ModifiedBy = objectiveVM.LoggedInUser.NetworkId;
                objectivesDB.CreatedBy = objectiveVM.LoggedInUser.NetworkId;
                objectivesDB.ModifiedOn = DateTime.Now;
                objectivesDB.CreatedOn = DateTime.Now;
                objectivesDB.YearEndResults = string.Empty;
                objectivesDB.ManagerYearEndResults = string.Empty;
                db.Objectives.Add(objectivesDB);
                db.SaveChanges();

                //Objective Approval Section
                objectiveApprovalsDB.ObjectiveId = objectivesDB.ObjectiveId;
                objectiveApprovalsDB.ApprovalStatusId = (int)ObjectiveApprovalStatus.Created;
                objectiveApprovalsDB.ApproverName = managerProfile.EmployeeName;
                objectiveApprovalsDB.ApproverId = managerProfile.NetworkId;
                objectiveApprovalsDB.ModifiedBy = objectiveVM.LoggedInUser.NetworkId;
                objectiveApprovalsDB.ModifiedOn = DateTime.Now;
                objectiveApprovalsDB.StatusChangedDate = DateTime.Now;
                db.ObjectiveApprovals.Add(objectiveApprovalsDB);
                db.SaveChanges();

                Appraisals appraisals = db.Appraisals.Where(a => a.AppraisalId == objectiveVM.LoggedInUser.AppraisalId).SingleOrDefault();
                var appraisalTypes = db.AppraisalTypes.Where(p => p.AppraisalTypeId == appraisals.AppraisalTypeId).FirstOrDefault();

                if (appraisalTypes.Title.ToLower().IndexOf("mid") > -1)
                {
                    //MidYear Section
                    midYearDB.ProfileId = objectiveVM.LoggedInUser.ProfileId;
                    midYearDB.AppraisalTypeId = appraisals.AppraisalTypeId; // 17; //to be changed as per the advice
                    midYearDB.CreatedBy = objectiveVM.DisplayUser.NetworkId;
                    midYearDB.CreatedOn = DateTime.Now;
                    midYearDB.ModifiedBy = objectiveVM.DisplayUser.NetworkId;
                    midYearDB.ModifiedOn = DateTime.Now;
                    midYearDB.ObjectiveId = objectivesDB.ObjectiveId;
                    db.MidYear.Add(midYearDB);
                    db.SaveChanges();
                }

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("UpdateObjective")]
        public IActionResult UpdateObjective(vmObjective objectiveVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                if(objectiveVM != null)
                {
                    var managerProfile = db.Profiles.Where(p => p.ProfileId == objectiveVM.DisplayUser.ManagerId).SingleOrDefault();
                    var objectivesDB = db.Objectives.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).SingleOrDefault();
                    var ObjectiveApprovals = db.ObjectiveApprovals.Where(oa => oa.ObjectiveId == objectiveVM.ObjectiveId).FirstOrDefault();

                    objectivesDB.Description = objectiveVM.Description; 
                    objectivesDB.DateDue = objectiveVM.DateDue;

                    if (ObjectiveApprovals != null)
                    {
                        ObjectiveApprovals.ObjectiveId = objectiveVM.ObjectiveId;
                        ObjectiveApprovals.ApprovalStatusId = (int)ObjectiveApprovalStatus.Created;
                        ObjectiveApprovals.ApproverName = managerProfile.EmployeeName;
                        ObjectiveApprovals.ApproverId = managerProfile.NetworkId;
                        ObjectiveApprovals.ModifiedBy = objectiveVM.LoggedInUser.NetworkId;
                        ObjectiveApprovals.ModifiedOn = DateTime.Now;
                    }
                    else
                    {
                        ObjectiveApprovals objectiveApprovalsDB = new ObjectiveApprovals();
                        objectiveApprovalsDB.ObjectiveId = objectiveVM.ObjectiveId;
                        objectiveApprovalsDB.ApprovalStatusId = (int)ObjectiveApprovalStatus.Created;
                        objectiveApprovalsDB.ApproverName = managerProfile.EmployeeName;
                        objectiveApprovalsDB.ApproverId = managerProfile.NetworkId;
                        objectiveApprovalsDB.ModifiedBy = objectiveVM.LoggedInUser.NetworkId;
                        objectiveApprovalsDB.ModifiedOn = DateTime.Now;
                        db.ObjectiveApprovals.Add(objectiveApprovalsDB);
                    }
                    db.SaveChanges();
                    return Ok(new { status = "Success" });
                }
                else
                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("SubmitObjective")]
        public IActionResult SubmitObjective(vmObjective objectiveVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var objectiveApprovalDb = db.ObjectiveApprovals.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).OrderByDescending(p => p.ObjectiveApprovalId).FirstOrDefault();

                objectiveApprovalDb.ApprovalStatusId = (int)ObjectiveApprovalStatus.Submitted;
                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }

        [HttpPost]
        [Route("DeleteObjective")]
        public IActionResult DeleteObjective(vmObjective objectiveVM)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                var objectiveDB = db.Objectives.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).SingleOrDefault();
                db.Objectives.Remove(objectiveDB);

                var objectiveApprovalDbList = db.ObjectiveApprovals.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).ToList();
                db.ObjectiveApprovals.RemoveRange(objectiveApprovalDbList);

                //Delete MidYear record with the ObjectiveID
                var midYearDB = db.MidYear.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).SingleOrDefault();
                if (midYearDB != null)
                {
                    db.MidYear.Remove(midYearDB);
                }

                db.SaveChanges();

                return Ok(new { status = "Success" });
            }
        }



        [HttpGet]
        [Route("IsUserInCurrentCycle")]
        public IActionResult IsUserInCurrentCycle(int AppraisalID, int AppraisalTypeID)
        {
            PostResult obj = new PostResult();
            ;
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    
                    obj = db.postResults.FromSqlRaw("USP_Check_UserInCurrentCycle {0},{1}", AppraisalID, AppraisalTypeID).ToList()[0];
                    return Ok(obj);
                }
            }
            catch (Exception)
            {

                return Ok(obj);
            }

          
        }



    }
}