﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanComments_GetByArchiveDevelopmentPlanDetailID]
    @ArchiveDevelopmentPlanDetailID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanCommentID, 
        ArchiveDevelopmentPlanStrengthID, 
        ArchiveDevelopmentPlanWeaknessID, 
        ArchiveDevelopmentPlanDetailID, 
        Comment, 
        Confidential, 
        CommentType, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanComments
    WHERE ArchiveDevelopmentPlanDetailID = @ArchiveDevelopmentPlanDetailID
END