﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_DevelopmentPlanWeaknesses_GetByArchiveDevelopmentPlanID]
    @ArchiveDevelopmentPlanID int
AS
BEGIN
    SELECT ArchiveDevelopmentPlanWeaknessID, 
        ArchiveDevelopmentPlanID, 
        Weakness, 
        ModifiedBy, 
        ModifiedOn
    FROM DevelopmentPlanWeaknesses
    WHERE ArchiveDevelopmentPlanID = @ArchiveDevelopmentPlanID
END