﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 07/24/2012
-- =============================================
CREATE PROCEDURE [dbo].[AwardsPatentsRecognitionsUpdate]

@AwardPatentRecognitionID int,
@ProfileID int,
@Description ntext,
@DateReceived varchar(4),
@ReferenceNumber nvarchar(20),
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
    UPDATE AwardsPatentsRecognitions
    SET ProfileID = @ProfileID, 
        Description = @Description, 
        DateReceived = @DateReceived, 
        ReferenceNumber = @ReferenceNumber, 
        ModifiedBy = @ModifiedBy, 
        ModifiedOn = @ModifiedOn
    WHERE AwardPatentRecognitionID = @AwardPatentRecognitionID
END