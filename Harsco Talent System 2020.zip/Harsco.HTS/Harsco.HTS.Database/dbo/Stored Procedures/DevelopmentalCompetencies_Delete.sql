﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 7/13/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetencies_Delete]

@Id int,
@ModifiedBy nvarchar(50)

AS

BEGIN

	UPDATE DevelopmentalCompetencies
	SET	IsDeleted = 1, 
		ModifiedBy = @ModifiedBy, 
		ModifiedOn = getdate()
	WHERE Id = @ID

END