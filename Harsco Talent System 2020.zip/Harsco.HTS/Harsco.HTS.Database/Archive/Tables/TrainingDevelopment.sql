﻿CREATE TABLE [Archive].[TrainingDevelopment] (
    [ArchiveTrainingDevelopmentID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalTrainingDevelopmentID] INT           NOT NULL,
    [ArchiveProfileID]              INT           NOT NULL,
    [Description]                   NTEXT         NOT NULL,
    [TrainingCategory]              NVARCHAR (50) NOT NULL,
    [CertificationNumber]           NVARCHAR (20) NULL,
    [YearObtained]                  INT           NULL,
    [ExpirationDate]                SMALLDATETIME NULL,
    [ModifiedBy]                    NVARCHAR (50) NOT NULL,
    [ModifiedOn]                    DATETIME      CONSTRAINT [DF_TrainingDevelopment_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_TrainingDevelopment_1] PRIMARY KEY CLUSTERED ([ArchiveTrainingDevelopmentID] ASC),
    CONSTRAINT [FK_TrainingDevelopment_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);


GO
CREATE TRIGGER [Archive].[tr_TrainingDevelopment_PreventChanges]     ON  Archive.TrainingDevelopment     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END