﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 8/16/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetenciesListActiveTranslated]

@TranslationCode varchar(2)

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT DevelopmentalCompetencies.Id, ISNULL(Translations.TranslatedText,DevelopmentalCompetencies.Competency) as Competency
    FROM DevelopmentalCompetencies
		INNER JOIN dbo.Translations ON Translations.KeyPhrase = DevelopmentalCompetencies.Competency 
		INNER JOIN TranslationLanguages ON TranslationLanguages.Id = TranslationLanguageId
			and Code = @TranslationCode
	WHERE IsDeleted = 0
	ORDER BY ISNULL(Translations.TranslatedText,DevelopmentalCompetencies.Competency)
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;