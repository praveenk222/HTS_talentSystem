﻿CREATE TABLE [History].[ObjectiveApprovals] (
    [CreatedOn]                   DATETIME      CONSTRAINT [DF_ObjectiveApprovals_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ObjectiveApprovalID]         INT           NOT NULL,
    [ObjectiveID]                 INT           NULL,
    [ObjectiveMilestoneID]        INT           NULL,
    [ObjectiveMilestoneTimeStamp] BINARY (8)    NULL,
    [ApprovalStatusID]            INT           NOT NULL,
    [ApprovalStatusTimeStamp]     BINARY (8)    NOT NULL,
    [Comment]                     NTEXT         NULL,
    [StatusChangedDate]           DATETIME      NULL,
    [ApproverName]                NVARCHAR (75) NOT NULL,
    [ApproverID]                  NVARCHAR (20) NOT NULL,
    [ModifiedBy]                  NVARCHAR (50) NOT NULL,
    [ModifiedOn]                  DATETIME      NOT NULL,
    [TimeStamp]                   BINARY (50)   NOT NULL,
    CONSTRAINT [PK_ObjectiveApprovals] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ObjectiveApprovalID] ASC)
);

