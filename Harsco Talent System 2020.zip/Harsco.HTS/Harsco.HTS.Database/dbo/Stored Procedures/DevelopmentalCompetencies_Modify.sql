﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 7/13/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentalCompetencies_Modify]

@Id int,
@Competency varchar(50),
@IsDeleted bit,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.DevelopmentalCompetencies WHERE Id = @Id))
		BEGIN
			UPDATE DevelopmentalCompetencies
			SET Competency = @Competency, 
				IsDeleted = @IsDeleted, 
				ModifiedBy = @ModifiedBy, 
				ModifiedOn = @ModifiedOn
			WHERE Id = @ID
		END
    ELSE
		BEGIN
			INSERT INTO DevelopmentalCompetencies
			(Competency, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@Competency, @IsDeleted, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)

		END
END