﻿



-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 08/13/2012
-- =============================================
-- Exec [Archive].[ArchiveProfiles_GetByArchiveAppraisalID] 1

CREATE PROCEDURE  [Archive].[ArchiveProfiles_GetByArchiveAppraisalID]

@ArchiveAppraisalID int

AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ArchiveProfileID, 
        ArchiveAppraisalID, 
        NetworkID, 
        ManagerName, 
        EmployeeNumber, 
        EmployeeName, 
        Email, 
        DivisionName, 
        CountryName, 
        LocationName, 
        [Address], 
        PhoneNumber, 
        JobTitle, 
        JobFamilyName,
        DateHired, 
        ModifiedBy, 
        ModifiedOn
    FROM Profiles
    WHERE ArchiveAppraisalID = @ArchiveAppraisalID

END
SET NOCOUNT OFF
COMMIT TRANSACTION;