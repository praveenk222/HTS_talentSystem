﻿using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("[controller]")]
    [ApiController]
    public class NoticationsController : ControllerBase
    {
        [HttpGet]
        [Route("GetNotifications")]
        public IActionResult GetNotifications(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                vmNotifications notifications = new vmNotifications();
                var profile = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();

                return Ok(notifications);
            }
        }

        [HttpGet]
        [Route("GetAppraisalType")]
        public IActionResult GetAppraisalType(int profileID)
        {
            using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
            {
                vmAppraisalType appraisalty = new vmAppraisalType();
                var profile = db.Profiles.Where(p => p.ProfileId == profileID).SingleOrDefault();
                var appraisal = db.Appraisals.Where(q => q.AppraisalId == profile.AppraisalId).SingleOrDefault();
                var type = db.AppraisalTypes.Where(r => r.AppraisalTypeId == appraisal.AppraisalTypeId).SingleOrDefault();

                return Ok(type);
            }
        }
    }
}
