﻿CREATE TABLE [History].[ApprovalStatuses] (
    [CreatedOn]        DATETIME      CONSTRAINT [DF_ApprovalStatuses_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ApprovalStatusID] INT           NOT NULL,
    [Title]            NVARCHAR (50) NOT NULL,
    [Code]             VARCHAR (6)   NOT NULL,
    [IsDeleted]        BIT           NOT NULL,
    [ModifiedBy]       NVARCHAR (50) NOT NULL,
    [ModifiedOn]       DATETIME      NOT NULL,
    [TimeStamp]        BINARY (8)    NOT NULL,
    CONSTRAINT [PK_ApprovalStatuses] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [ApprovalStatusID] ASC)
);

