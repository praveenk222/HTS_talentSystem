﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Harsco.HTS.API.Models
{
    public class _SP_HRTItoHTSFeed
    {
        public string Result { get; set; }
    }
}
