﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
	[EnableCors("AllowOrigin")]
	[Route("[controller]")]
	[ApiController]
	public class EndYearAppraisalController : ControllerBase
	{
		[HttpGet]
		[Route("GetObjectivesByID")]
		public IActionResult GetObjectivesByID(int appraisalID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var user = HttpContext.User.Identity;
				List<vmObjective> objectivesListVM = new List<vmObjective>();

				var objectivesListDB = db.Objectives.Include(x => x.ObjectiveApprovals).Where(p => p.AppraisalId == appraisalID).OrderBy(p => p.DateDue).ToList();
				foreach (var objectiveDB in objectivesListDB)
				{
					vmObjective objectiveVM = new vmObjective();
					objectiveVM.ObjectiveApprovals = new List<vmObjectiveApproval>();
					objectiveDB.BindModelTo(objectiveVM);
					foreach (var objectiveApprDB in objectiveDB.ObjectiveApprovals)
					{
						vmObjectiveApproval objectiveApprovalVM = new vmObjectiveApproval();
						objectiveApprDB.BindModelTo(objectiveApprovalVM);
						objectiveVM.ObjectiveApprovals.Add(objectiveApprovalVM);
					}

					objectivesListVM.Add(objectiveVM);
				}

				return Ok(objectivesListVM);
			}
		}

		[HttpGet]
		[Route("GetDropDownValuesForEndYear")]
		public IActionResult GetObjectivesAchievedValues()
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var ObjectiveAchieved = db.ObjectiveAchieved.ToList();
				var CompetencySkillRatings = db.CompetencySkillRatings.ToList();
				var valuesMaster = db.EnterpriseCompetencies.Where(p => p.EnterpriseCompetencyId >= 17 && p.EnterpriseCompetencyId <= 22).ToList();
				var appraisalRatings = db.AppraisalRatings.Where(p => p.IsDeleted == false).ToList();

				return Ok(new
				{
					ObjectiveAchieved,
					CompetencySkillRatings,
					valuesMaster,
					appraisalRatings
				});
			}
		}

		[HttpGet]
		[Route("GetAppraisalsByID")]
		public IActionResult GetAppraisalsByID(int appraisalID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalID).SingleOrDefault();
				vmAppraisals appraisalVM = new vmAppraisals();
				appraisalDB.BindModelTo(appraisalVM);
				var humanResourceDB = db.HumanResource.Where(p => p.AppraisalId == appraisalID).FirstOrDefault();
				appraisalVM.SendToHrFlag = humanResourceDB != null ? true : false;
				appraisalVM.HRStepComplete = (humanResourceDB != null && humanResourceDB.SendToManager != null) ? true : false;
				appraisalVM.HRComment = (humanResourceDB != null && humanResourceDB.Comments != null) ? humanResourceDB.Comments : null;
				appraisalVM.ReviewedByHR = (humanResourceDB != null && humanResourceDB.SendToManager != null) ?
					db.Profiles.Where(p => p.NetworkId == humanResourceDB.ModifiedBy && p.TerminationDate == null).SingleOrDefault().EmployeeName : null;
				appraisalVM.ReviewedByHROn = (humanResourceDB != null && humanResourceDB.SendToManager != null) ?
				   humanResourceDB.ModifiedOn.ToString() : null;

				return Ok(appraisalVM);
			}
		}

		[HttpGet]
		[Route("GetCompetencies")]
		public IActionResult GetCompetencies(int appraisalID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var competenciesListDB = db.Competencies.Include(p => p.CompetencyComments).Where(p => p.AppraisalId == appraisalID).ToList();
				List<vmEndYearCompetencies> endYearCompetenciesLst = new List<vmEndYearCompetencies>();
				competenciesListDB.ForEach(item =>
				{
					vmEndYearCompetencies endYearCompetenciesVM = new vmEndYearCompetencies();
					item.BindModelTo(endYearCompetenciesVM);
					endYearCompetenciesVM.EmployeeComment = item.CompetencyComments.FirstOrDefault() == null ? null : item.CompetencyComments.FirstOrDefault().Comment;
					endYearCompetenciesVM.ManagerComment = item.CompetencyComments.FirstOrDefault() == null ? null : item.CompetencyComments.FirstOrDefault().ManagerComment;
					endYearCompetenciesLst.Add(endYearCompetenciesVM);
				});

				return Ok(endYearCompetenciesLst);
			}
		}

		[HttpGet]
		[Route("GetNextYearPreliminaryObjectives")]
		public IActionResult GetNextYearPreliminaryObjectives(int appraisalID)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var nextYearDB = db.NextYearPreliminaryObjectives.Where(p => p.AppraisalId == appraisalID).ToList();
				if (nextYearDB == null)
					return Ok(new NextYearPreliminaryObjectives());
				else
					return Ok(nextYearDB);
			}
		}

		[HttpPost]
		[Route("UpdateCompetencies")]
		public IActionResult UpdateCompetencies(vmEndYearCompetencies endYearCompetenciesVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var competenciesDB = db.Competencies.Where(p => p.CompetencyId == endYearCompetenciesVM.CompetencyId).FirstOrDefault();

				endYearCompetenciesVM.BindModelTo(competenciesDB);

				//if (endYearCompetenciesVM.EmployeeComment != null)
				//{
				var competencyCommentDB = db.CompetencyComments.Where(p => p.CompetencyId == endYearCompetenciesVM.CompetencyId).FirstOrDefault();
				if (competencyCommentDB != null)
				{
					competencyCommentDB.Comment = endYearCompetenciesVM.EmployeeComment == null ? string.Empty : endYearCompetenciesVM.EmployeeComment;
					competencyCommentDB.ManagerComment = endYearCompetenciesVM.ManagerComment == null ? string.Empty : endYearCompetenciesVM.ManagerComment;
				}
				else
				{
					CompetencyComments CommentDB = new CompetencyComments();
					CommentDB.Comment = endYearCompetenciesVM.EmployeeComment == null ? string.Empty : endYearCompetenciesVM.EmployeeComment;
					CommentDB.ManagerComment = endYearCompetenciesVM.ManagerComment == null ? string.Empty : endYearCompetenciesVM.ManagerComment;
					CommentDB.CompetencyId = endYearCompetenciesVM.CompetencyId;
					CommentDB.CreatedBy = endYearCompetenciesVM.LoggedInUser.NetworkId;
					CommentDB.CreatedOn = DateTime.Now;
					CommentDB.ModifiedBy = endYearCompetenciesVM.LoggedInUser.NetworkId;
					CommentDB.ModifiedOn = DateTime.Now;
					db.CompetencyComments.Add(CommentDB);
				}
				//}

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateObjective")]
		public IActionResult UpdateObjective(vmObjective objectiveVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var objectivesDB = db.Objectives.Where(p => p.ObjectiveId == objectiveVM.ObjectiveId).SingleOrDefault();
				objectiveVM.BindModelTo(objectivesDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateAppraisalRatings")]
		public IActionResult UpdateAppraisalRatings(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				try
				{
					var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == Convert.ToInt32(appraisalsVM.AppraisalId)).SingleOrDefault();
					appraisalDB.PerformanceRating = appraisalsVM.PerformanceRating;
					appraisalDB.CompetencyRating = appraisalsVM.CompetencyRating;
					appraisalDB.OverallRating = appraisalsVM.OverallRating;

					db.SaveChanges();

					return Ok(new { status = "Success" });
				}
				catch (Exception ex)
				{
					var data = new TblErrors();
					data.ErrorMessage = ex.Message;
					data.ErrorProcedure = "UpdateAppraisalRatings(EndYearApprisalController)";
					data.ErrorLine = 191;
					this.SaveErrors(data);

					return Ok(new { status = "Failed" });

				}

			}
		}

		[HttpPost]
		[Route("SendToHR")]
		public IActionResult SendToHR(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				HumanResource humanResourceDB = new HumanResource();
				humanResourceDB.AppraisalId = appraisalsVM.AppraisalId;
				humanResourceDB.SendToHr = DateTime.Now;
				humanResourceDB.CreatedBy = appraisalsVM.LoggedInUser.NetworkId;
				humanResourceDB.CreatedOn = DateTime.Now;
				humanResourceDB.ModifiedBy = appraisalsVM.LoggedInUser.NetworkId;
				humanResourceDB.ModifiedOn = DateTime.Now;
				db.HumanResource.Add(humanResourceDB);

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("SaveHRComment")]
		public IActionResult SaveHRComment(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var humanResourceDB = db.HumanResource.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).FirstOrDefault();
				humanResourceDB.Comments = appraisalsVM.HRComment;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CheckisValidHRRepresentative")]
		public IActionResult CheckisValidHRRepresentative(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var hrreviewApprovals = db._AppraisalsSelfAssessmentNeedsManangerStepSP.FromSqlRaw("USP_AppraisalNeedsHRSignOff {0}", appraisalsVM.LoggedInUser.NetworkId).ToList();
				bool isDirectManager = (appraisalsVM.LoggedInUser.ProfileId == appraisalsVM.DisplayUser.ManagerId);
				bool isvalidHrRep = hrreviewApprovals.Any(p => p.NetworkId == appraisalsVM.DisplayUser.NetworkId) && !isDirectManager;

				//bool IsHR = false;
				//List<HrusersNew> hlist = new List<HrusersNew>();                
				//hlist = db.HrusersNew.Where(h => h.UserName == appraisalsVM.LoggedInUser.NetworkId).ToList();
				//            if (hlist != null)
				//                IsHR = hlist.Count > 0 ? true : false; 

				return Ok(new { status = isvalidHrRep });
			}
		}

		[HttpPost]
		[Route("CompleteHRAction")]
		public IActionResult CompleteHRAction(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var humanResourceDB = db.HumanResource.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).FirstOrDefault();
				humanResourceDB.SendToManager = DateTime.Now;
				humanResourceDB.Comments = appraisalsVM.HRComment;
				humanResourceDB.ModifiedBy = appraisalsVM.LoggedInUser.NetworkId;
				humanResourceDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateEmployeeComment")]
		public IActionResult UpdateEmployeeComment(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == Convert.ToInt32(appraisalsVM.AppraisalId)).SingleOrDefault();
				appraisalDB.EmployeeComment = appraisalsVM.EmployeeComment;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateManagerComment")]
		public IActionResult UpdateManagerComment(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == Convert.ToInt32(appraisalsVM.AppraisalId)).SingleOrDefault();
				appraisalDB.ManagerComment = appraisalsVM.ManagerComment;

				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("CreateNextYearPreliminaryObjectives")]
		public IActionResult CreateNextYearPreliminaryObjectives(vmNextYearPreliminaryObj nextYearPreliminaryVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				NextYearPreliminaryObjectives nextYearPreliminaryObjectivesDB = new NextYearPreliminaryObjectives();
				nextYearPreliminaryVM.BindModelTo(nextYearPreliminaryObjectivesDB);
				nextYearPreliminaryObjectivesDB.AppraisalId = nextYearPreliminaryVM.DisplayUser.AppraisalId;
				nextYearPreliminaryObjectivesDB.CreatedBy = nextYearPreliminaryVM.LoggedInUser.NetworkId;
				nextYearPreliminaryObjectivesDB.CreatedOn = DateTime.Now;
				nextYearPreliminaryObjectivesDB.ModifiedBy = nextYearPreliminaryVM.LoggedInUser.NetworkId;
				nextYearPreliminaryObjectivesDB.ModifiedOn = DateTime.Now;
				db.NextYearPreliminaryObjectives.Add(nextYearPreliminaryObjectivesDB);
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("UpdateNextYearPreliminaryObjectives")]
		public IActionResult UpdateNextYearPreliminaryObjectives(vmNextYearPreliminaryObj nextYearPreliminaryVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var nextYearPreliminaryObjectivesDB = db.NextYearPreliminaryObjectives.Where(p => p.Id == nextYearPreliminaryVM.Id).SingleOrDefault();

				try
				{
					if (nextYearPreliminaryObjectivesDB == null)
					{
						NextYearPreliminaryObjectives obj = new NextYearPreliminaryObjectives();
						//obj.BindModelTo(nextYearPreliminaryVM);
						obj.ModifiedBy = nextYearPreliminaryVM.LoggedInUser.NetworkId;
						obj.ModifiedOn = DateTime.Now;
						obj.CreatedBy = nextYearPreliminaryVM.LoggedInUser.NetworkId;
						obj.CreatedOn = DateTime.Now;
						obj.AppraisalId = nextYearPreliminaryVM.AppraisalId;
						obj.NextYearObjectives = nextYearPreliminaryVM.NextYearObjectives;
						db.NextYearPreliminaryObjectives.Add(obj);
						db.SaveChanges();

					}
					else
					{
						nextYearPreliminaryVM.BindModelTo(nextYearPreliminaryObjectivesDB);
						nextYearPreliminaryObjectivesDB.ModifiedBy = nextYearPreliminaryVM.LoggedInUser.NetworkId;
						nextYearPreliminaryObjectivesDB.ModifiedOn = DateTime.Now;
						db.SaveChanges();
					}
					return Ok(new { status = "Success" });
				}
				catch (Exception)
				{
					return Ok(new { status = "Failed" });
					throw;
				}
			}
		}



		[HttpPost]
		[Route("SubmitSelfAssessmentForEndYear")]
		public IActionResult SubmitSelfAssessmentForEndYear(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
				appraisalsVM.BindModelTo(appraisalDB);

				appraisalDB.SelfAssessmentComplete = true;
				appraisalDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("SubmitManagerAssessmentForEndYear")]
		public IActionResult SubmitManagerAssessmentForEndYear(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
				appraisalsVM.BindModelTo(appraisalDB);

				appraisalDB.ManagerStepComplete = true;
				appraisalDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("SaveForm")]
		public IActionResult SaveForm(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
				appraisalsVM.BindModelTo(appraisalDB);

				appraisalDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}

		[HttpPost]
		[Route("SignEmployeeAppraisal")]
		public IActionResult SignEmployeeAppraisal(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				try
				{
					var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
					appraisalsVM.BindModelTo(appraisalDB);
					appraisalDB.EmployeeSignDate = DateTime.Now;
					appraisalDB.EmployeeName = appraisalsVM.LoggedInUser.EmployeeName;

					appraisalDB.ModifiedOn = DateTime.Now;
					db.SaveChanges();
					return Ok(new { status = "Success" });

				}
				catch (Exception ex)
				{
					var data = new TblErrors();
					data.ErrorMessage = ex.Message;
					data.ErrorProcedure = "SignEmployeeAppraisal Controler";
					data.ErrorLine = 449;
					this.SaveErrors(data);

					return Ok(new { status = "Failed" });

				}



			}
		}


		[HttpPost]
		[Route("RejectCurrentAppraisal")]
		public IActionResult RejectCurrentAppraisal(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
				appraisalsVM.BindModelTo(appraisalDB);
				appraisalDB.EmployeeSignDate = DateTime.Now;
				appraisalDB.EmployeeName = "Rejected";
				appraisalDB.ModifiedOn = DateTime.Now;
				db.SaveChanges();

				return Ok(new { status = "Success" });
			}
		}


		[HttpPost]
		[Route("SignManagerAppraisal")]
		public IActionResult SignManagerAppraisal(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{				
				try
				{
					var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
					appraisalsVM.BindModelTo(appraisalDB);
					appraisalDB.ManagerStepComplete = true;
					appraisalDB.ManagerName = appraisalsVM.LoggedInUser.EmployeeName;
					appraisalDB.ManagerSignDate = DateTime.Now;
					appraisalDB.ModifiedOn = DateTime.Now;
					db.SaveChanges();

					//call archival procedure

					var connectionString = db.Database.GetDbConnection().ConnectionString;
					DataSet ds = new DataSet();
					using (SqlConnection conn = new SqlConnection(connectionString))
					{
						conn.Open();
						SqlCommand cmd = new SqlCommand("[dbo].[proc_Appraisal_Archive]", conn);
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@AppraisalID", appraisalsVM.AppraisalId);
						SqlDataAdapter adapter = new SqlDataAdapter(cmd);
						adapter.Fill(ds);
						conn.Close();
					}

					return Ok(new { status = "Success" });
				}
				catch (Exception ex)
				{
					var data = new TblErrors();
					data.ErrorMessage = ex.Message;
					data.ErrorNumber = 0;
					data.ErrorProcedure = "proc_Appraisal_Archive";
					data.ErrorLine = 525;
					this.SaveErrors(data);

					return Ok(new { status = "Failed" });

				}

			}
		}





            [HttpPost]
		[Route("SignManagersManagerAppraisal")]
		public IActionResult SignManagersManagerAppraisal(vmAppraisals appraisalsVM)
		{
			using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
			{
				try
				{
                    var appraisalDB = db.Appraisals.Where(p => p.AppraisalId == appraisalsVM.AppraisalId).SingleOrDefault();
                    appraisalsVM.BindModelTo(appraisalDB);
                    appraisalDB.ManagersManagerName = appraisalsVM.LoggedInUser.EmployeeName;
                    appraisalDB.ManagersManagerSignDate = DateTime.Now;

                    appraisalDB.ModifiedOn = DateTime.Now;
                    db.SaveChanges();

                    //call archival procedure

                    var connectionString = db.Database.GetDbConnection().ConnectionString;
                    DataSet ds = new DataSet();
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("[dbo].[proc_Appraisal_Archive]", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@AppraisalID", appraisalsVM.AppraisalId);
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(ds);
                        conn.Close();
                    }

                    return Ok(new { status = "Success" });
                }
				catch(Exception ex)
				{
                    var data = new TblErrors();
                    data.ErrorMessage = ex.Message;
					data.ErrorNumber = 538;
					data.ErrorProcedure = "proc_Appraisal_Archive";
                    data.ErrorLine = 525;
                    this.SaveErrors(data);

                    return Ok(new { status = "Failed" });

                }
			
			}
		}




		[HttpGet]
		[Route("ReturnToEmployee")]
		public IActionResult ReturnToEmployee(int AppraisalID)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					bool status = false;
					var result = db.Database.ExecuteSqlCommand("proc_empsignoff {0}", AppraisalID);
					if (result > 0) { status = true; }

					return Ok(status);
				}
			}
			catch (Exception ex)
			{

				throw ex;
			}

		}
		[HttpPost]
		[Route("ReturnToEmployeeDetails")]
		public IActionResult ReturnToEmployeeDetails(ReturnToEmployeeDetails item)
		{
			bool status = false;
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					item.ModifiedOn = DateTime.Now;
					//item.ActionerID = Convert.ToString(item.LoggedInUser.ProfileId);
					var result = db.Database.ExecuteSqlCommand("proc_SaveReturnToEmployeeReasons {0},{1},{2},{3},{4},{5},{6},{7},{8}", item.ManagerID, item.EmployeeID, item.ActionerID, item.AppraisalTypeID, item.ActionType, item.Description, item.ModifiedBy, item.ModifiedOn, item.IsActive);
					if (result > 0) { status = true; }
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return Ok(status);
		}

		[HttpGet]
		[Route("ReturnToEmployeeDetailsList")]
		public ActionResult ReturnToEmployeeDetailsList(int profileID)
		{
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var res = db.SP_ReturnToEmployeeDetails.FromSqlRaw("proc_GetListReturnToEmployeeReasons {0}", profileID).ToList();
					return Ok(res);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		//Save Errors to the tabl errors
		[HttpPost]
		[Route("SaveErrors")]
		public IActionResult SaveErrors(TblErrors item)
		{
			bool status = false;
			try
			{
				using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
				{
					var result = db.Database.ExecuteSqlCommand("proc_SaveErros {0},{1},{2},{3},{4},{5}", item.ErrorMessage, item.ErrorNumber, item.ErrorSeverity, item.ErrorState, item.ErrorLine, item.ErrorProcedure);
					if (result > 0) { status = true; }
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return Ok(status);
		}
	}
}