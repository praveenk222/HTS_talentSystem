﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[Split]
(
    @String VARCHAR(8000), 
    @Delimiter CHAR(1)
)        
RETURNS @temptable TABLE (items VARCHAR(8000))        
AS        
BEGIN        
    DECLARE @idx INT        
    DECLARE @slice VARCHAR(8000)        
       
    SELECT @idx = 1        
        IF len(@String)<1 or @String is null  RETURN        
       
    WHILE @idx!= 0        
    BEGIN        
        SET @idx = charindex(@Delimiter,@String)        
        IF @idx!=0        
            SET @slice = left(@String,@idx - 1)        
        ELSE        
            SET @slice = @String        
           
        IF(len(@slice)>0)   
            INSERT INTO @temptable(Items) VALUES(@slice)        
  
        SET @String = right(@String,len(@String) - @idx)        
        IF len(@String) = 0 BREAK        
    END    
RETURN        
END