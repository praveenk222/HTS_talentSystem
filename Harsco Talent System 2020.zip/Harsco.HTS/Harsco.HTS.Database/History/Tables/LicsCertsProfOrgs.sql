﻿CREATE TABLE [History].[LicsCertsProfOrgs] (
    [CreatedOn]                    DATETIME      CONSTRAINT [DF_LicsCertsProfOrgs_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [LicCertProfOrgID]             INT           NOT NULL,
    [EmployeeProfileID]            INT           NOT NULL,
    [Description]                  NTEXT         NOT NULL,
    [LicenseCategoryID]            INT           NOT NULL,
    [LicenseCategoryOther]         NVARCHAR (75) NULL,
    [LicenseNumber]                NVARCHAR (20) NULL,
    [CertificationNumber]          NVARCHAR (20) NULL,
    [ProfessionalOrganizationName] NVARCHAR (50) NULL,
    [DateReceived]                 DATETIME      NULL,
    [ExpirationDate]               DATETIME      NULL,
    [CreatedBy]                    VARCHAR (50)  NULL,
    [CratedOn]                     DATETIME      NULL,
    [ModifiedBy]                   NVARCHAR (50) NOT NULL,
    [ModifiedOn]                   DATETIME      NOT NULL,
    CONSTRAINT [PK_LicsCertsProfOrgs] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [LicCertProfOrgID] ASC)
);

