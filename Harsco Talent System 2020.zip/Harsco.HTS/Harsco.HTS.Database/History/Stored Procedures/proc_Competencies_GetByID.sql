﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_Competencies_GetByID]
    @CompetencyID int
AS
BEGIN
    SELECT CreatedOn, 
        CompetencyID, 
        AppraisalID, 
        EnterpriseCompetencyID, 
        EmployeeSkillRatingID, 
        ManagerSkillRatingID,
        ModifiedBy, 
        ModifiedOn
    FROM Competencies
    WHERE CompetencyID = @CompetencyID
    ORDER BY CreatedOn Desc
END