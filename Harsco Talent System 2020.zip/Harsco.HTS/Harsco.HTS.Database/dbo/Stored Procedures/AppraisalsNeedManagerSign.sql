﻿
-- ==================================================================
-- Author:		Ed Blair
-- Create date: 06/22/2012
-- Description: get appraisals the manager needs to sign
-- 
-- Modifications:
--  [dbo].[AppraisalsNeedManagerSign]  'eblair'
-- ==================================================================
CREATE PROCEDURE [dbo].[AppraisalsNeedManagerSign] 
	@CurrentUser varchar(50)
AS

SET NOCOUNT ON
BEGIN
	DECLARE @ManagerId int
	
	--SELECT @ManagerId = ProfileID FROM Profiles WHERE NetworkId = @CurrentUser
	--Commented since we are using ProfileID directly
	SET @ManagerId = @CurrentUser
	
    SELECT Profiles.EmployeeName, Appraisals.AppraisalId, ProfileID, Profiles.NetworkId
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
    WHERE SelfAssessmentComplete = 1
		AND ManagerStepComplete = 1
		AND EmployeeSignDate is not null
		AND ManagerSignDate is null
		AND ManagerID = @ManagerId
		AND Profiles.Networkid NOT IN ('removed','Duplicate','pdecker')
		AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND Profiles.TerminationDate IS NULL

    UNION ALL

    SELECT Profiles.EmployeeName, Appraisals.AppraisalId, Profiles.ProfileID, Profiles.NetworkId
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		INNER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerId
    WHERE SelfAssessmentComplete = 1
		AND ManagerStepComplete = 1
		AND ManagerSignDate is not null
		AND ManagersManagerSignDate is null
		AND Manager.ManagerID = @ManagerId
		AND Profiles.Networkid NOT IN ('removed','Duplicate','pdecker')
		AND Profiles.Networkid NOT IN (select NetworkID FROM NotRequiredReview WHERE IsDeleted = 0)
		AND Profiles.TerminationDate IS NULL
	
END
SET NOCOUNT OFF