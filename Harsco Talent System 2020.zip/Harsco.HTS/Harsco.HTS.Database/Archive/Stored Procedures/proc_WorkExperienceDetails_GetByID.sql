﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_WorkExperienceDetails_GetByID]
    @ArchiveWorkExperienceDetailID int
AS
BEGIN
    SELECT ArchiveWorkExperienceDetailID, 
        ArchiveWorkExperienceID, 
        Title, 
        Responsibilities, 
        Sequence, 
        ModifiedBy, 
        ModifiedOn
    FROM WorkExperienceDetails
    WHERE ArchiveWorkExperienceDetailID = @ArchiveWorkExperienceDetailID
END