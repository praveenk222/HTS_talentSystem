﻿CREATE TABLE [Archive].[DevelopmentPlanStrengths] (
    [ArchiveDevelopmentPlanStrengthID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanStrengthID] INT           NOT NULL,
    [ArchiveDevelopmentPlanID]          INT           NOT NULL,
    [Strength]                          NTEXT         NOT NULL,
    [ModifiedBy]                        NVARCHAR (50) NOT NULL,
    [ModifiedOn]                        DATETIME      CONSTRAINT [DF_DevelopmentPlanStrengths_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanStrengths] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanStrengthID] ASC),
    CONSTRAINT [FK_DevelopmentPlanStrengths_DevelopmentPlans] FOREIGN KEY ([ArchiveDevelopmentPlanID]) REFERENCES [Archive].[DevelopmentPlans] ([ArchiveDevelopmentPlanID])
);


GO
CREATE TRIGGER [Archive].[tr_DevelopmentPlanStrengths_PreventChanges]     ON  Archive.DevelopmentPlanStrengths     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END