﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_TrainingDevelopment_GetByArchiveProfileID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveTrainingDevelopmentID, 
        ArchiveProfileID, 
        Description, 
        TrainingCategory, 
        CertificationNumber, 
        YearObtained, 
        ExpirationDate, 
        ModifiedBy, 
        ModifiedOn
    FROM TrainingDevelopment
    WHERE ArchiveProfileID = @ArchiveProfileID
END