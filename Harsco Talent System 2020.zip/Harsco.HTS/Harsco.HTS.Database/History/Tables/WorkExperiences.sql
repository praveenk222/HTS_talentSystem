﻿CREATE TABLE [History].[WorkExperiences] (
    [CreatedOn]             DATETIME       CONSTRAINT [DF_WorkExperiences_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [WorkExperienceID]      INT            NOT NULL,
    [EmployeeProfileID]     INT            NOT NULL,
    [EmployerName]          NVARCHAR (75)  NOT NULL,
    [JobTitle]              VARCHAR (255)  NOT NULL,
    [Address]               NVARCHAR (255) NOT NULL,
    [DateEmploymentStarted] SMALLDATETIME  NOT NULL,
    [DateEmploymentEnded]   SMALLDATETIME  NULL,
    [CreatedBy]             VARCHAR (50)   NOT NULL,
    [Created]               DATETIME       NOT NULL,
    [ModifiedBy]            NVARCHAR (50)  NOT NULL,
    [ModifiedOn]            DATETIME       NOT NULL,
    CONSTRAINT [PK_WorkExperiences] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [WorkExperienceID] ASC)
);



