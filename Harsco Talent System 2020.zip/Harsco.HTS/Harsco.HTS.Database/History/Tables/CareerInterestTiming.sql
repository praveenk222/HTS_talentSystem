﻿CREATE TABLE [History].[CareerInterestTiming] (
    [CreatedOn]              DATETIME      CONSTRAINT [DF_CareerInterestTiming_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CareerInterestTimingID] INT           NOT NULL,
    [Title]                  NVARCHAR (50) NOT NULL,
    [IsDeleted]              BIT           NOT NULL,
    [ModifiedBy]             NVARCHAR (50) NOT NULL,
    [ModifiedOn]             DATETIME      NOT NULL,
    [TimeStamp]              BINARY (8)    NOT NULL,
    CONSTRAINT [PK_CareerInterestTiming] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CareerInterestTimingID] ASC)
);

