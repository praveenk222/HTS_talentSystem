﻿using Harsco.HTS.API.Helpers;
using Harsco.HTS.API.Models;
using Harsco.HTS.API.Models.Harsco.HTS.API.Models;
using Harsco.HTS.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Org.BouncyCastle.Asn1.Ess;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Harsco.HTS.API.Controllers
{
    [EnableCors("AllowOrigin")]
    [ApiController]
    [Route("[controller]")]
    public class MycompetencyController : ControllerBase
    {
        private readonly IConfiguration _config;
        private string Harsco_AIF_connectionstring;
        //ResponseDto _ResponseDto = new ResponseDto();
        public MycompetencyController(IConfiguration configuration)
        {
            this._config = configuration;
            this.Harsco_AIF_connectionstring = configuration["ConnectionStrings:Harsco.HTS.connectionString"].ToString();
        }
        public IActionResult GetLDRComptncy()
        {
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    var res = db.LeadershipCompetencies.FromSqlRaw("USP_GetLDRComp").ToList();

                    return Ok(res);
                }

            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetEmpRatings/{ID}")]
        public IActionResult GetEmpRating(int ID)
        {
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    var res = db.tbl_EmpCompetencies.FromSqlRaw("USP_GetEMPRating {0}",ID).ToList();

                    return Ok(res);
                }

            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetAllCompetencies")]
        public IActionResult GetAllCompetencies()
        {
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    vmCompetencies vmcompetencies = new vmCompetencies();
                    vmComptency vms = new vmComptency();
                    vmcompetencies.LeadershipCompetencyRatings = new List<LeadershipCompetencyRatings>();
                    vmcompetencies.LDRCompetencies_Desc = new List<LDRCompetenciesDesc>();
                    List<LeadershipCompetencies> vmd = new List<LeadershipCompetencies>();
                    //vmcomp.LeadershipCompetencyRatings = db.LdrshipRating.FromSqlRaw("USP_GetLDRCompRating").ToList();
                    //vmcomp.LDRCompetencies_Desc = db.LDRCompetenciesDescrp.FromSqlRaw("USP_GetLDRCompDesc").ToList();
                    vmd = db.LeadershipCompetencies.FromSqlRaw("USP_GetLDRComp").ToList();
                    foreach (var item in vmd)
                    {
                        vms.LeadershipCompetencies.Add(item);

                        var data = db.LdrshipRating.FromSqlRaw("USP_GetLDRCompRatingByID {0}", item.LC_ID).ToList();
                        foreach (var rest in data)
                        {
                            vmcompetencies.LeadershipCompetencyRatings.Add(rest);
                        }
                        var Comdata = db.LDRCompetenciesDescrp.FromSqlRaw("USP_GetLDRCompDescByID {0}", item.LC_ID).ToList();

                        foreach (var restc in Comdata)
                        {

                            vmcompetencies.LDRCompetencies_Desc.Add(restc);
                        }


                    }

                    return Ok(vmcompetencies);
                }

            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetCompetencies")]
        public IActionResult GetCompetencies()
        {
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    vmCompetencies vmcompetencies = new vmCompetencies();
                    vmComptency vms = new vmComptency();


                    vms.LeadershipCompetencyRatings = db.LdrshipRating.FromSqlRaw("USP_GetLDRCompRating").ToList();
                    vms.LDRCompetencies_Desc = db.LDRCompetenciesDescrp.FromSqlRaw("USP_GetLDRCompDesc").ToList();
                    vms.LeadershipCompetencies = db.LeadershipCompetencies.FromSqlRaw("USP_GetLDRComp").ToList();


                    return Ok(vms);
                }

            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        public IActionResult SaveEmpRating(LeadershipCompetencies item)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Harsco_AIF_connectionstring))
                {
                    DataSet ds = new DataSet();

                    SqlCommand cmd = new SqlCommand("USP_InsertLDRComp", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    cmd.Parameters.AddWithValue("@Description", item.Description);
                    cmd.Parameters.AddWithValue("@Competency", item.Competency);
                    cmd.Parameters.AddWithValue("@ModifiedBy", item.ModifiedBy);
                    cmd.Parameters.AddWithValue("@IsActive", item.IsActive);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(ds);
                    conn.Close();
                    return Ok(ds.Tables[0]);
                }


            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost("SaveEMPCompetency")]
        public IActionResult SaveEMPCompetency(vmemprating item)
        {
            try
            {
                //removing mgrcomment not requied for saving Emp Comments
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    bool status = false;
                    List<PostResult> PostResults = new List<PostResult>();
                    {
                        vmProfile profileModel = new vmProfile();
                        int M_ID = Convert.ToInt16(item.EmpCompetencies[0].ApproverID);
                        profileModel.NetworkId = db.Profiles.Where(x => x.ProfileId == M_ID).FirstOrDefault().NetworkId;
                        foreach (var data in item.EmpCompetencies)
                        {

                            var res = db.postResults.FromSqlRaw("USP_SaveEmpCompetencies {0},{1},{2},{3},{4},{5},{6},{7},{8},{9}", data.LC_ID, data.AppraisalID, data.AppraisalTypeID, data.EmpRating,  data.ApprovalStatusID, profileModel.NetworkId, data.ModifiedBy, data.EmpComment,  data.EmpNumber, data.IsActive).ToList();
                            PostResults.AddRange(res);
                        }
                    }                   

                    return Ok(PostResults);
                }


            }
            catch (System.Exception ex)
            {

                return StatusCode(500, new { message = ex.Message });
            }
        }
        [HttpPost("SaveMgrCompetency")]
        public IActionResult UpdateEMPCompetency(vmemprating item)
        {
            try
            {
                using (Performance_ManagmentContextDbo db = new Performance_ManagmentContextDbo())
                {
                    List<PostResult> PostResults = new List<PostResult>();
                    {

                        //  int M_ID = Convert.ToInt16(item.EmpCompetencies[0].ApproverID);
                        //var data = db.tbl_EmpCompetencies.Where( x => x.AppraisalID == item.EmpCompetencies[0].AppraisalID).ToList();
                        foreach (var data in item.EmpCompetencies)
                        {
                           var  res = db.postResults.FromSqlRaw("USP_UpdateEmpCompetencies {0},{1},{2},{3},{4},{5},{6},{7}", data.LC_ID, data.AppraisalID, data.AppraisalTypeID,  data.MgrRating, data.ApprovalStatusID, data.ModifiedBy, data.MgrComment, data.IsActive).ToList();
                            PostResults.AddRange(res);
                        }
                    }                  

                    return Ok(PostResults);
                }


            }
            catch (System.Exception ex)
            {

                return StatusCode(500, new { message = ex.Message });
            }
        }

    }
}
