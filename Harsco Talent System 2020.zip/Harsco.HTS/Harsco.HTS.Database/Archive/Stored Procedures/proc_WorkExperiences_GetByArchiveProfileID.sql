﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_WorkExperiences_GetByArchiveProfileID]
    @ArchiveProfileID int
AS
BEGIN
    SELECT ArchiveWorkExperienceID, 
        ArchiveProfileID, 
        EmployerName, 
        Address, 
        DateEmploymentStarted, 
        DateEmploymentEnded, 
        ModifiedBy, 
        ModifiedOn
    FROM WorkExperiences
    WHERE ArchiveProfileID = @ArchiveProfileID
END