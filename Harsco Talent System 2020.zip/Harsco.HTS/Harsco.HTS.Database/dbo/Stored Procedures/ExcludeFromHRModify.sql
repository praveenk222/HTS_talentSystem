﻿


-- =========================================================================
-- Author:		Ed Blair
-- Create date: 8/15/2013
-- Description:	modify a single ExcludeFromHR record
--
-- =========================================================================
CREATE PROCEDURE [dbo].[ExcludeFromHRModify]

@Id int,
@ADName varchar(50),
@ELTFlag bit,
@CreatedBy varchar(50),
@CreatedOn datetime,
@ModifiedBy varchar(50),
@ModifiedOn datetime
      
AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.ExcludeFromHR WHERE Id = @Id))
		BEGIN
			UPDATE ExcludeFromHR SET
				ADName = @ADName,
				ELTFlag = @ELTFlag,
				ModifiedBy = @ModifiedBy,
				ModifiedOn = @ModifiedOn
			WHERE Id = @Id		
		END
    ELSE
		BEGIN
			INSERT INTO ExcludeFromHR (ADName, ELTFlag, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn)
			VALUES (@ADName, @ELTFlag, @CreatedBy, @CreatedOn, @ModifiedBy, @ModifiedOn)
		END
END