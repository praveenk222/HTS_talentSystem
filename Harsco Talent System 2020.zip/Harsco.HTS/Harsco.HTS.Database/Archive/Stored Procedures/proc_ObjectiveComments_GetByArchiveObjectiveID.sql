﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/06/25
-- =============================================
CREATE PROCEDURE [Archive].[proc_ObjectiveComments_GetByArchiveObjectiveID]
    @ArchiveObjectiveID int
AS
BEGIN
    SELECT ArchiveObjectiveCommentID, 
        ArchiveObjectiveID, 
        ArchiveObjectiveMilestoneID, 
        Comment, 
        Confidential, 
        CommentType, 
        ModifiedBy, 
        ModifiedOn
    FROM ObjectiveComments
    WHERE ArchiveObjectiveID = @ArchiveObjectiveID
END