﻿CREATE TABLE [History].[CommentTypes] (
    [CreatedOn]     DATETIME      CONSTRAINT [DF_CommentTypes_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [CommentTypeID] INT           NOT NULL,
    [Title]         NVARCHAR (50) NOT NULL,
    [Code]          VARCHAR (6)   NOT NULL,
    [IsDeleted]     BIT           NOT NULL,
    [ModifiedBy]    NVARCHAR (50) NOT NULL,
    [ModifiedOn]    DATETIME      NOT NULL,
    [TimeStamp]     BINARY (50)   NOT NULL,
    CONSTRAINT [PK_CommentTypes] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [CommentTypeID] ASC)
);

