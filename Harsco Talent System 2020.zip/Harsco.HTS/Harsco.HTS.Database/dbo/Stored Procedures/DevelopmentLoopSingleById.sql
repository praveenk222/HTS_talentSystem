﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2017/10/20
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentLoopSingleById]

@DevelopmentLoopId int

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT ID, Description, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM dbo.DevelopmentLoop
	WHERE ID = @DevelopmentLoopId
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;