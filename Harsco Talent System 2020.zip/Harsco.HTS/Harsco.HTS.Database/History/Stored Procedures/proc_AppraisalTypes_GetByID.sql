﻿

-- =============================================
-- AUTHOR: Shaun Kline
-- CREATED DATE: 2009/07/29
-- =============================================
CREATE PROCEDURE [History].[proc_AppraisalTypes_GetByID]
    @AppraisalTypeID int
AS
BEGIN
    SELECT CreatedOn, 
        AppraisalTypeID, 
        Title, 
        Code, 
        IsDeleted, 
        ModifiedBy, 
        ModifiedOn, 
        TimeStamp
    FROM AppraisalTypes
    WHERE AppraisalTypeID = @AppraisalTypeID
    ORDER BY CreatedOn Desc
END