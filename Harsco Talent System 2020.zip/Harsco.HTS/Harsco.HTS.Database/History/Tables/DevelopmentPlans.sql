﻿CREATE TABLE [History].[DevelopmentPlans] (
    [CreatedOn]          DATETIME      CONSTRAINT [DF_DevelopmentPlans_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [DevelopmentPlanID]  INT           NOT NULL,
    [AppraisalID]        INT           NOT NULL,
    [AppraisalTimeStamp] BINARY (8)    NOT NULL,
    [ModifiedBy]         NVARCHAR (50) NOT NULL,
    [ModifiedOn]         DATETIME      NOT NULL,
    [TimeStamp]          BINARY (50)   NOT NULL,
    CONSTRAINT [PK_DevelopmentPlans_1] PRIMARY KEY CLUSTERED ([CreatedOn] ASC, [DevelopmentPlanID] ASC)
);

