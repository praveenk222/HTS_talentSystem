﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 7/10/2012
-- =============================================
CREATE PROCEDURE [dbo].[DevelopmentPlanCompletionListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT Id, Completion, IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM DevelopmentPlanCompletion
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;