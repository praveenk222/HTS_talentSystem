﻿

-- =========================================================================
-- Author:		Ed Blair
-- Create date: 8/15/2013
-- Description:	list all ExcludeFromHR records
--
-- =========================================================================
CREATE PROCEDURE [dbo].[ExcludeFromHRListAll]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

  SELECT Id, ADName, ELTFlag, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
  FROM dbo.ExcludeFromHR
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;