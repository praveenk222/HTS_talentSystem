﻿


-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 5/1/2013
-- =============================================
CREATE PROCEDURE [dbo].[CommunicationsLogModify]

@CommunicationsLogID int,
@AppraisalID int,
@Recipients nvarchar(500),
@Subject nvarchar(200),
@Body ntext,
@DateSent datetime,
@ModifiedBy nvarchar(50),
@ModifiedOn datetime

AS

BEGIN
	IF (EXISTS(SELECT 1 FROM dbo.CommunicationsLog WHERE CommunicationsLogID = @CommunicationsLogID))
		BEGIN
			UPDATE CommunicationsLog
			SET AppraisalID = @AppraisalID, 
				Recipients = @Recipients,
				[Subject] = @Subject,
				Body = @Body,
				DateSent = @DateSent,
				ModifiedBy = @ModifiedBy,
				ModifiedOn = @ModifiedOn
			WHERE CommunicationsLogID = @CommunicationsLogID		
		END
    ELSE
		BEGIN
			INSERT INTO CommunicationsLog
			(AppraisalID, Recipients, [Subject], Body, DateSent, ModifiedBy, ModifiedOn)
			VALUES (@AppraisalID, @Recipients, @Subject, @Body, @DateSent, @ModifiedBy, @ModifiedOn)

		END
END