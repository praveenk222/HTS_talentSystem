﻿CREATE TABLE [Archive].[UnderstoodLanguages] (
    [ArchiveUnderstoodLanguageID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalUnderstoodLanguageID] INT           NOT NULL,
    [ArchiveProfileID]             INT           NOT NULL,
    [Language]                     NVARCHAR (50) NOT NULL,
    [Description]                  NTEXT         NULL,
    [LanguageFluency]              NVARCHAR (50) NOT NULL,
    [ModifiedBy]                   NVARCHAR (50) NOT NULL,
    [ModifiedOn]                   DATETIME      CONSTRAINT [DF_UnderstoodLanguages_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_UnderstoodLanguages_1] PRIMARY KEY CLUSTERED ([ArchiveUnderstoodLanguageID] ASC),
    CONSTRAINT [FK_UnderstoodLanguages_Profiles] FOREIGN KEY ([ArchiveProfileID]) REFERENCES [Archive].[Profiles] ([ArchiveProfileID])
);


GO

CREATE TRIGGER [Archive].[tr_UnderstoodLanguages_PreventChanges]     ON  Archive.UnderstoodLanguages     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END