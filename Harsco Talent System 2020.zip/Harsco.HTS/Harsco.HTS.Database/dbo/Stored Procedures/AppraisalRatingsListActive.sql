﻿

-- =============================================
-- AUTHOR: Ed Blair
-- CREATED DATE: 2012/06/12
-- =============================================
CREATE PROCEDURE [dbo].[AppraisalRatingsListActive]

AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN

    SELECT Id, [Description], IsDeleted, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
    FROM AppraisalRatings
    WHERE IsDeleted = 0
	
END
SET NOCOUNT OFF
COMMIT TRANSACTION;