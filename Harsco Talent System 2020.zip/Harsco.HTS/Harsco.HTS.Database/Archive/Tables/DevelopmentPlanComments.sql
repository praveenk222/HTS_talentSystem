﻿CREATE TABLE [Archive].[DevelopmentPlanComments] (
    [ArchiveDevelopmentPlanCommentID]  INT           IDENTITY (1, 1) NOT NULL,
    [OriginalDevelopmentPlanCommentID] INT           NOT NULL,
    [ArchiveDevelopmentPlanStrengthID] INT           NULL,
    [ArchiveDevelopmentPlanWeaknessID] INT           NULL,
    [ArchiveDevelopmentPlanDetailID]   INT           NULL,
    [Comment]                          NTEXT         NOT NULL,
    [Confidential]                     BIT           CONSTRAINT [DF_DevelopmentPlanComments_Confidential_1] DEFAULT ((0)) NOT NULL,
    [CommentType]                      NVARCHAR (50) NOT NULL,
    [ModifiedBy]                       NVARCHAR (50) NOT NULL,
    [ModifiedOn]                       DATETIME      CONSTRAINT [DF_DevelopmentPlanComments_ModifiedOn_1] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_DevelopmentPlanComments] PRIMARY KEY CLUSTERED ([ArchiveDevelopmentPlanCommentID] ASC),
    CONSTRAINT [FK_DevelopmentPlanComments_DevelopmentPlanDetails] FOREIGN KEY ([ArchiveDevelopmentPlanDetailID]) REFERENCES [Archive].[DevelopmentPlanDetails] ([ArchiveDevelopmentPlanDetailID]),
    CONSTRAINT [FK_DevelopmentPlanComments_DevelopmentPlanStrengths] FOREIGN KEY ([ArchiveDevelopmentPlanStrengthID]) REFERENCES [Archive].[DevelopmentPlanStrengths] ([ArchiveDevelopmentPlanStrengthID]),
    CONSTRAINT [FK_DevelopmentPlanComments_DevelopmentPlanWeaknesses] FOREIGN KEY ([ArchiveDevelopmentPlanWeaknessID]) REFERENCES [Archive].[DevelopmentPlanWeaknesses] ([ArchiveDevelopmentPlanWeaknessID])
);


GO
CREATE TRIGGER [Archive].[tr_DevelopmentPlanComments_PreventChanges]     ON  Archive.DevelopmentPlanComments     INSTEAD OF DELETE, UPDATE  AS   BEGIN   SET NOCOUNT ON;    END