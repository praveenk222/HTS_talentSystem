﻿
-- ==================================================================
-- Author:		Ed Blair
-- Create date: 03/27/2013
-- Description: Get list of actions that the user has
-- 
-- Modifications:
-- [dbo].[GETHTSActionsForNetworkId]  'tdegregorio'
-- ==================================================================
CREATE PROCEDURE [dbo].[GETHTSActionsForNetworkId]

@NetworkId varchar(50)

AS
   
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SET NOCOUNT ON
BEGIN   
	DECLARE @ListofApprovers TABLE (ApproverId nvarchar(100), LanguageCode nvarchar(5))

	--Objective Approvals
    INSERT INTO @ListofApprovers
    SELECT ApproverId, ISNULL(TranslationLanguages.Code, 'en')
    FROM ObjectiveApprovals
		INNER JOIN Objectives ON Objectives.ObjectiveID = ObjectiveApprovals.ObjectiveID
		INNER JOIN Profiles ON Profiles.AppraisalId = Objectives.AppraisalId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId
    WHERE ApprovalStatusID = (SELECT ApprovalStatusID FROM ApprovalStatuses WHERE Title = 'Pending') 
		AND ObjectiveApprovals.ObjectiveID IS NOT NULL
		AND ApproverId = @NetworkId
		
	-- Development Plan Approvals
    INSERT INTO @ListofApprovers
    SELECT ApproverId, ISNULL(TranslationLanguages.Code, 'en')
	FROM DevelopmentPlanApprovals
		INNER JOIN DevelopmentPlanDetails ON DevelopmentPlanDetails.DevelopmentPlanDetailId = DevelopmentPlanApprovals.DevelopmentPlanDetailId
		INNER JOIN dbo.DevelopmentPlans ON DevelopmentPlans.DevelopmentPlanId = DevelopmentPlanDetails.DevelopmentPlanId
    	INNER JOIN Profiles ON Profiles.AppraisalId = DevelopmentPlans.AppraisalId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId    	
    WHERE DevelopmentPlanApprovals.ApprovalStatusID = (SELECT ApprovalStatusID FROM ApprovalStatuses WHERE Title = 'Pending') 
		AND DevelopmentPlanApprovals.DevelopmentPlanDetailID IS NOT NULL
		AND ApproverId = @NetworkId
		
	-- Employee Self Assessment Submitted
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en')
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN HumanResource ON HumanResource.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 0
    AND (HumanResource.Id IS NULL or (HumanResource.SendToHr IS NOT NULL
    AND HumanResource.SendToManager IS NOT NULL))
	AND Manager.NetworkId = @NetworkId
	
	-- Signoff on Employee's Appraisal
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en')
	FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and EmployeeSignDate is not null
    AND ManagerSignDate is null
    AND Manager.NetworkId = @NetworkId
    UNION ALL
    SELECT ManagerManager.NetworkId, ISNULL(TranslationLanguages.Code, 'en')
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		INNER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerId
		LEFT OUTER JOIN Profiles ManagerManager ON ManagerManager.ProfileId = Manager.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and ManagerSignDate is not null
    AND ManagersManagerSignDate is null
	AND Manager.NetworkId = @NetworkId
			
	-- Signoff on Your Appraisal
    INSERT INTO @ListofApprovers 
    SELECT Profiles.NetworkId, ISNULL(TranslationLanguages.Code, 'en')
    FROM dbo.Appraisals
		INNER JOIN Profiles ON Profiles.AppraisalID = Appraisals.AppraisalID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Profiles.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE SelfAssessmentComplete = 1
    and ManagerStepComplete = 1
    and EmployeeSignDate is null
    AND ManagerSignDate is null
    AND Profiles.Networkid = @NetworkId
	
    -- Mid Year Submitted
    INSERT INTO @ListofApprovers
    SELECT Manager.NetworkId, ISNULL(TranslationLanguages.Code, 'en')
    FROM dbo.MidYear
		INNER JOIN Profiles ON Profiles.ProfileId = MidYear.ProfileId
		LEFT OUTER JOIN Profiles Manager ON Manager.ProfileId = Profiles.ManagerID
		LEFT OUTER JOIN CountryLanguage ON CountryLanguage.CountryId = Manager.CountryID
		LEFT OUTER JOIN TranslationLanguages ON TranslationLanguages.Id = CountryLanguage.TranslationLanguagesId		
    WHERE EmpSignDate is not null
    AND MgrSignDate is null
	AND Manager.NetworkId = @NetworkId
    
	SELECT DISTINCT ApproverId, LanguageCode
	FROM @ListofApprovers
	WHERE ApproverId != ''
END
SET NOCOUNT OFF
COMMIT TRANSACTION;